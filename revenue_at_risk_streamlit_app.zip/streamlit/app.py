"""app.py - Revenue-at-Risk Agent (NexaSphere Command Center), Streamlit in Snowflake entry point."""
import streamlit as st

st.set_page_config(page_title="Revenue-at-Risk Agent", page_icon="❄️", layout="wide",
                   initial_sidebar_state="expanded")

import ui_common as ui  # noqa: E402  (after set_page_config)

ui.inject_css()
ui.sidebar_brand()

for key, default in (("history", []), ("results", []), ("last_result", None), ("pins", {})):
    st.session_state.setdefault(key, default)

pages = [
    st.Page("ask_agent_page.py", title="Ask the Agent", icon=":material/forum:", default=True),
    st.Page("overview_page.py", title="Overview", icon=":material/space_dashboard:"),
    st.Page("action_board_page.py", title="Action Board", icon=":material/task_alt:"),
    st.Page("trace_page.py", title="Reasoning Trace", icon=":material/data_object:"),
    st.Page("architecture_page.py", title="Architecture", icon=":material/account_tree:"),
]

with st.sidebar:
    st.caption("Governed by Snowflake · reasoning by Claude Opus 5.5")

st.navigation(pages).run()
