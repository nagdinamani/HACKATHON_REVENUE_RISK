"""Page 4 - Reasoning Trace: the SQL and tool evidence behind the last answer."""
from __future__ import annotations

import json

import pandas as pd
import streamlit as st

import ui_common as ui

ui.show_flash()
ui.brand_header("Reasoning Trace", "Every query and decision tool the agent used for the last answer")

last = st.session_state.get("last_result")
if not last:
    ui.card('<div style="font-weight:700;margin-bottom:6px;">Nothing traced yet</div>'
            '<div class="raa-muted">Ask a question on <b>Ask the Agent</b>; the governed SQL, result rows and '
            'decision-tool outputs it relied on will appear here.</div>', "dashed")
    st.stop()

calls = last.get("tool_calls") or []
rows_total = sum(len(c.get("rows") or []) for c in calls)
failures = [c for c in calls if c.get("error") or str(c.get("status", "")).lower() == "error"]
trust = last.get("trust") or {}
t_status = trust.get("status") or "UNCHECKED"
t_col = {"PASSED": ui.GREEN, "FLAGGED": ui.RED}.get(t_status, ui.AMBER)

ui.card(f"""<div class="raa-eyebrow">Question</div>
<div style="font-size:1.08rem;font-weight:600;margin:4px 0 10px 0;">“{ui.esc(last.get('question'))}”</div>
<div style="display:flex;gap:18px;flex-wrap:wrap;">
<div><span class="raa-muted">Tool calls</span><br><b>{len(calls)}</b></div>
<div><span class="raa-muted">Rows returned</span><br><b>{rows_total:,}</b></div>
<div><span class="raa-muted">Trust</span><br><b style="color:{t_col}">{ui.esc(t_status)}</b>
<span class="raa-muted"> · {int(trust.get('dollar_values_checked') or 0)} $ figures checked</span></div>
<div><span class="raa-muted">Failures</span><br><b style="color:{ui.RED if failures else ui.TEXT_PRIMARY}">{len(failures)}</b></div>
</div>""")
if last.get("error"):
    st.error(f"Agent error: {last['error']}")
if trust.get("unverified"):
    st.error("Unverified figures: " + ", ".join(map(str, trust["unverified"])))


def _tables_in(obj, found: list, depth: int = 0) -> list:
    """List-of-dicts inside a tool JSON, shown as dataframes."""
    if depth > 4:
        return found
    if isinstance(obj, list) and obj and all(isinstance(x, dict) for x in obj):
        found.append(obj)
    elif isinstance(obj, dict):
        for v in obj.values():
            _tables_in(v, found, depth + 1)
    elif isinstance(obj, list):
        for v in obj:
            _tables_in(v, found, depth + 1)
    return found


if not calls:
    ui.card('<div class="raa-muted">The agent answered without calling a tool.</div>')

with st.container(height=640, border=False):
    for n, c in enumerate(calls, 1):
        is_analyst = c.get("kind") == "analyst"
        status = "ERROR" if (c.get("error") or str(c.get("status", "")).lower() == "error") else "SUCCESS"
        kind_pill = ui.pill("Cortex Analyst" if is_analyst else "Decision tool",
                            ui.SNOWFLAKE_BLUE if is_analyst else ui.CLAUDE_CLAY)
        with st.container(border=True):
            ui.md_html(f"""<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;">
<div><span class="raa-muted">Step {n} of {len(calls)}</span> · <b>{ui.esc(c.get('name'))}</b></div>
<div>{kind_pill} {ui.pill(status)}</div></div>""")
            if c.get("error"):
                st.error(str(c["error"])[:600])
            if is_analyst:
                st.code(c.get("sql") or "", language="sql")
                rows = c.get("rows") or []
                if rows:
                    df = pd.DataFrame(rows)
                    st.dataframe(df, hide_index=True, use_container_width=True, height=min(38 + 35 * len(df), 360))
                else:
                    st.caption("No rows returned.")
            else:
                if c.get("input"):
                    st.caption("Input arguments")
                    st.code(json.dumps(c["input"], indent=2, default=str), language="json")
                payload = c.get("json")
                if payload is not None:
                    st.json(payload, expanded=False)
                    for tbl in _tables_in(payload, [])[:3]:
                        df = pd.DataFrame(tbl)
                        st.dataframe(df, hide_index=True, use_container_width=True, height=min(38 + 35 * len(df), 320))
