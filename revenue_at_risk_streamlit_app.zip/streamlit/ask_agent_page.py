"""Page 1 (default) - Ask the Agent: chat on the left, Insights panel on the right."""
from __future__ import annotations

import pandas as pd
import streamlit as st

import rr_backend as rb
import ui_common as ui

CHIPS = [
    "Give me the Q4 revenue outlook.",
    "How much revenue is at risk from late-stage deals that are stalling?",
    "How much revenue is at risk before quarter-end, in total?",
    "We are $8.2M short. What can we recover, and how do we close the rest?",
    "What should we put in place so this does not happen again next quarter?",
]

ui.show_flash()
ui.brand_header("Ask the Agent", "Cortex Agent · Claude Opus 5.5 · Cortex Analyst over governed Snowflake data")

state = st.session_state
for key, default in (("history", []), ("results", []), ("last_result", None), ("pins", {})):
    state.setdefault(key, default)


# ----------------------------------------------------------------------------------------
# Rendering helpers
# ----------------------------------------------------------------------------------------
def _metric_value(key: str, v):
    if isinstance(v, (int, float)) and not isinstance(v, bool) and 0 <= v <= 1 and "prob" in key.lower():
        return f"{v:.0%}"
    return v


def _approve_buttons(action_id: str, key_prefix: str) -> None:
    c1, c2, _ = st.columns([1, 1, 3])
    if c1.button("Approve", key=f"{key_prefix}_ap_{action_id}", type="primary",
                 help="Human approval via SP_APPROVE_RECOVERY_ACTION"):
        ui.result_toast(rb.approve_action(action_id, True), f"Approved {action_id}")
        st.rerun()
    if c2.button("Reject", key=f"{key_prefix}_rj_{action_id}", help="Human rejection via SP_REJECT_RECOVERY_ACTION"):
        ui.result_toast(rb.approve_action(action_id, False), f"Rejected {action_id}")
        st.rerun()


def render_result(result: dict, idx: int) -> None:
    if result.get("error"):
        st.error(f"The agent call failed: {result['error']}")
        return
    trust = result.get("trust") or {}
    ui.trust_badge(trust)
    ans = result.get("answer")
    if not isinstance(ans, dict):
        st.markdown(result.get("text") or "_The agent returned no text._")
        st.caption(f"{len(result.get('tool_calls') or [])} queries · see Reasoning Trace")
        return

    ui.card(f'<div style="line-height:1.55">{ui.esc(ans.get("executive_summary", ""))}</div>')
    if ans.get("ml_second_opinion"):
        ui.md_html(f'<div class="raa-muted" style="margin:-4px 0 8px 2px;"><b style="color:{ui.CLAUDE_CLAY}">'
                   f'ML second opinion</b> · {ui.esc(ans["ml_second_opinion"])}</div>')
    for c in ans.get("caveats") or []:
        st.caption(f"⚠ {c}")

    passed = trust.get("status") == "PASSED"
    metrics = {k: v for k, v in (ans.get("metrics") or {}).items()
               if isinstance(v, (int, float)) and not isinstance(v, bool)}
    if metrics and passed:
        accents = [ui.SNOWFLAKE_BLUE, ui.CLAUDE_CLAY, ui.TEAL, ui.PURPLE, ui.GREEN]
        items = [(rb.PIN_LABELS.get(k, k.replace("_", " ").title()), _metric_value(k, v), accents[i % 5])
                 for i, (k, v) in enumerate(list(metrics.items())[:5])]
        ui.stat_row(items)
    elif metrics and not passed:
        st.caption("Figures are not shown as tiles because the trust check did not pass.")

    actions = ans.get("ranked_actions") or []
    if actions:
        ui.section_title("Ranked actions")
    for k, a in enumerate(actions[:6]):
        cat = a.get("category")
        tag = ui.estimate_tag() if a.get("needs_approval") else ""
        ui.md_html(f"""<div class="raa-action" style="--accent:{ui.category_color(cat)}">
<div style="display:flex;justify-content:space-between;gap:8px;align-items:center;">
<div>{ui.icon_svg(cat, 16)} <b>{ui.esc(ui.category_label(cat))}</b>{tag}</div>
<div title="{ui.exact_money(a.get('expected_recovery'))}" style="font-weight:700">{ui.fmt_money(a.get('expected_recovery'))}</div></div>
<div style="margin:4px 0 2px 0">{ui.esc(a.get('action', ''))}</div>
<div class="raa-muted">Owner: {ui.esc(a.get('owner') or '—')}</div></div>""")
        if a.get("action_id"):
            _approve_buttons(str(a["action_id"]), f"r{idx}_{k}")

    c1, c2 = st.columns([1, 2])
    if passed and c1.button("Save verified answer", key=f"save_{idx}",
                            help="Stores the question, answer and governed SQL in VERIFIED_ANSWERS"):
        ui.result_toast(rb.save_answer(result), "Answer saved")
        st.rerun()
    c2.caption(f"{len(result.get('tool_calls') or [])} queries · see Reasoning Trace")


# ----------------------------------------------------------------------------------------
# Insights panel renderers
# ----------------------------------------------------------------------------------------
def _outlook_row() -> dict:
    try:
        d = rb.load_outlook()
        return d.iloc[0].to_dict() if len(d) else {}
    except Exception:
        return {}


def draw_chart(cid: str, data, category: str | None) -> None:
    if cid == "outlook_card":
        o = data.iloc[0].to_dict() if isinstance(data, pd.DataFrame) and len(data) else {}
        ui.stat_row([("Q4 target", o.get("TARGET_USD"), ui.SNOWFLAKE_BLUE),
                     ("Plan forecast", o.get("PLAN_FORECAST_USD"), ui.SNOWFLAKE_BLUE_DEEP),
                     ("Forecast gap", o.get("GAP_USD"), ui.RED)])
        if o.get("ML_FORECAST_USD") is not None:
            prob = o.get("PROB_HIT_TARGET")
            st.caption(f"ML second opinion {ui.fmt_money(o.get('ML_FORECAST_USD'))} "
                       f"(P10 {ui.fmt_money(o.get('ML_P10_USD'))} – P90 {ui.fmt_money(o.get('ML_P90_USD'))})"
                       + (f" · chance of hitting target ≈ {float(prob):.0%}" if prob is not None and str(prob) != 'nan' else "")
                       + f" · {o.get('ML_METHOD') or ''}")
    elif cid == "forecast_vs_target":
        ui.render_forecast_vs_target(data)
    elif cid == "gap_drivers":
        ui.render_hbar(data, "SEGMENT", "GAP_CONTRIBUTION_USD", "What drives the gap (forecast − target)")
    elif cid == "policy_vs_ml_deals":
        d = data.head(10).copy() if isinstance(data, pd.DataFrame) else pd.DataFrame()
        if len(d):
            d["DEAL"] = d["CUSTOMER_NAME"].fillna(d["OPPORTUNITY_ID"]).astype(str).str.slice(0, 18)
        ui.render_comparison_chart(d, "DEAL", ["POLICY_PROB", "ML_WIN_PROB"], ["Governed probability", "ML win probability"],
                                   "Governed vs ML probability (top pipeline risks)", percent=True)
    elif cid == "gap_bridge":
        ui.render_waterfall(data, _outlook_row().get("TARGET_USD"))
    elif cid == "outcome_range":
        ui.render_range(data, _outlook_row().get("GAP_USD"))
    elif cid == "risk_by_category":
        ui.render_stacked_category(data, highlight=category)
    elif cid == "action_cards":
        ui.section_title("Top proposed actions", "Governed action board")
        if not isinstance(data, pd.DataFrame) or data.empty:
            st.caption("No proposed actions awaiting approval.")
        for _, r in (data.iterrows() if isinstance(data, pd.DataFrame) else []):
            ui.md_html(f"""<div class="raa-action" style="--accent:{ui.category_color(r.get('CATEGORY'))}">
<div style="display:flex;justify-content:space-between;"><b>{ui.esc(ui.category_label(r.get('CATEGORY')))} · {ui.esc(r.get('CUSTOMER_NAME') or '')}</b>
<span title="{ui.exact_money(r.get('EXPECTED_RECOVERY_USD'))}">{ui.fmt_money(r.get('EXPECTED_RECOVERY_USD'))}</span></div>
<div>{ui.esc(r.get('TITLE') or '')}</div><div class="raa-muted">Owner: {ui.esc(r.get('OWNER') or '—')} · due {ui.esc(r.get('DUE_DATE'))}</div></div>""")
            _approve_buttons(str(r["ACTION_ID"]), "ins")
    else:
        titles = {"early_warning": "ML early warning (not yet in the governed ledger)",
                  "fulfillment_plan": "Inventory optimiser: alternate-warehouse coverage",
                  "expansion": "Expansions threatened by support health",
                  "prevention_controls": "Proposed prevention controls (launch on the Action Board)",
                  "root_cause_briefs": "Root-cause briefs per category (AI_AGG)"}
        ui.section_title(titles.get(cid, cid.replace("_", " ").title()))
        ui.money_table(data if isinstance(data, pd.DataFrame) else pd.DataFrame(data or []))


# ----------------------------------------------------------------------------------------
# Layout
# ----------------------------------------------------------------------------------------
left, right = st.columns([45, 55], gap="large")
pending = state.pop("_pending_q", None)
typed = st.chat_input("Ask about Q4 revenue risk, recovery or actions…")
question = typed or pending

with left:
    if not state["results"] and not question:
        ui.card('<div class="raa-eyebrow">Start with a business question</div>'
                '<div class="raa-muted">The agent plans the analysis, queries governed data through Cortex Analyst, '
                'runs decision tools and verifies every dollar before you see it.</div>')
        for i, chip in enumerate(CHIPS):
            if st.button(chip, key=f"chip_{i}", use_container_width=True):
                state["_pending_q"] = chip
                st.rerun()

    for i, res in enumerate(state["results"]):
        with st.chat_message("user"):
            st.markdown(res.get("question", ""))
        with st.chat_message("assistant", avatar="❄️"):
            render_result(res, i)

    if question:
        with st.chat_message("user"):
            st.markdown(question)
        with st.chat_message("assistant", avatar="❄️"):
            stepper = ui.Stepper()
            result = rb.ask_agent(question, state["history"], on_stage=stepper.set)
            stepper.finish()
            stepper.clear()
            state["history"] += [
                {"role": "user", "content": [{"type": "text", "text": question}]},
                {"role": "assistant", "content": [{"type": "text", "text": result.get("text") or result.get("error") or ""}]},
            ]
            state["results"].append(result)
            state["last_result"] = result
            rb.update_pins(result, len(state["results"]))
            render_result(result, len(state["results"]) - 1)

with right:
    ui.section_title("Insights", "Governed charts for the current answer")
    ui.pin_row(state.get("pins"))
    last = state.get("last_result")
    if not last:
        ui.card('<div style="font-weight:700;margin-bottom:6px;">Charts appear here as you ask</div>'
                '<div class="raa-muted">Every chart is drawn from governed Snowflake tables selected by the tools '
                'and SQL the agent actually used, never from numbers in the model\'s text.</div>', "dashed")
    else:
        ids, category = rb.charts_for(last)
        if not ids:
            st.caption("No governed chart applies to this answer.")
        for cid in ids:
            with st.container(border=True):
                try:
                    draw_chart(cid, rb.CHART_QUERIES[cid](), category)
                except Exception as e:      # never crash the page on one chart
                    st.warning(f"{cid}: {str(e)[:200]}")
