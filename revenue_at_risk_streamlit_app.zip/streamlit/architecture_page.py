"""Page 5 - Architecture: how the Revenue Recovery Agent turns governed data into decisions."""
from __future__ import annotations

import streamlit as st

import rr_backend as rb
import ui_common as ui

ui.show_flash()
ui.brand_header("Architecture", "Snowflake computes the financial truth · Claude reasons over it · humans decide")

# Live governed counts for step 1 (cached; falls back to text if unavailable)
try:
    recon = rb.load_reconciliation()
    ledger_fact = (f"{ui.fmt_money(recon['AT_RISK_USD'].sum())} at risk, {ui.fmt_money(recon['RECOVERABLE_USD'].sum())} "
                   f"recoverable, {int(recon['ITEMS'].sum())} items across {len(recon)} categories")
except Exception:
    ledger_fact = "gross revenue at risk, recoverable value and item counts per category"

STEPS = [
    ("Governed risk ledger",
     f"RR_RISK_LEDGER holds one row per at-risk item from five deterministic SQL mechanisms (pipeline, fulfillment, "
     f"billing, renewal, support/expansion), with lineage query ids and row hashes ({ledger_fact}). The same rules back "
     f"the semantic view's verified queries."),
    ("Semantic view + Cortex Analyst",
     "RR_REVENUE_RISK_SEMANTIC gives one definition of at risk and recoverable. Claude writes governed SQL against it "
     "through Cortex Analyst, guided by 12 verified queries."),
    ("Snowflake ML second opinion",
     "CLASSIFICATION (deal win probability vs governed probability), ANOMALY_DETECTION (usage drops), FORECAST "
     "(monthly revenue, shipments, demand) and TOP_INSIGHTS (gap drivers) — with statistical fallbacks. ML never "
     "overwrites governed values."),
    ("Cortex AI enrichment",
     "AI_CLASSIFY assigns a blocker class; AI_COMPLETE with Claude Opus 5.5 picks a play, owner and first step for each "
     "item; AI_AGG writes category briefs. Only rows whose evidence hash changed are sent to the model."),
    ("Decision tools",
     "Monte Carlo recovery simulation, inventory optimiser (alternate-warehouse allocation without double counting), "
     "gap-closure planner and prevention planner — governed procedures the agent calls as tools."),
    ("Trust check + governed write-back",
     "Every $ figure in an answer is matched to tool evidence and the governed trust check (reconciliation, lineage, "
     "AI-did-not-alter-money) must pass. Actions change only through approval procedures, each logged in AGENT_ACTIONS."),
]

for i, (title, body) in enumerate(STEPS, 1):
    ui.md_html(f"""<div class="raa-card" style="display:flex;align-items:flex-start;">
<span class="raa-num" aria-hidden="true">{i}</span>
<div><div style="font-weight:700;font-size:1.02rem;margin-bottom:4px;">{ui.esc(title)}</div>
<div class="raa-muted" style="line-height:1.55;">{ui.esc(body)}</div></div></div>""")

ui.card(f"""<div style="font-weight:700;font-size:1.02rem;margin-bottom:6px;color:{ui.CLAUDE_CLAY}">
Why governed modules plus an agent beat free-form text-to-SQL for a CFO decision</div>
<div class="raa-muted" style="line-height:1.6;">Free-form text-to-SQL re-derives "revenue at risk" on every question, so two
phrasings can give two answers and nobody can audit which rule produced a dollar. Here the money is computed once by
reviewed SQL, reconciled and hashed; ML and Claude add a second opinion and reasoning on top but cannot change a number;
the trust check proves it; and nothing is committed without a named human approval. The agent's job is to investigate,
explain and recommend — the CFO's numbers stay the same no matter how the question is asked.</div>""", "dashed")

st.caption("Surfaces: this Command Center (Streamlit) · Snowflake CoWork (same agent, markdown answers) · "
           "Claude Desktop via the managed MCP server · CoCo for engineering.")
