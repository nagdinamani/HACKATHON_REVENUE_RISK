"""Page 3 - Action Board: governed write-back (approve / reject / start / done, prevention controls, audit trail)."""
from __future__ import annotations

import pandas as pd
import streamlit as st

import rr_backend as rb
import ui_common as ui

ESTIMATE_LEVERS = {"RENEWAL_SAVE", "SUPPORT_RECOVERY"}     # modeled, outside the governed base scenario
ARR_CATEGORIES = {"RENEWAL"}

ui.show_flash()
ui.brand_header("Action Board", "Human-in-the-loop write-back · every change goes through a governed procedure and AGENT_ACTIONS")


def _write(res: dict, ok_text: str) -> None:
    ui.result_toast(res, ok_text)
    st.rerun()


# ----------------------------------------------------------------------------------------
# Sidebar admin
# ----------------------------------------------------------------------------------------
with st.sidebar:
    with st.expander("Admin", expanded=False):
        st.caption("Rebuilds the decision layer, incremental AI enrichment, planners, proposals and trust check.")
        if st.button("Rebuild analytics", use_container_width=True):
            with st.spinner("Rebuilding governed analytics…"):
                res = rb.refresh_analytics()
            ui.flash(res.get("message") or res.get("error") or "Done", bool(res.get("ok")))
            st.session_state["_show_refresh_log"] = True
            st.rerun()
        if st.session_state.get("_show_refresh_log"):
            try:
                st.dataframe(rb.load_refresh_log(), hide_index=True, use_container_width=True)
            except Exception as e:
                st.caption(f"Refresh log unavailable: {str(e)[:160]}")

# ----------------------------------------------------------------------------------------
# Progress vs gap
# ----------------------------------------------------------------------------------------
try:
    prog = rb.load_approved_vs_gap()
    board = rb.load_action_board()
except Exception as e:
    st.error(f"Could not load the action board: {str(e)[:300]}")
    st.stop()

gap = float(prog.get("GAP_USD") or 0)
approved = float(prog.get("APPROVED_Q4_USD") or 0)
share = min(approved / gap, 1.0) if gap else 0.0
ui.card(f"""<div style="display:flex;justify-content:space-between;align-items:baseline;">
<div><div class="raa-eyebrow">Approved recovery vs forecast gap</div>
<div style="font-size:1.4rem;font-weight:800" title="{ui.exact_money(approved)} of {ui.exact_money(gap)}">{ui.fmt_money(approved)} of {ui.fmt_money(gap)} approved</div></div>
<div class="raa-muted" style="text-align:right">+ {ui.fmt_money(prog.get('APPROVED_ARR_USD'))} ARR approved (renewals, not Q4 revenue)<br>
{ui.fmt_money(prog.get('DONE_Q4_USD'))} done · {ui.fmt_money(prog.get('PROPOSED_USD'))} awaiting approval</div></div>
<div class="raa-progress" style="margin-top:10px;" role="progressbar" aria-valuenow="{share * 100:.0f}" aria-valuemin="0" aria-valuemax="100">
<div style="width:{share * 100:.1f}%"></div></div>""")

# ----------------------------------------------------------------------------------------
# Filters
# ----------------------------------------------------------------------------------------
statuses = ["ALL", "PROPOSED", "APPROVED", "IN_PROGRESS", "DONE", "REJECTED"]
levers = ["ALL"] + sorted(board["LEVER_TYPE"].dropna().unique().tolist()) if len(board) else ["ALL"]
f1, f2 = st.columns(2)
_chip = getattr(st, "pills", None)
with f1:
    status = (_chip("Status", statuses, default="ALL", key="ab_status") if _chip
              else st.radio("Status", statuses, horizontal=True, key="ab_status")) or "ALL"
with f2:
    lever = (_chip("Lever", levers, default="ALL", key="ab_lever") if _chip
             else st.radio("Lever", levers, horizontal=True, key="ab_lever")) or "ALL"

view = board.copy()
if status != "ALL":
    view = view[view["STATUS"] == status]
if lever != "ALL":
    view = view[view["LEVER_TYPE"] == lever]

ui.section_title(f"Recovery actions ({len(view)})")
if view.empty:
    ui.card('<div class="raa-muted">No actions match these filters.</div>')

for _, r in view.iterrows():
    aid, st_, cat = str(r["ACTION_ID"]), str(r["STATUS"]), r.get("CATEGORY")
    tag = ui.estimate_tag() if r.get("LEVER_TYPE") in ESTIMATE_LEVERS else ""
    arr = ' <span class="raa-muted">ARR</span>' if cat in ARR_CATEGORIES else ""
    decided = f" · decided by {ui.esc(r.get('DECISION_BY'))}" if r.get("DECISION_BY") else ""
    with st.container(border=True):
        info, act = st.columns([5, 2])
        with info:
            ui.md_html(f"""<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
{ui.icon_svg(cat, 16)} <b>{ui.esc(r.get('TITLE') or '')}</b> {ui.pill(st_)}{tag}</div>
<div class="raa-muted" style="margin-top:4px;">{ui.esc(ui.category_label(cat))} · {ui.esc(r.get('CUSTOMER_NAME') or '—')} ·
owner {ui.esc(r.get('OWNER') or '—')} · due {ui.esc(r.get('DUE_DATE'))}{decided}</div>
<div style="margin-top:4px;">First step: {ui.esc(r.get('FIRST_STEP') or '—')}</div>""")
        with act:
            ui.md_html(f'<div style="text-align:right;font-size:1.25rem;font-weight:800" '
                       f'title="{ui.exact_money(r.get("EXPECTED_RECOVERY_USD"))}">{ui.fmt_money(r.get("EXPECTED_RECOVERY_USD"))}{arr}</div>'
                       f'<div class="raa-muted" style="text-align:right">expected recovery</div>')
            if st_ == "PROPOSED":
                b1, b2 = st.columns(2)
                if b1.button("Approve", key=f"ab_ap_{aid}", type="primary", use_container_width=True):
                    _write(rb.approve_action(aid, True), f"Approved {aid}")
                if b2.button("Reject", key=f"ab_rj_{aid}", use_container_width=True):
                    _write(rb.approve_action(aid, False), f"Rejected {aid}")
            elif st_ == "APPROVED":
                if st.button("Start", key=f"ab_st_{aid}", type="primary", use_container_width=True):
                    _write(rb.update_action_status(aid, "IN_PROGRESS"), f"Started {aid}")
            elif st_ == "IN_PROGRESS":
                if st.button("Done", key=f"ab_dn_{aid}", type="primary", use_container_width=True):
                    _write(rb.update_action_status(aid, "DONE"), f"Completed {aid}")

# ----------------------------------------------------------------------------------------
# Prevention controls
# ----------------------------------------------------------------------------------------
ui.section_title("Prevention controls", "So this does not happen again next quarter")
try:
    controls = rb.CHART_QUERIES["prevention_controls"]()
except Exception as e:
    controls = pd.DataFrame()
    st.caption(f"Prevention plan unavailable: {str(e)[:160]}")
if controls is None or controls.empty:
    ui.card('<div class="raa-muted">No prevention controls proposed yet (the planner runs with action proposals).</div>')
for _, c in (controls.iterrows() if controls is not None else []):
    cid = str(c["CONTROL_ID"])
    with st.container(border=True):
        i1, i2 = st.columns([5, 2])
        with i1:
            ui.md_html(f"""<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">{ui.icon_svg(c.get('CATEGORY'), 16)}
<b>{ui.esc(c.get('CONTROL_NAME'))}</b> {ui.pill(c.get('STATUS'))}</div>
<div class="raa-muted" style="margin-top:4px;">{ui.esc(c.get('RATIONALE'))}</div>
<div class="raa-muted">Owner {ui.esc(c.get('OWNER'))}{' · review ' + ui.esc(c.get('REVIEW_DATE')) if c.get('REVIEW_DATE') is not None and str(c.get('REVIEW_DATE')) not in ('NaT', 'None') else ''}</div>""")
        with i2:
            ui.md_html(f'<div style="text-align:right;font-weight:700" title="{ui.exact_money(c.get("EST_PREVENTABLE_USD"))}">'
                       f'{ui.fmt_money(c.get("EST_PREVENTABLE_USD"))}</div>'
                       f'<div style="text-align:right">{ui.estimate_tag()}</div>')
            if c.get("STATUS") == "PROPOSED" and st.button("Launch", key=f"pc_{cid}", type="primary", use_container_width=True):
                _write(rb.launch_control(cid), f"Launched {cid}")

# ----------------------------------------------------------------------------------------
# Audit trail
# ----------------------------------------------------------------------------------------
with st.expander("Trail", expanded=False):
    try:
        st.dataframe(rb.load_table("V_AGENT_AUDIT", "ACTED_AT DESC"), hide_index=True, use_container_width=True)
    except Exception as e:
        st.caption(f"Audit trail unavailable: {str(e)[:160]}")
