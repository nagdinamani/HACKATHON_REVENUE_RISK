"""rr_backend.py - the only module the Streamlit pages use to talk to Snowflake.

Pages never write SQL themselves. Everything goes through:
  ask_agent()          Cortex Agent (Claude Opus 5.5 + Cortex Analyst + decision tools)
  trust_check()        every $ figure in the answer must exist in the tool results (+ governed data trust)
  update_pins()        pinned facts from trust-checked answers
  charts_for()         which governed charts to draw for an answer (deterministic)
  load_*()             governed tables for charts, tables and the Action board
  approve_action() ... governed write-back procedures (each writes an AGENT_ACTIONS audit row)

Runs in Streamlit in Snowflake (warehouse runtime). Packages: streamlit, snowflake-snowpark-python, pandas, plotly.

ADAPTED to the Revenue Recovery build in HACKATHON_REVENUE_RISK.SOLUTION
--------------------------------------------------------------------------
Public API (function names, signatures, return shapes, CHART_QUERIES ids, STAGES,
PIN_LABELS) is unchanged from the provided module so the pages follow UI_PROMPT.md.
Internals now target the SOLUTION decision layer instead of the DEMO views:
  * No database views: the former V_* "views" are read-only SELECTs defined in
    LOGICAL_VIEWS below, over RR_* decision tables.
  * Agent = RR_REVENUE_RECOVERY_APP_AGENT (JSON-contract twin of the CoWork agent).
  * Write-back = SP_APPROVE_RECOVERY_ACTION / SP_REJECT_RECOVERY_ACTION /
    SP_UPDATE_ACTION_STATUS / SP_LAUNCH_PLANNED_CONTROL / SP_SAVE_VERIFIED_ANSWER /
    SP_REFRESH_ANALYTICS.
  * trust_check() runs in Python (no RR_TRUST_CHECK UDF) and also requires the
    latest governed SP_RR_TRUST_CHECK status to be PASS.
"""
from __future__ import annotations

import json
import re
from typing import Any, Callable

import pandas as pd
import streamlit as st

# ----------------------------------------------------------------------------------------
# Configuration
# ----------------------------------------------------------------------------------------
DATABASE = "HACKATHON_REVENUE_RISK"
SCHEMA = "SOLUTION"
AGENT_DATABASE = "HACKATHON_REVENUE_RISK"     # SHOW AGENTS IN SCHEMA HACKATHON_REVENUE_RISK.SOLUTION
AGENT_SCHEMA = "SOLUTION"
AGENT_NAME = "RR_REVENUE_RECOVERY_APP_AGENT"  # JSON-contract twin created by 15_STREAMLIT_APP_SUPPORT.sql
WAREHOUSE = "RR_WH"
SURFACE = "COMMAND_CENTER"
AGENT_TIMEOUT_MS = 180_000
FQ = f"{DATABASE}.{SCHEMA}"

STAGES = ["Planning the analysis", "Querying governed data (Cortex Analyst)",
          "Running decision tools", "Synthesizing the answer"]

CATEGORIES = ["PIPELINE", "FULFILLMENT", "BILLING", "RENEWAL", "SUPPORT_EXPANSION"]
LEVER_BY_CATEGORY = {"PIPELINE": "DEAL_ACCELERATION", "FULFILLMENT": "INVENTORY_TRANSFER",
                     "BILLING": "BILLING_FIX", "RENEWAL": "RENEWAL_SAVE", "SUPPORT_EXPANSION": "SUPPORT_RECOVERY"}


# ----------------------------------------------------------------------------------------
# Session
# ----------------------------------------------------------------------------------------
@st.cache_resource
def get_session():
    from snowflake.snowpark.context import get_active_session
    s = get_active_session()
    try:
        s.sql(f"USE WAREHOUSE {WAREHOUSE}").collect()
    except Exception:
        pass
    return s


def _df(sql: str, params: list | None = None) -> pd.DataFrame:
    return get_session().sql(sql, params=params or []).to_pandas()


def _viewer() -> str:
    """Best-effort viewer identity (Streamlit in Snowflake runs queries with the owner's role)."""
    for attr in ("user", "experimental_user"):
        try:
            u = getattr(st, attr)
            for key in ("user_name", "email", "login_name"):
                v = u.get(key) if hasattr(u, "get") else getattr(u, key, None)
                if v:
                    return str(v)
        except Exception:
            continue
    return "unknown viewer"


# ----------------------------------------------------------------------------------------
# Lenient JSON parsing (same contract as ui_common.parse_answer)
# ----------------------------------------------------------------------------------------
def parse_answer(text: str | None) -> dict | None:
    """Return the answer JSON object or None. Never raises."""
    if not text:
        return None
    t = str(text).strip()
    for candidate in (t, re.sub(r"^```(?:json)?|```$", "", t, flags=re.M).strip()):
        try:
            v = json.loads(candidate)
            if isinstance(v, str):
                v = json.loads(v)
            if isinstance(v, dict):
                return v
        except Exception:
            pass
    i, j = t.find("{"), t.rfind("}")
    if i >= 0 and j > i:
        try:
            v = json.loads(t[i:j + 1])
            return v if isinstance(v, dict) else None
        except Exception:
            return None
    return None


# ----------------------------------------------------------------------------------------
# Agent call
# ----------------------------------------------------------------------------------------
def _post_agent(messages: list[dict]) -> Any:
    import _snowflake   # available in Streamlit in Snowflake (warehouse runtime)
    path = f"/api/v2/databases/{AGENT_DATABASE}/schemas/{AGENT_SCHEMA}/agents/{AGENT_NAME}:run"
    resp = _snowflake.send_snow_api_request("POST", path, {}, {}, {"messages": messages, "stream": False},
                                            None, AGENT_TIMEOUT_MS)
    if int(resp.get("status", 0)) != 200:
        raise RuntimeError(f"Agent call failed ({resp.get('status')}): {str(resp.get('content'))[:500]}")
    content = resp.get("content")
    return json.loads(content) if isinstance(content, str) else content


def _content_items(payload: Any) -> list[dict]:
    """Normalise the agent response to a flat list of content items.
    Handles a final message {role, content:[...]}, a {message:{...}} wrapper, and a list of SSE events."""
    if isinstance(payload, list):                                   # streamed events
        final = [e for e in payload if (e.get("event") or e.get("type")) == "response"]
        if final:
            return _content_items(final[-1].get("data", final[-1]))
        items = []
        for e in payload:
            d = e.get("data", e)
            ev = e.get("event") or e.get("type") or ""
            if ev.endswith("tool_use"):
                items.append({"type": "tool_use", "tool_use": d})
            elif ev.endswith("tool_result"):
                items.append({"type": "tool_result", "tool_result": d})
            elif ev == "response.text":
                items.append({"type": "text", "text": d.get("text", "")})
        return items
    if isinstance(payload, dict):
        if "content" in payload and isinstance(payload["content"], list):
            return payload["content"]
        for k in ("message", "response", "data"):
            if isinstance(payload.get(k), (dict, list)):
                return _content_items(payload[k])
    return []


def _find(obj: Any, keys: tuple[str, ...]) -> Any:
    """First value for any of keys anywhere in a nested JSON object."""
    if isinstance(obj, dict):
        for k in keys:
            if k in obj and obj[k] not in (None, ""):
                return obj[k]
        for v in obj.values():
            r = _find(v, keys)
            if r is not None:
                return r
    elif isinstance(obj, list):
        for v in obj:
            r = _find(v, keys)
            if r is not None:
                return r
    return None


def _rows_from(obj: Any) -> list[dict] | None:
    """Result rows from an Analyst result_set ({data, resultSetMetaData.rowType}) if present."""
    rs = _find(obj, ("result_set", "resultSet"))
    if isinstance(rs, dict) and isinstance(rs.get("data"), list):
        cols = [c.get("name") for c in (rs.get("resultSetMetaData", {}) or {}).get("rowType", [])]
        if cols:
            return [dict(zip(cols, r)) for r in rs["data"]]
    return None


def _tool_payload(result_body: dict) -> Any:
    """Tool result content: JSON items, or text items that contain JSON (our SP tools return JSON text)."""
    out = []
    for c in (result_body.get("content") or []):
        if not isinstance(c, dict):
            continue
        if c.get("type") == "json":
            out.append(c.get("json"))
        elif c.get("type") == "text":
            parsed = parse_answer(c.get("text"))
            out.append(parsed if parsed is not None else c.get("text"))
    if not out:
        return None
    return out[0] if len(out) == 1 else out


def run_readonly_sql(sql: str, limit: int = 500) -> pd.DataFrame:
    """Re-run an Analyst SQL statement for the Trace page. Only SELECT / WITH is allowed."""
    s = sql.strip().rstrip(";")
    if not re.match(r"(?is)^\s*(select|with)\b", s) or re.search(r"(?is)\b(insert|update|delete|merge|create|drop|alter|grant|call)\b", s):
        raise ValueError("Only read-only SELECT statements are allowed here.")
    get_session().sql(f"USE SCHEMA {FQ}").collect()
    return get_session().sql(f"SELECT * FROM ({s}) LIMIT {int(limit)}").to_pandas()


def ask_agent(question: str, history: list[dict] | None = None,
              on_stage: Callable[[int], None] | None = None) -> dict:
    """Ask the Cortex Agent. Returns
    {question, text, answer (dict|None), tool_calls:[{name, kind, input, sql, rows, json, status, error}],
     trust, error}"""
    def stage(i):
        if on_stage:
            on_stage(i)

    messages = list(history or []) + [{"role": "user", "content": [{"type": "text", "text": question}]}]
    out = {"question": question, "text": "", "answer": None, "tool_calls": [], "trust": None, "error": None}
    stage(0)
    try:
        payload = _post_agent(messages)
    except Exception as e:
        out["error"] = str(e)
        return out

    uses, results, texts = {}, [], []
    for it in _content_items(payload):
        typ = it.get("type")
        body = it.get(typ, it) if isinstance(it.get(typ), dict) else it
        if typ == "tool_use":
            uses[body.get("tool_use_id") or body.get("id") or str(len(uses))] = body
        elif typ == "tool_result":
            results.append(body)
        elif typ == "text":
            texts.append(it.get("text") or body.get("text", ""))

    stage(1)
    for r in results:
        use = uses.get(r.get("tool_use_id"), {})
        name = r.get("name") or use.get("name") or "tool"
        j = _tool_payload(r)
        sql = _find(j, ("sql", "SQL"))
        kind = "analyst" if sql else "decision_tool"
        rows = _rows_from(j)
        call = {"name": name, "kind": kind, "input": use.get("input"), "sql": sql, "rows": rows, "json": j,
                "status": r.get("status", "success"), "error": _find(j, ("error",)) if r.get("status") == "error" else None}
        if sql and rows is None:
            try:
                call["rows"] = run_readonly_sql(sql).to_dict("records")
            except Exception as e:
                call["error"] = call["error"] or str(e)[:300]
        out["tool_calls"].append(call)
    if any(c["kind"] == "decision_tool" for c in out["tool_calls"]):
        stage(2)
    stage(3)
    out["text"] = "\n".join(t for t in texts if t).strip()
    out["answer"] = parse_answer(out["text"])
    out["trust"] = trust_check(out)
    return out


# ----------------------------------------------------------------------------------------
# Trust check: every dollar figure in the answer must exist in the tool results,
# and the governed data trust check (SP_RR_TRUST_CHECK) must currently PASS.
# ----------------------------------------------------------------------------------------
def _answer_text_for_check(result: dict) -> str:
    a = result.get("answer")
    if not isinstance(a, dict):
        return result.get("text", "")
    parts = [str(a.get("executive_summary", ""))]
    for k, v in (a.get("metrics") or {}).items():
        if isinstance(v, (int, float)) and abs(v) > 1:          # numbers become $ claims (probabilities are skipped)
            parts.append(f"{k} ${v:.2f}")
    for rc in a.get("root_causes") or []:
        if isinstance(rc.get("at_risk_amount"), (int, float)):
            parts.append(f"${rc['at_risk_amount']:.2f}")
    for ra in a.get("ranked_actions") or []:
        parts.append(str(ra.get("action", "")))
        if isinstance(ra.get("expected_recovery"), (int, float)):
            parts.append(f"${ra['expected_recovery']:.2f}")
    return " ".join(parts)


_MONEY = re.compile(r"\$\s?(-?\d[\d,]*(?:\.\d+)?)\s*(billion|million|thousand|[BMK](?![A-Za-z]))?", re.I)
_UNIT = {"b": 1e9, "billion": 1e9, "m": 1e6, "million": 1e6, "k": 1e3, "thousand": 1e3}


def _money_claims(text: str) -> list[tuple[str, float, float]]:
    """[(raw, value_usd, tolerance_usd)] — tolerance = half of the last displayed digit."""
    out = []
    for m in _MONEY.finditer(text or ""):
        num, unit = m.group(1).replace(",", ""), (m.group(2) or "").lower()
        try:
            v = float(num)
        except ValueError:
            continue
        mult = _UNIT.get(unit, 1.0)
        decimals = len(num.split(".")[1]) if "." in num else 0
        tol = max(1.0, 0.5 * (10 ** -decimals) * mult) if mult > 1 else 1.0
        if abs(v * mult) >= 1000:                       # ignore tiny amounts
            out.append((m.group(0).strip(), v * mult, tol))
    return out


def _evidence_numbers(obj: Any, acc: list[float]) -> list[float]:
    if isinstance(obj, bool) or obj is None:
        return acc
    if isinstance(obj, (int, float)):
        acc.append(float(obj))
    elif isinstance(obj, str):
        try:
            acc.append(float(obj.replace(",", "")))
        except ValueError:
            for _, v, _t in _money_claims(obj):
                acc.append(v)
    elif isinstance(obj, dict):
        for v in obj.values():
            _evidence_numbers(v, acc)
    elif isinstance(obj, list):
        for v in obj:
            _evidence_numbers(v, acc)
    return acc


@st.cache_data(ttl=60, show_spinner=False)
def _data_trust_status() -> str:
    try:
        d = _df(f"SELECT MAX_BY(STATUS, ENDED_AT) AS S FROM {FQ}.RR_REFRESH_AUDIT WHERE STAGE = 'TRUST'")
        return str(d.iloc[0, 0]) if len(d) and d.iloc[0, 0] is not None else "NOT_RUN"
    except Exception:
        return "UNKNOWN"


def trust_check(result: dict) -> dict:
    evidence = [c.get("rows") or c.get("json") for c in result.get("tool_calls", [])]
    try:
        nums = _evidence_numbers(evidence, [])
        claims = _money_claims(_answer_text_for_check(result))
        unverified = [raw for raw, v, tol in claims if not any(abs(v - e) <= tol for e in nums)]
        data_trust = _data_trust_status()
        if data_trust == "FAIL":
            status = "FLAGGED"
        elif unverified:
            status = "FLAGGED"
        else:
            status = "PASSED"
        return {"status": status, "dollar_values_checked": len(claims),
                "verified": len(claims) - len(unverified), "unverified": unverified[:12],
                "data_trust": data_trust,
                "method": "Each $ figure in the answer matched to tool-result evidence (rounding-aware); "
                          "governed SP_RR_TRUST_CHECK must not be FAIL."}
    except Exception as e:
        return {"status": "UNCHECKED", "dollar_values_checked": 0, "unverified": [], "error": str(e)[:200]}


# ----------------------------------------------------------------------------------------
# Pinned facts (top of the Insights panel); only from PASSED answers
# ----------------------------------------------------------------------------------------
PIN_LABELS = {"target": "Q4 target", "forecast": "Forecast", "gap": "Gap", "at_risk": "At risk",
              "recoverable": "Recoverable", "no_path": "No path today", "ml_forecast": "ML forecast",
              "planned_recovery": "Planned vs gap"}


def update_pins(result: dict, q_no: int) -> dict:
    pins = st.session_state.setdefault("pins", {})
    a = result.get("answer") or {}
    if (result.get("trust") or {}).get("status") != "PASSED":
        return pins
    for k, v in (a.get("metrics") or {}).items():
        if k in PIN_LABELS and isinstance(v, (int, float)):
            pins[PIN_LABELS[k]] = {"value": v, "q": f"Q{q_no}"}
    return pins


# ----------------------------------------------------------------------------------------
# Which governed charts to draw for an answer (deterministic, not model-chosen)
# Matched against tool names, the Analyst SQL and the question text.
# ----------------------------------------------------------------------------------------
CHART_RULES = [  # (pattern, chart ids) — most specific first; at most 4 charts are drawn
    (r"GapClosurePlan|RR_GAP_PLAN|RecoveryScenario|close the rest|closing the gap", ["gap_bridge", "outcome_range"]),
    (r"RecoverySimulation|confidence|probability of closing", ["outcome_range"]),
    (r"PreventionPlan|RR_PREVENTION_PLAN|prevent|does not happen again|next quarter", ["prevention_controls"]),
    (r"RR_ML_DEAL_SCORES|ML_GOVERNED_DELTA|ml_vs_governed|ml_second_opinion_score|ML disagree", ["policy_vs_ml_deals"]),
    (r"RR_FULFILLMENT_ALLOCATION|RECOVERY_PATH|recovery_route|warehouse", ["fulfillment_plan"]),
    (r"HEALTH_DETERIORATING|ML_USAGE_ANOMALY|RR_ML_USAGE_ANOMALIES|deteriorating|early warning", ["early_warning"]),
    (r"SUPPORT_EXPANSION|AT_RISK_EXPANSION|expansion", ["expansion"]),
    (r"RecoveryActions|RR_RECOVERY_ACTIONS|recommended_action", ["action_cards"]),
    (r"RR_ML_GAP_DRIVERS|gap driver", ["gap_drivers"]),
    (r"ExecutiveSnapshot|RR_REVENUE_OUTLOOK|FACT_REVENUE_PLAN|RR_ML_PLAN_FORECAST|outlook", ["outlook_card", "forecast_vs_target"]),
    (r"RR_RISK_LEDGER|RevenueRiskAnalyst|ExecutiveSnapshot|at risk", ["risk_by_category"]),
    (r"DeepRevenueReasoning|RR_AI_CATEGORY_BRIEFS|blocker", ["root_cause_briefs"]),
]
CATEGORY_HINTS = {"PIPELINE": r"'PIPELINE'|FACT_OPPORTUNITY|pipeline|late-stage|deals?\b",
                  "FULFILLMENT": r"'FULFILLMENT'|RR_FULFILLMENT_ALLOCATION|fulfil|warehouse|shortage",
                  "BILLING": r"'BILLING'|FACT_BILLING|billing|invoice",
                  "RENEWAL": r"'RENEWAL'|RENEWAL_ARR|renewal",
                  "SUPPORT_EXPANSION": r"'SUPPORT_EXPANSION'|AT_RISK_EXPANSION_VALUE|expansion|support issues"}


def charts_for(result: dict) -> tuple[list[str], str | None]:
    """Return (chart ids, highlighted category) from the tools and SQL the agent used and the question."""
    blob = " ".join(f"{c.get('name', '')} {c.get('sql') or ''}" for c in result.get("tool_calls", []))
    blob = f"{blob} {result.get('question') or ''}"
    ids: list[str] = []
    for pat, cids in CHART_RULES:
        if re.search(pat, blob, flags=re.I):
            ids += [c for c in cids if c not in ids]
    hits = [k for k, pat in CATEGORY_HINTS.items() if re.search(pat, blob, flags=re.I)]
    return ids[:4], (hits[0] if len(hits) == 1 else None)


# ----------------------------------------------------------------------------------------
# Logical read-only "views" (SELECTs over decision tables; nothing is created in Snowflake)
# ----------------------------------------------------------------------------------------
_LEVER_SQL = ("CASE a.CATEGORY WHEN 'PIPELINE' THEN 'DEAL_ACCELERATION' WHEN 'FULFILLMENT' THEN 'INVENTORY_TRANSFER' "
              "WHEN 'BILLING' THEN 'BILLING_FIX' WHEN 'RENEWAL' THEN 'RENEWAL_SAVE' ELSE 'SUPPORT_RECOVERY' END")

LOGICAL_VIEWS = {
    "V_ACTION_BOARD": f"""
        SELECT a.ACTION_ID, a.PRIORITY_RANK, a.CATEGORY, {_LEVER_SQL} AS LEVER_TYPE, a.ACTION_TEXT AS TITLE,
               a.CUSTOMER_NAME, a.OWNER_ROLE AS OWNER, a.FIRST_STEP, a.EXPECTED_RECOVERY_USD, a.DUE_DATE, a.STATUS,
               a.ACTION_SOURCE, a.DECISION_BY, a.DECISION_TIME, a.NOTES, a.RISK_ITEM_ID,
               l.BLOCKER, l.AI_SUMMARY, l.VALUE_BASIS, l.AT_RISK_USD, l.RECOVERY_PATH
        FROM {FQ}.RR_RECOVERY_ACTIONS a
        LEFT JOIN {FQ}.RR_RISK_LEDGER l ON l.RISK_ITEM_ID = a.RISK_ITEM_ID
        WHERE a.STATUS <> 'SUPERSEDED'""",
    "V_ACTION_RANKING": f"""
        SELECT a.ACTION_ID, a.PRIORITY_RANK, a.CATEGORY, {_LEVER_SQL} AS LEVER_TYPE, a.ACTION_TEXT AS TITLE,
               a.CUSTOMER_NAME, a.OWNER_ROLE AS OWNER, a.EXPECTED_RECOVERY_USD, a.DUE_DATE, a.STATUS
        FROM {FQ}.RR_RECOVERY_ACTIONS a WHERE a.STATUS IN ('PROPOSED', 'APPROVED', 'IN_PROGRESS')""",
    "V_AGENT_AUDIT": f"""
        SELECT ACTED_AT, ACTOR, ACTOR_ROLE, SURFACE, ACTION_TYPE, TARGET_OBJECT, TARGET_ID, TO_VARCHAR(PAYLOAD) AS PAYLOAD
        FROM {FQ}.AGENT_ACTIONS WHERE SURFACE LIKE 'RR_%' OR SURFACE = '{SURFACE}'""",
    "V_EARLY_WARNING": f"""
        SELECT CUSTOMER_NAME, REGION_NAME, RENEWAL_DATE, RENEWAL_ARR, USAGE_AVG_LAST_4W, USAGE_AVG_PRIOR_8W, CSAT,
               OPEN_P1_P2, ML_ANOMALY_SCORE, ML_ANOMALY_METHOD, LEDGER_AT_RISK_USD,
               IFF(LEDGER_ITEM_COUNT > 0, 'IN RISK LEDGER', 'NEW - ML EARLY WARNING') AS STATUS
        FROM {FQ}.RR_CUSTOMER_360 WHERE HEALTH_DETERIORATING_FLAG OR ML_USAGE_ANOMALY_FLAG""",
    "RR_FULFILLMENT_PLAN": f"""
        SELECT f.ORDER_ID, l.CUSTOMER_NAME, l.PRODUCT_NAME, f.SOURCE_WAREHOUSE, f.ALTERNATE_WAREHOUSE, f.REQUIRED_QTY,
               f.BOOKED_VALUE, f.COVERED_FLAG, f.PROMISED_DATE, f.REASON
        FROM {FQ}.RR_FULFILLMENT_ALLOCATION f
        LEFT JOIN {FQ}.RR_RISK_LEDGER l ON l.RISK_ITEM_ID = 'FUL-' || f.ORDER_ID""",
    "V_EXPANSION_CANDIDATES": f"""
        SELECT CUSTOMER_NAME, REGION_NAME, BLOCKER, AT_RISK_USD, RECOVERABLE_USD AS EXPECTED_IN_QTR_USD, RECOVERY_PROB,
               AI_NEXT_BEST_ACTION, AI_OWNER_ROLE
        FROM {FQ}.RR_RISK_LEDGER WHERE ACTIVE_FLAG AND CATEGORY = 'SUPPORT_EXPANSION'""",
    "RR_PREVENTION_PLAN": f"""
        SELECT CONTROL_ID, CATEGORY, RISK_CLASS, CONTROL_NAME, OWNER, ITEMS, EST_PREVENTABLE_USD, STATUS,
               RATIONALE, REVIEW_DATE, LAUNCHED_BY, LAUNCHED_AT
        FROM {FQ}.RR_PREVENTION_PLAN WHERE STATUS IN ('PROPOSED', 'LAUNCHED')""",
    "RR_AI_CATEGORY_BRIEF": f"""
        SELECT CATEGORY, ITEM_COUNT, BRIEF, GENERATED_AT FROM {FQ}.RR_AI_CATEGORY_BRIEFS""",
    "RR_GAP_PLAN_ITEMS": f"""
        SELECT CATEGORY, RISK_ITEM_ID, CUSTOMER_NAME, AT_RISK_USD, RECOVERABLE_USD, RECOVERY_PROB, DUE_DATE, BLOCKER
        FROM {FQ}.RR_RISK_LEDGER WHERE ACTIVE_FLAG""",
    "RR_REFRESH_LOG": f"""
        SELECT RUN_ID, STAGE AS STEP, STATUS, DATEDIFF(second, STARTED_AT, ENDED_AT) AS SECONDS, STARTED_AT, ENDED_AT
        FROM {FQ}.RR_REFRESH_AUDIT""",
}


# ----------------------------------------------------------------------------------------
# Governed data loaders (charts, tables, Overview page, Action board)
# ----------------------------------------------------------------------------------------
_OUTLOOK_SQL = f"""
    WITH m AS (
      SELECT SUM(ML_FORECAST_USD) AS F, SUM(ML_P10_USD) AS P10, SUM(ML_P90_USD) AS P90,
             SQRT(SUM(POWER((ML_P90_USD - ML_P10_USD) / 2.5631, 2))) AS SD, ANY_VALUE(ML_METHOD) AS M
      FROM {FQ}.RR_ML_PLAN_FORECAST),
    t AS (SELECT MAX_BY(STATUS, ENDED_AT) AS TS FROM {FQ}.RR_REFRESH_AUDIT WHERE STAGE = 'TRUST')
    SELECT o.AS_OF_DATE, o.QTR_START, o.QTR_END,
           o.Q4_TARGET_USD AS TARGET_USD, o.Q4_FORECAST_USD AS PLAN_FORECAST_USD, o.Q4_FORECAST_USD AS FORECAST_USD,
           o.FORECAST_GAP_USD AS GAP_USD, o.GROSS_AT_RISK_USD AS AT_RISK_USD, o.MODELED_RECOVERABLE_USD AS RECOVERABLE_USD,
           o.NO_PATH_USD, o.BASE_RECOVERY_CATEGORIES, o.BASE_RECOVERY_USD, o.BASE_REVISED_OUTLOOK_USD,
           o.BASE_REMAINING_GAP_USD, o.UPSIDE_RECOVERY_USD, o.UPSIDE_OUTLOOK_USD, o.UPSIDE_REMAINING_GAP_USD,
           m.F AS ML_FORECAST_USD, m.P10 AS ML_P10_USD, m.P90 AS ML_P90_USD,
           IFF(m.SD > 0, 1 / (1 + EXP(-1.702 * ((m.F - o.Q4_TARGET_USD) / m.SD))), NULL) AS PROB_HIT_TARGET,
           m.M AS ML_METHOD, o.ACCOUNTING_NOTE, t.TS AS DATA_TRUST_STATUS, o.REFRESHED_AT
    FROM {FQ}.RR_REVENUE_OUTLOOK o CROSS JOIN m CROSS JOIN t"""


@st.cache_data(ttl=300, show_spinner=False)
def load_overview() -> dict:
    """Overview page numbers straight from governed tables (no LLM call)."""
    o = _df(_OUTLOOK_SQL)
    r = load_reconciliation()
    return {"outlook": o.iloc[0].to_dict() if len(o) else {}, "categories": r,
            "at_risk": float(r["AT_RISK_USD"].sum()) if len(r) else 0.0,
            "recoverable": float(r["RECOVERABLE_USD"].sum()) if len(r) else 0.0,
            "no_path": float(r["NO_PATH_USD"].sum()) if len(r) else 0.0}


@st.cache_data(ttl=300, show_spinner=False)
def load_reconciliation() -> pd.DataFrame:
    return _df(f"""SELECT CATEGORY, COUNT(*) AS ITEMS, SUM(AT_RISK_USD) AS AT_RISK_USD,
                          SUM(RECOVERABLE_USD) AS RECOVERABLE_USD, SUM(NO_PATH_USD) AS NO_PATH_USD,
                          DIV0(SUM(RECOVERABLE_USD), SUM(AT_RISK_USD)) AS RECOVERY_RATE,
                          SUM(Q4_REVENUE_IMPACT) AS Q4_REVENUE_IMPACT
                   FROM {FQ}.RR_RISK_LEDGER WHERE ACTIVE_FLAG
                   GROUP BY CATEGORY ORDER BY AT_RISK_USD DESC""")


@st.cache_data(ttl=300, show_spinner=False)
def load_ledger(category: str | None = None) -> pd.DataFrame:
    sql = (f"SELECT RISK_ITEM_ID, CATEGORY, CUSTOMER_NAME, REGION_NAME, AT_RISK_USD, RECOVERABLE_USD, NO_PATH_USD, "
           f"RECOVERY_PROB, DUE_DATE, BLOCKER FROM {FQ}.RR_RISK_LEDGER WHERE ACTIVE_FLAG")
    return _df(sql + (" AND CATEGORY = ? ORDER BY AT_RISK_USD DESC" if category else " ORDER BY AT_RISK_USD DESC"),
               [category] if category else None)


@st.cache_data(ttl=300, show_spinner=False)
def load_outlook() -> pd.DataFrame:
    return _df(_OUTLOOK_SQL)


@st.cache_data(ttl=300, show_spinner=False)
def load_monthly() -> pd.DataFrame:
    return _df(f"""WITH c AS (SELECT * FROM {FQ}.RR_CONFIG WHERE CONFIG_ID = 1)
                   SELECT p.PERIOD_MONTH, SUM(p.TARGET_REVENUE) TARGET, SUM(p.FORECAST_REVENUE) PLAN_FORECAST,
                          SUM(p.ACTUAL_REVENUE) ACTUAL, MAX(m.ML_FORECAST_USD) ML_FORECAST,
                          MAX(m.ML_P10_USD) ML_P10, MAX(m.ML_P90_USD) ML_P90
                   FROM {FQ}.FACT_REVENUE_PLAN p
                   CROSS JOIN c
                   LEFT JOIN {FQ}.RR_ML_PLAN_FORECAST m ON m.PERIOD_MONTH = p.PERIOD_MONTH
                   WHERE p.PERIOD_MONTH >= DATE_TRUNC('YEAR', c.QTR_START) AND p.PERIOD_MONTH <= c.QTR_END
                     AND (c.PLAN_SCENARIO_ID IS NULL OR p.SCENARIO_ID = c.PLAN_SCENARIO_ID)
                   GROUP BY 1 ORDER BY 1""")


@st.cache_data(ttl=300, show_spinner=False)
def load_gap_drivers(n: int = 10) -> pd.DataFrame:
    return _df(f"""SELECT CONTRIBUTOR AS SEGMENT, CONTRIBUTION AS GAP_CONTRIBUTION_USD, RELATIVE_CONTRIBUTION AS SHARE_OF_GAP,
                          ML_METHOD
                   FROM {FQ}.RR_ML_GAP_DRIVERS WHERE CONTRIBUTOR <> 'Overall'
                   ORDER BY ABS(CONTRIBUTION) DESC LIMIT {int(n)}""")


@st.cache_data(ttl=300, show_spinner=False)
def load_policy_vs_ml() -> pd.DataFrame:
    return _df(f"""SELECT l.SOURCE_ID AS OPPORTUNITY_ID, l.CUSTOMER_NAME, l.AT_RISK_USD, l.RECOVERY_PROB AS POLICY_PROB,
                          s.ML_WIN_PROB, s.ML_METHOD, l.BLOCKER
                   FROM {FQ}.RR_RISK_LEDGER l JOIN {FQ}.RR_ML_DEAL_SCORES s ON s.OPPORTUNITY_ID = l.SOURCE_ID
                   WHERE l.ACTIVE_FLAG AND l.CATEGORY = 'PIPELINE' ORDER BY l.AT_RISK_USD DESC""")


@st.cache_data(ttl=300, show_spinner=False)
def load_gap_plan() -> pd.DataFrame:
    return _df(f"SELECT * FROM {FQ}.RR_GAP_PLAN ORDER BY STEP_ORDER")


_SCENARIOS = {"TOP3 POLICY": "BASE", "BASE": "BASE", "UPSIDE": "UPSIDE", "ALL": "UPSIDE"}


@st.cache_data(ttl=300, show_spinner=False)
def load_scenario(name: str = "TOP3 POLICY") -> dict:
    """Monte Carlo outcome range (SP_SIMULATE_RECOVERY). 'TOP3 POLICY' = governed base scenario."""
    cats = _SCENARIOS.get(str(name).upper(), name)
    raw = get_session().call(f"{FQ}.SP_SIMULATE_RECOVERY", cats, 10000)
    d = json.loads(raw) if isinstance(raw, str) else (raw or {})
    if not d or d.get("error"):
        return {}
    return {"SCENARIO_NAME": name, "CATEGORIES": ",".join(d.get("categories", [])),
            "EXPECTED_USD": d.get("simulated_mean_usd"), "GOVERNED_RECOVERABLE_USD": d.get("governed_recoverable_usd"),
            "P10_USD": d.get("p10_usd"), "P50_USD": d.get("p50_usd"), "P90_USD": d.get("p90_usd"),
            "PROB_REACH_GAP": d.get("probability_recovery_covers_forecast_gap"), "GAP_USD": d.get("forecast_gap_usd"),
            "ITERATIONS": d.get("iterations")}


@st.cache_data(ttl=300, show_spinner=False)
def load_table(view: str, order_by: str, where: str = "", limit: int = 50) -> pd.DataFrame:
    if view not in LOGICAL_VIEWS:
        raise ValueError(f"{view} is not an allowed view")
    return _df(f"SELECT * FROM ({LOGICAL_VIEWS[view]}) {('WHERE ' + where) if where else ''} "
               f"ORDER BY {order_by} LIMIT {int(limit)}")


CHART_QUERIES = {   # chart id -> loader (pages decide how to draw)
    "outlook_card": load_outlook,
    "forecast_vs_target": load_monthly,
    "gap_drivers": load_gap_drivers,
    "policy_vs_ml_deals": load_policy_vs_ml,
    "gap_bridge": load_gap_plan,
    "outcome_range": lambda: load_scenario("TOP3 POLICY"),
    "risk_by_category": load_reconciliation,
    "action_cards": lambda: load_table("V_ACTION_BOARD", "PRIORITY_RANK NULLS LAST, EXPECTED_RECOVERY_USD DESC",
                                       "STATUS = 'PROPOSED'", 5),
    "early_warning": lambda: load_table("V_EARLY_WARNING", "RENEWAL_ARR DESC NULLS LAST", "STATUS = 'NEW - ML EARLY WARNING'", 15),
    "fulfillment_plan": lambda: load_table("RR_FULFILLMENT_PLAN", "COVERED_FLAG DESC, BOOKED_VALUE DESC"),
    "expansion": lambda: load_table("V_EXPANSION_CANDIDATES", "EXPECTED_IN_QTR_USD DESC", "", 15),
    "prevention_controls": lambda: load_table("RR_PREVENTION_PLAN", "EST_PREVENTABLE_USD DESC"),
    "root_cause_briefs": lambda: load_table("RR_AI_CATEGORY_BRIEF", "CATEGORY"),
}


@st.cache_data(ttl=120, show_spinner=False)
def load_action_board(status: str | None = None) -> pd.DataFrame:
    return load_table("V_ACTION_BOARD", "STATUS, PRIORITY_RANK NULLS LAST, EXPECTED_RECOVERY_USD DESC",
                      f"STATUS = '{status}'" if status in {"PROPOSED", "APPROVED", "REJECTED", "IN_PROGRESS", "DONE"} else "", 200)


@st.cache_data(ttl=120, show_spinner=False)
def load_approved_vs_gap() -> dict:
    d = _df(f"""SELECT o.FORECAST_GAP_USD AS GAP_USD, o.BASE_RECOVERY_USD,
                       COALESCE(a.APPROVED_Q4_USD, 0) AS APPROVED_Q4_USD, COALESCE(a.APPROVED_ARR_USD, 0) AS APPROVED_ARR_USD,
                       COALESCE(a.DONE_Q4_USD, 0) AS DONE_Q4_USD, COALESCE(a.PROPOSED_USD, 0) AS PROPOSED_USD,
                       COALESCE(a.APPROVED_ACTIONS, 0) AS APPROVED_ACTIONS, COALESCE(a.PROPOSED_ACTIONS, 0) AS PROPOSED_ACTIONS
                FROM {FQ}.RR_REVENUE_OUTLOOK o
                CROSS JOIN (
                  SELECT SUM(IFF(STATUS IN ('APPROVED', 'IN_PROGRESS', 'DONE') AND CATEGORY <> 'RENEWAL', EXPECTED_RECOVERY_USD, 0)) AS APPROVED_Q4_USD,
                         SUM(IFF(STATUS IN ('APPROVED', 'IN_PROGRESS', 'DONE') AND CATEGORY = 'RENEWAL', EXPECTED_RECOVERY_USD, 0)) AS APPROVED_ARR_USD,
                         SUM(IFF(STATUS = 'DONE' AND CATEGORY <> 'RENEWAL', EXPECTED_RECOVERY_USD, 0)) AS DONE_Q4_USD,
                         SUM(IFF(STATUS = 'PROPOSED', EXPECTED_RECOVERY_USD, 0)) AS PROPOSED_USD,
                         COUNT_IF(STATUS IN ('APPROVED', 'IN_PROGRESS', 'DONE')) AS APPROVED_ACTIONS,
                         COUNT_IF(STATUS = 'PROPOSED') AS PROPOSED_ACTIONS
                  FROM {FQ}.RR_RECOVERY_ACTIONS) a""")
    return d.iloc[0].to_dict() if len(d) else {}


def load_refresh_log() -> pd.DataFrame:
    return _df(f"""SELECT STAGE AS STEP, STATUS, DATEDIFF(second, STARTED_AT, ENDED_AT) AS SECONDS, STARTED_AT
                   FROM {FQ}.RR_REFRESH_AUDIT
                   WHERE RUN_ID = (SELECT RUN_ID FROM {FQ}.RR_REFRESH_AUDIT WHERE RUN_ID LIKE 'RA-%'
                                   ORDER BY STARTED_AT DESC LIMIT 1)
                   ORDER BY STARTED_AT""")


# ----------------------------------------------------------------------------------------
# Governed write-back (each call writes one AGENT_ACTIONS row); returns {"ok": bool, ...}
# ----------------------------------------------------------------------------------------
def _call(proc: str, *args) -> dict:
    try:
        r = get_session().call(f"{FQ}.{proc}", *args)
        if isinstance(r, str):
            try:
                out = json.loads(r)
            except ValueError:
                out = {"ok": True, "message": r}
        else:
            out = r if isinstance(r, dict) else {"ok": True, "message": str(r)}
        out.setdefault("ok", True)
    except Exception as e:
        msg = str(e)
        m = re.search(r"(Not authorized[^.]*\.|Only [A-Z_ ]+[^.]*\.|Refused:[^.]*\.|[^.]*not found[^.]*\.|"
                      r"Allowed transitions[^.]*\.|A rejection reason[^.]*\.)", msg)
        out = {"ok": False, "error": (m.group(1) if m else msg)[:300]}
    st.cache_data.clear()
    return out


def approve_action(action_id: str, approve: bool = True, note: str = "") -> dict:
    tag = f"[{SURFACE} · {_viewer()}]"
    if approve:
        return _call("SP_APPROVE_RECOVERY_ACTION", action_id, f"{note} {tag}".strip())
    return _call("SP_REJECT_RECOVERY_ACTION", action_id, f"{note or 'Rejected in the Command Center'} {tag}")


def update_action_status(action_id: str, status: str, note: str = "") -> dict:
    return _call("SP_UPDATE_ACTION_STATUS", action_id, status, f"{note} [{SURFACE} · {_viewer()}]".strip())


def launch_control(control_id: str, owner: str | None = None, review_days: int = 30, note: str = "") -> dict:
    return _call("SP_LAUNCH_PLANNED_CONTROL", control_id, owner, int(review_days),
                 f"{note} [{SURFACE} · {_viewer()}]".strip())


def save_answer(result: dict) -> dict:
    sql = next((c["sql"] for c in result.get("tool_calls", []) if c.get("sql")), None)
    return _call("SP_SAVE_VERIFIED_ANSWER", result.get("question"), result.get("text"), sql)


def refresh_analytics() -> dict:
    return _call("SP_REFRESH_ANALYTICS")


# ----------------------------------------------------------------------------------------
# Formatting helper shared with ui_common.fmt_money
# ----------------------------------------------------------------------------------------
def fmt_money(v: Any) -> str:
    try:
        v = float(v)
    except (TypeError, ValueError):
        return "-"
    a = abs(v)
    for div, suf in ((1e9, "B"), (1e6, "M"), (1e3, "K")):
        if a >= div:
            return f"{'-' if v < 0 else ''}${a / div:.1f}{suf}"
    return f"${v:,.0f}"
