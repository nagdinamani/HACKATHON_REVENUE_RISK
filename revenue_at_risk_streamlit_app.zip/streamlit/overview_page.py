"""Page 2 - Overview: governed numbers straight from Snowflake decision tables. No LLM call on load."""
from __future__ import annotations

import streamlit as st

import rr_backend as rb
import ui_common as ui

ui.show_flash()
ui.brand_header("Overview", "Governed Q4 position · computed by Snowflake SQL, no model in the loop")

try:
    data = rb.load_overview()
except Exception as e:
    st.error(f"Could not load the governed overview: {str(e)[:300]}")
    st.stop()

o = data.get("outlook") or {}
cats = data.get("categories")
gap = o.get("GAP_USD")

top_l, top_r = st.columns([4, 1])
with top_r:
    if st.button("Refresh", help="Re-read governed tables (does not rebuild analytics)", use_container_width=True):
        st.cache_data.clear()
        st.rerun()
    st.caption(f"As of {o.get('AS_OF_DATE', '—')} · data trust {o.get('DATA_TRUST_STATUS') or 'not run'}")
with top_l:
    ui.hero_metric("Revenue at risk", data.get("at_risk", 0.0),
                   f"against a {ui.fmt_money(gap)} forecast gap this quarter — gross operational exposure, not the gap")

ui.stat_row([
    ("Q4 target", o.get("TARGET_USD"), ui.SNOWFLAKE_BLUE),
    ("Forecast", o.get("PLAN_FORECAST_USD"), ui.SNOWFLAKE_BLUE_DEEP),
    ("Gap", gap, ui.RED),
    ("Recoverable", data.get("recoverable"), ui.GREEN),
    ("No path today", data.get("no_path"), ui.AMBER),
])

left, right = st.columns([3, 2], gap="large")
with left:
    with st.container(border=True):
        ui.render_stacked_category(cats)
with right:
    with st.container(border=True):
        if cats is not None and len(cats):
            ui.render_donut_chart([ui.category_label(c) for c in cats["CATEGORY"]],
                                  [float(v) for v in cats["AT_RISK_USD"]],
                                  [ui.category_color(c) for c in cats["CATEGORY"]], "Where the exposure sits")
        else:
            st.caption("No active risk items.")

ui.section_title("By category", "Five governed risk mechanisms")
if cats is not None and len(cats):
    cols = st.columns(len(cats))
    for col, (_, r) in zip(cols, cats.iterrows()):
        c = r["CATEGORY"]
        basis = " ARR" if c == "RENEWAL" else ""
        with col:
            ui.md_html(f"""<div class="raa-catcard" style="border-top:3px solid {ui.category_color(c)}">
<div class="t">{ui.icon_svg(c, 18)} {ui.esc(ui.category_label(c))}</div>
<div class="raa-muted" style="margin-top:8px;">At risk</div>
<div style="font-size:1.25rem;font-weight:700" title="{ui.exact_money(r['AT_RISK_USD'])}">{ui.fmt_money(r['AT_RISK_USD'])}{basis}</div>
<div class="raa-muted" style="margin-top:6px;">Recoverable</div>
<div style="font-weight:700;color:{ui.GREEN}" title="{ui.exact_money(r['RECOVERABLE_USD'])}">{ui.fmt_money(r['RECOVERABLE_USD'])}{basis}</div>
<div class="raa-muted" style="margin-top:6px;">{int(r['ITEMS'])} items · {float(r['RECOVERY_RATE'] or 0):.0%} recovery rate</div></div>""")

if o:
    s1, s2 = st.columns(2)
    with s1:
        ui.card(f"""<div class="raa-eyebrow">Base Revised Outlook · illustrative</div>
<div style="font-size:1.4rem;font-weight:700" title="{ui.exact_money(o.get('BASE_REVISED_OUTLOOK_USD'))}">{ui.fmt_money(o.get('BASE_REVISED_OUTLOOK_USD'))}</div>
<div class="raa-muted">{ui.esc(o.get('BASE_RECOVERY_CATEGORIES'))} recover {ui.fmt_money(o.get('BASE_RECOVERY_USD'))} ·
remaining gap {ui.fmt_money(o.get('BASE_REMAINING_GAP_USD'))}</div>""")
    with s2:
        ui.card(f"""<div class="raa-eyebrow">Upside Recovery Case · illustrative, not guaranteed</div>
<div style="font-size:1.4rem;font-weight:700" title="{ui.exact_money(o.get('UPSIDE_OUTLOOK_USD'))}">{ui.fmt_money(o.get('UPSIDE_OUTLOOK_USD'))}</div>
<div class="raa-muted">All five categories recover {ui.fmt_money(o.get('UPSIDE_RECOVERY_USD'))} ·
remaining gap {ui.fmt_money(o.get('UPSIDE_REMAINING_GAP_USD'))}</div>""")

    prob = o.get("PROB_HIT_TARGET")
    pct = f"{float(prob):.0%}" if prob is not None and str(prob) != "nan" else "n/a"
    st.caption(f"ML forecast {ui.fmt_money(o.get('ML_FORECAST_USD'))} (P10–P90 {ui.fmt_money(o.get('ML_P10_USD'))}–"
               f"{ui.fmt_money(o.get('ML_P90_USD'))}), chance of hitting target ≈ {pct} · {o.get('ML_METHOD') or ''} · "
               "second opinion only; the governed plan forecast is authoritative.")
    if o.get("ACCOUNTING_NOTE"):
        st.caption(o["ACCOUNTING_NOTE"])
