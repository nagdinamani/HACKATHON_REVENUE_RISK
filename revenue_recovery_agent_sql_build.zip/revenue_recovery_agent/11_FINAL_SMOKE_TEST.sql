/* =============================================================================
   11_FINAL_SMOKE_TEST.sql
   End-to-end smoke test of every agent tool BEFORE the agent is created.
   Raises (STOP) on any critical failure. Makes exactly one Claude call
   (SP_DEEP_REVENUE_REASONING) to prove the deep-reasoning path works.
   ============================================================================= */

USE DATABASE HACKATHON_REVENUE_RISK;
USE SCHEMA SOLUTION;
USE WAREHOUSE RR_WH;

CREATE OR REPLACE PROCEDURE SP_RUN_SMOKE_TEST()
RETURNS VARIANT
LANGUAGE SQL
COMMENT = 'Calls each agent tool and checks its contract against governed values.'
AS
$$
DECLARE
  run_id      VARCHAR DEFAULT ('SM-' || TO_VARCHAR(CURRENT_TIMESTAMP(), 'YYYYMMDDHH24MISSFF3'));
  started_at  TIMESTAMP_NTZ DEFAULT (CURRENT_TIMESTAMP()::TIMESTAMP_NTZ);
  snap        VARCHAR;
  scen_base   VARCHAR;
  scen_words  VARCHAR;
  scen_up     VARCHAR;
  acts        VARCHAR;
  sim         VARCHAR;
  changed     VARCHAR;
  trust       VARCHAR;
  deep        VARCHAR;
  gplan       VARCHAR;
  pplan       VARCHAR;
  fails       NUMBER;
  summary     VARIANT;
  smoke_failed EXCEPTION (-20601, 'SMOKE TEST FAILED — STOP. Query RR_VALIDATION_RESULTS (RUN_TYPE = SMOKE).');
BEGIN
  CALL SP_GET_EXECUTIVE_SNAPSHOT() INTO :snap;
  CALL SP_RECOVERY_SCENARIO('BASE') INTO :scen_base;
  CALL SP_RECOVERY_SCENARIO('What if we recover Pipeline, Fulfillment and Billing') INTO :scen_words;
  CALL SP_RECOVERY_SCENARIO('UPSIDE') INTO :scen_up;
  CALL SP_GET_RECOVERY_ACTIONS(5, 'OPEN') INTO :acts;
  CALL SP_SIMULATE_RECOVERY('BASE', 5000) INTO :sim;
  CALL SP_WHAT_CHANGED() INTO :changed;
  CALL SP_RR_TRUST_CHECK() INTO :trust;
  CALL SP_GET_GAP_PLAN() INTO :gplan;
  CALL SP_GET_PREVENTION_PLAN() INTO :pplan;
  CALL SP_DEEP_REVENUE_REASONING('We are forecasting below our Q4 target. How much revenue is at risk before quarter-end, why, and how much can we still recover?') INTO :deep;

  INSERT INTO RR_VALIDATION_RESULTS (VALIDATION_RUN_ID, RUN_TYPE, TEST_ID, TEST_GROUP, SEVERITY, STATUS, EXPECTED, ACTUAL, TESTED_AT)
  WITH j AS (
    SELECT PARSE_JSON(:snap) AS SNAP, PARSE_JSON(:scen_base) AS SB, PARSE_JSON(:scen_words) AS SW,
           PARSE_JSON(:scen_up) AS SU, PARSE_JSON(:acts) AS A, PARSE_JSON(:sim) AS SIM,
           PARSE_JSON(:changed) AS CH, PARSE_JSON(:trust) AS TR, PARSE_JSON(:deep) AS D,
           PARSE_JSON(:gplan) AS GP, PARSE_JSON(:pplan) AS PP
  ),
  o AS (SELECT * FROM RR_REVENUE_OUTLOOK),
  t AS (
    SELECT 'S-SNAPSHOT-CONTRACT' AS ID, 'CRITICAL' AS SEV,
           j.SNAP:current_position:q4_target_usd::NUMBER(18,2) = o.Q4_TARGET_USD
           AND j.SNAP:revenue_at_risk:gross_at_risk_usd::NUMBER(18,2) = o.GROSS_AT_RISK_USD
           AND j.SNAP:scenarios:base_revised_outlook:outlook_usd::NUMBER(18,2) = o.BASE_REVISED_OUTLOOK_USD AS OK,
           'snapshot = RR_REVENUE_OUTLOOK' AS EXP, TO_VARCHAR(j.SNAP:display_usd_millions) AS ACT
    FROM j CROSS JOIN o
    UNION ALL
    SELECT 'S-SCENARIO-BASE', 'CRITICAL', ABS(j.SB:scenario_recovery_usd::NUMBER(18,2) - o.BASE_RECOVERY_USD) < 1,
           TO_VARCHAR(o.BASE_RECOVERY_USD), TO_VARCHAR(j.SB:scenario_recovery_usd) FROM j CROSS JOIN o
    UNION ALL
    SELECT 'S-SCENARIO-NATURAL-LANGUAGE', 'CRITICAL',
           j.SW:categories::VARCHAR = 'BILLING,FULFILLMENT,PIPELINE'
           AND ABS(j.SW:scenario_recovery_usd::NUMBER(18,2) - o.BASE_RECOVERY_USD) < 1,
           'BILLING,FULFILLMENT,PIPELINE', j.SW:categories::VARCHAR FROM j CROSS JOIN o
    UNION ALL
    SELECT 'S-SCENARIO-UPSIDE', 'CRITICAL', ABS(j.SU:scenario_outlook_usd::NUMBER(18,2) - o.UPSIDE_OUTLOOK_USD) < 1,
           TO_VARCHAR(o.UPSIDE_OUTLOOK_USD), TO_VARCHAR(j.SU:scenario_outlook_usd) FROM j CROSS JOIN o
    UNION ALL
    SELECT 'S-ACTIONS-CONTRACT', 'CRITICAL',
           j.A:actions_returned::NUMBER BETWEEN 1 AND 5
           AND j.A:expected_recovery_of_returned_actions_usd::NUMBER(18,2) <= o.MODELED_RECOVERABLE_USD,
           '1..5 actions, value <= modeled recoverable', TO_VARCHAR(j.A:actions_returned) FROM j CROSS JOIN o
    UNION ALL
    SELECT 'S-SIMULATION-CONSISTENT', 'CRITICAL',
           ABS(j.SIM:simulated_mean_usd::FLOAT - j.SIM:governed_recoverable_usd::FLOAT)
             <= 0.05 * GREATEST(j.SIM:governed_recoverable_usd::FLOAT, 1)
           AND ABS(j.SIM:governed_recoverable_usd::NUMBER(18,2) - o.BASE_RECOVERY_USD) < 1,
           'simulated mean within 5% of governed base recovery',
           TO_VARCHAR(j.SIM:simulated_mean_usd) || ' vs ' || TO_VARCHAR(j.SIM:governed_recoverable_usd) FROM j CROSS JOIN o
    UNION ALL
    SELECT 'S-WHAT-CHANGED', 'CRITICAL', j.CH:item_status_counts IS NOT NULL, 'status counts present',
           TO_VARCHAR(j.CH:item_status_counts) FROM j
    UNION ALL
    SELECT 'S-GAP-PLAN-CONTRACT', 'CRITICAL',
           ARRAY_SIZE(j.GP:steps) >= 2
           AND ABS(GET(j.GP:steps, ARRAY_SIZE(j.GP:steps) - 1):cumulative_forecast_usd::NUMBER(18,2) - o.UPSIDE_OUTLOOK_USD) < 1,
           'last step = upside outlook', TO_VARCHAR(ARRAY_SIZE(j.GP:steps)) || ' steps' FROM j CROSS JOIN o
    UNION ALL
    SELECT 'S-PREVENTION-PLAN', 'INFO', ARRAY_SIZE(j.PP:controls) > 0, '> 0 controls',
           TO_VARCHAR(ARRAY_SIZE(j.PP:controls)) FROM j
    UNION ALL
    SELECT 'S-TRUST-PASS', 'CRITICAL', j.TR:overall_status::VARCHAR = 'PASS', 'PASS', j.TR:overall_status::VARCHAR FROM j
    UNION ALL
    SELECT 'S-DEEP-REASONING-ANSWERED', 'CRITICAL',
           LENGTH(j.D:answer::VARCHAR) > 300 AND j.D:model::VARCHAR = 'claude-opus-5-5',
           'non-empty answer from claude-opus-5-5', j.D:model::VARCHAR || ' / ' || TO_VARCHAR(LENGTH(j.D:answer::VARCHAR)) || ' chars'
    FROM j
    UNION ALL
    SELECT 'S-DEEP-REASONING-SECTIONS', 'INFO',
           j.D:answer::VARCHAR ILIKE '%DIRECT ANSWER%' AND j.D:answer::VARCHAR ILIKE '%EVIDENCE%',
           'response contract headings', LEFT(j.D:answer::VARCHAR, 200) FROM j
    UNION ALL
    SELECT 'S-DEEP-REASONING-NO-GUARANTEE', 'INFO',
           NOT (j.D:answer::VARCHAR ILIKE '%guaranteed forecast of $123.2M%'),
           'upside never described as guaranteed', 'manual review in 13' FROM j
  )
  SELECT :run_id, 'SMOKE', ID, 'TOOLS', SEV, IFF(COALESCE(OK, FALSE), 'PASS', 'FAIL'), EXP, COALESCE(ACT, 'NULL'),
         CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
  FROM t;

  SELECT COUNT_IF(STATUS = 'FAIL' AND SEVERITY = 'CRITICAL'),
         OBJECT_CONSTRUCT('smoke_run_id', :run_id, 'tests', COUNT(*), 'passed', COUNT_IF(STATUS = 'PASS'),
                          'failed', ARRAY_AGG(IFF(STATUS = 'FAIL', TEST_ID, NULL)),
                          'deep_reasoning_preview', LEFT(PARSE_JSON(:deep):answer::VARCHAR, 1500))
    INTO :fails, :summary
    FROM RR_VALIDATION_RESULTS WHERE VALIDATION_RUN_ID = :run_id;

  INSERT INTO RR_REFRESH_AUDIT (RUN_ID, STAGE, STATUS, STARTED_AT, ENDED_AT, AS_OF_DATE, ROWS_AFFECTED, DETAILS, RUN_BY)
  SELECT :run_id, 'SMOKE_TEST', IFF(:fails = 0, 'SUCCESS', 'FAILED'), :started_at, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ,
         (SELECT AS_OF_DATE FROM RR_CONFIG WHERE CONFIG_ID = 1), :fails, :summary, CURRENT_USER();

  IF (fails > 0) THEN RAISE smoke_failed; END IF;
  RETURN summary;
END;
$$;

-- ===========================================================================
-- EXECUTE
-- ===========================================================================
CALL SP_RUN_SMOKE_TEST();

SELECT TEST_ID, SEVERITY, STATUS, EXPECTED, ACTUAL
FROM RR_VALIDATION_RESULTS
WHERE VALIDATION_RUN_ID = (SELECT MAX(VALIDATION_RUN_ID) FROM RR_VALIDATION_RESULTS WHERE RUN_TYPE = 'SMOKE')
ORDER BY IFF(STATUS = 'FAIL', 0, 1), TEST_ID;

-- Full deep-reasoning answer for the primary demo question
SELECT DETAILS:deep_reasoning_preview::VARCHAR AS PREVIEW
FROM RR_REFRESH_AUDIT WHERE STAGE = 'SMOKE_TEST' ORDER BY ENDED_AT DESC LIMIT 1;
