/* =============================================================================
   00A_HACKATHON_WAREHOUSE_AND_CORTEX_CHECK.sql
   Creates RR_WH and verifies Cortex / Claude / ML availability BEFORE building.

   Role guidance
     * Build role: a role that owns HACKATHON_REVENUE_RISK.SOLUTION (e.g. SYSADMIN
       or a dedicated RR_BUILDER role).
     * Section 2 needs ACCOUNTADMIN once (grants + cross-region inference).
   ============================================================================= */

-- ---------------------------------------------------------------------------
-- 1. Warehouse with auto-suspend / auto-resume
-- ---------------------------------------------------------------------------
CREATE WAREHOUSE IF NOT EXISTS RR_WH
  WAREHOUSE_SIZE      = 'XSMALL'
  AUTO_SUSPEND        = 60
  AUTO_RESUME         = TRUE
  INITIALLY_SUSPENDED = TRUE
  COMMENT = 'Revenue Recovery Agent: refresh, AI enrichment, agent tools';

USE WAREHOUSE RR_WH;
USE DATABASE HACKATHON_REVENUE_RISK;
USE SCHEMA SOLUTION;

-- ---------------------------------------------------------------------------
-- 2. ONE-TIME ACCOUNTADMIN GRANTS (uncomment and replace <BUILD_ROLE>)
-- ---------------------------------------------------------------------------
-- USE ROLE ACCOUNTADMIN;
-- GRANT DATABASE ROLE SNOWFLAKE.CORTEX_USER TO ROLE <BUILD_ROLE>;
-- -- Opus 5.5 is served through cross-region inference in most regions:
-- ALTER ACCOUNT SET CORTEX_ENABLED_CROSS_REGION = 'ANY_REGION';
-- GRANT CREATE SNOWFLAKE.ML.CLASSIFICATION    ON SCHEMA HACKATHON_REVENUE_RISK.SOLUTION TO ROLE <BUILD_ROLE>;
-- GRANT CREATE SNOWFLAKE.ML.ANOMALY_DETECTION ON SCHEMA HACKATHON_REVENUE_RISK.SOLUTION TO ROLE <BUILD_ROLE>;
-- GRANT CREATE SNOWFLAKE.ML.FORECAST          ON SCHEMA HACKATHON_REVENUE_RISK.SOLUTION TO ROLE <BUILD_ROLE>;
-- GRANT CREATE SNOWFLAKE.ML.TOP_INSIGHTS      ON SCHEMA HACKATHON_REVENUE_RISK.SOLUTION TO ROLE <BUILD_ROLE>;
-- GRANT CREATE AGENT, CREATE SEMANTIC VIEW, CREATE TASK, CREATE PROCEDURE, CREATE TABLE
--   ON SCHEMA HACKATHON_REVENUE_RISK.SOLUTION TO ROLE <BUILD_ROLE>;
-- GRANT EXECUTE TASK ON ACCOUNT TO ROLE <BUILD_ROLE>;
-- GRANT USAGE ON WAREHOUSE RR_WH TO ROLE <BUILD_ROLE>;
-- USE ROLE <BUILD_ROLE>;

-- ---------------------------------------------------------------------------
-- 3. Context checks
-- ---------------------------------------------------------------------------
SELECT CURRENT_ROLE() AS ROLE_NAME, CURRENT_WAREHOUSE() AS WAREHOUSE_NAME,
       CURRENT_DATABASE() AS DB, CURRENT_SCHEMA() AS SCH, CURRENT_REGION() AS REGION;

SHOW PARAMETERS LIKE 'CORTEX_ENABLED_CROSS_REGION' IN ACCOUNT;

-- Models available to this account (look for claude-opus-5-5)
SHOW CORTEX BASE MODELS;

-- ---------------------------------------------------------------------------
-- 4. Cortex AI function smoke checks (each must return a value, not an error)
-- ---------------------------------------------------------------------------
-- Deep-reasoning model used by SP_DEEP_REVENUE_REASONING and AI enrichment
SELECT AI_COMPLETE('claude-opus-5-5', 'Reply with exactly the text: RR_OPUS_OK') AS OPUS_5_5_CHECK;

-- Blocker taxonomy classification used in AI enrichment
SELECT AI_CLASSIFY(
         'Customer disputes the negotiated unit price on invoice',
         ['Commercial dispute', 'PO mismatch', 'Tax master-data issue', 'Customer-master hold']
       ) AS AI_CLASSIFY_CHECK;

-- Category brief aggregation used in AI enrichment
SELECT AI_AGG(t.TXT, 'In one sentence, name the common theme.') AS AI_AGG_CHECK
FROM (SELECT 'Legal review pending on MSA' AS TXT
      UNION ALL SELECT 'Contract redlines with procurement'
      UNION ALL SELECT 'Awaiting legal sign-off') t;

-- ---------------------------------------------------------------------------
-- 5. Snowflake ML privilege check (informational — 03 is optional)
-- ---------------------------------------------------------------------------
SHOW GRANTS ON SCHEMA HACKATHON_REVENUE_RISK.SOLUTION;

SELECT 'If all checks above returned values, continue with 01_PREFLIGHT_AND_CONFIG.sql' AS NEXT_STEP;
