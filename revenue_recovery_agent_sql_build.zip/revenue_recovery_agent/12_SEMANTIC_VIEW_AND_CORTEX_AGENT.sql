/* =============================================================================
   12_SEMANTIC_VIEW_AND_CORTEX_AGENT.sql
   Run ONLY after 09_VALIDATION and 11_FINAL_SMOKE_TEST pass.

   1. RR_REVENUE_RISK_SEMANTIC  — Snowflake semantic view (business vocabulary,
      governed metrics, AI SQL instructions, verified queries) used by Cortex Analyst.
   2. RR_REVENUE_RECOVERY_AGENT — persistent Cortex Agent (orchestration layer).

   Orchestration model decision (verified against Snowflake docs, Oct 2026):
     Snowflake recommends `orchestration: auto`; Claude Opus 5.5 is available to
     Cortex Agents in public preview. The agent therefore uses `auto`, and
     claude-opus-5-5 is used explicitly as the DeepRevenueReasoning tool via
     AI_COMPLETE. Section 4 shows how to pin claude-opus-5-5 if your account
     confirms support and you accept preview status.
   ============================================================================= */

USE DATABASE HACKATHON_REVENUE_RISK;
USE SCHEMA SOLUTION;
USE WAREHOUSE RR_WH;

-- Gate: refuse to build the agent surface if the deterministic build has not passed
EXECUTE IMMEDIATE $$
DECLARE
  v VARCHAR; s VARCHAR;
  gate_failed EXCEPTION (-20701, 'Agent build blocked: latest 09 validation or 11 smoke test did not succeed. STOP.');
BEGIN
  SELECT MAX_BY(STATUS, ENDED_AT) INTO :v FROM RR_REFRESH_AUDIT WHERE STAGE = 'VALIDATION';
  SELECT MAX_BY(STATUS, ENDED_AT) INTO :s FROM RR_REFRESH_AUDIT WHERE STAGE = 'SMOKE_TEST';
  IF (COALESCE(v, 'NONE') <> 'SUCCESS' OR COALESCE(s, 'NONE') <> 'SUCCESS') THEN
    RAISE gate_failed;
  END IF;
  RETURN 'GATE PASSED: validation and smoke test succeeded';
END;
$$;

-- ---------------------------------------------------------------------------
-- 1. Semantic view
-- ---------------------------------------------------------------------------
CREATE OR REPLACE SEMANTIC VIEW RR_REVENUE_RISK_SEMANTIC
  TABLES (
    risk AS HACKATHON_REVENUE_RISK.SOLUTION.RR_RISK_LEDGER
      PRIMARY KEY (RISK_ITEM_ID)
      WITH SYNONYMS ('revenue risk ledger', 'risk items', 'revenue exposure', 'at-risk revenue')
      COMMENT = 'Governed revenue risk items across five mechanisms (pipeline, fulfillment, billing, renewal, support/expansion). Money computed by SQL only.',
    customers AS HACKATHON_REVENUE_RISK.SOLUTION.RR_CUSTOMER_360
      PRIMARY KEY (CUSTOMER_ID)
      WITH SYNONYMS ('accounts', 'customer health', 'customer 360')
      COMMENT = 'Customer 360: usage trend, CSAT, open P1/P2, renewal, ML usage-anomaly second opinion.',
    actions AS HACKATHON_REVENUE_RISK.SOLUTION.RR_RECOVERY_ACTIONS
      PRIMARY KEY (ACTION_ID)
      WITH SYNONYMS ('recovery actions', 'recommended actions', 'plays', 'action plan')
      COMMENT = 'Recovery actions: PROPOSED by AI or rules; APPROVED / REJECTED / IN_PROGRESS / DONE only by humans.'
  )
  RELATIONSHIPS (
    risk_to_customer AS risk (CUSTOMER_ID) REFERENCES customers,
    action_to_risk   AS actions (RISK_ITEM_ID) REFERENCES risk
  )
  FACTS (
    risk.active_at_risk_usd     AS IFF(ACTIVE_FLAG, AT_RISK_USD, 0)     COMMENT = 'At-risk value of currently active items (USD).',
    risk.active_recoverable_usd AS IFF(ACTIVE_FLAG, RECOVERABLE_USD, 0) COMMENT = 'Recoverable value of currently active items (USD).',
    risk.active_no_path_usd     AS IFF(ACTIVE_FLAG, NO_PATH_USD, 0)     COMMENT = 'Exposure with no modeled recovery path (USD).',
    risk.active_item_flag       AS IFF(ACTIVE_FLAG, 1, 0),
    risk.active_recovery_prob   AS IFF(ACTIVE_FLAG, RECOVERY_PROB, NULL),
    risk.prior_recoverable_usd  AS PREV_RECOVERABLE_USD                 COMMENT = 'Recoverable value at the previous refresh.',
    actions.open_expected_recovery_usd AS IFF(STATUS IN ('PROPOSED', 'APPROVED', 'IN_PROGRESS'), EXPECTED_RECOVERY_USD, 0)
      COMMENT = 'Governed expected recovery of open (proposed, approved or in progress) actions.',
    actions.committed_recovery_usd AS IFF(STATUS IN ('APPROVED', 'IN_PROGRESS', 'DONE'), EXPECTED_RECOVERY_USD, 0)
      COMMENT = 'Governed expected recovery of human-approved actions.',
    customers.arr_up_for_renewal AS RENEWAL_ARR COMMENT = 'Renewal ARR from the latest health snapshot (ARR, not Q4 revenue).'
  )
  DIMENSIONS (
    risk.risk_category  AS CATEGORY
      WITH SYNONYMS ('category', 'risk mechanism', 'risk type', 'risk area')
      COMMENT = 'PIPELINE, FULFILLMENT, BILLING, RENEWAL or SUPPORT_EXPANSION ("support" or "expansion" means SUPPORT_EXPANSION).',
    risk.risk_item      AS RISK_ITEM_ID WITH SYNONYMS ('risk item id') COMMENT = 'Unique risk item key (PIPE-, FUL-, BIL-, REN-, SUP- prefix).',
    risk.source_record  AS SOURCE_ID WITH SYNONYMS ('opportunity id', 'order id', 'billing id', 'deal id') COMMENT = 'Source record id: opportunity, order, billing line or customer.',
    risk.customer       AS CUSTOMER_NAME WITH SYNONYMS ('customer name', 'account', 'client'),
    risk.region         AS REGION_NAME WITH SYNONYMS ('geography', 'territory', 'region name'),
    risk.product_line   AS PRODUCT_FAMILY WITH SYNONYMS ('product family', 'line of business'),
    risk.product        AS PRODUCT_NAME WITH SYNONYMS ('product name', 'sku'),
    risk.blocker_reason AS BLOCKER WITH SYNONYMS ('blocker', 'risk reason', 'root cause', 'exception code') COMMENT = 'Governed blocker text from the source system.',
    risk.recovery_route AS RECOVERY_PATH WITH SYNONYMS ('recovery path', 'alternate warehouse transfer', 'fix') COMMENT = 'Deterministic recovery path, e.g. which alternate warehouse covers a shortage.',
    risk.due_on         AS DUE_DATE WITH SYNONYMS ('due date', 'deadline', 'expected close date', 'renewal date') COMMENT = 'Date by which the item must be recovered.',
    risk.days_until_due AS DAYS_TO_DUE WITH SYNONYMS ('days to due') COMMENT = 'Days from the as-of date to the due date.',
    risk.risk_class     AS AI_RISK_CLASS WITH SYNONYMS ('blocker class', 'risk classification') COMMENT = 'AI_CLASSIFY taxonomy of the blocker.',
    risk.owner          AS AI_OWNER_ROLE WITH SYNONYMS ('owner role', 'accountable owner', 'who owns') COMMENT = 'Recommended accountable role (Claude Opus 5.5).',
    risk.next_best_action AS AI_NEXT_BEST_ACTION WITH SYNONYMS ('recommended action', 'next step') COMMENT = 'Claude Opus 5.5 recommendation (qualitative).',
    risk.recommended_first_step AS AI_FIRST_STEP,
    risk.executive_summary AS AI_SUMMARY WITH SYNONYMS ('why', 'explanation') COMMENT = 'Claude Opus 5.5 root-cause summary (qualitative, no money).',
    risk.evidence       AS EVIDENCE_TEXT COMMENT = 'Governed evidence statement for the item.',
    risk.value_type     AS VALUE_BASIS COMMENT = 'BOOKING, ORDER, INVOICE, ARR or EXPANSION.',
    risk.change_since_last_refresh AS CHANGE_STATUS WITH SYNONYMS ('what changed', 'change status') COMMENT = 'NEW, CHANGED, UNCHANGED, REOPENED, RESOLVED or INACTIVE versus the previous refresh.',
    risk.is_active      AS ACTIVE_FLAG COMMENT = 'TRUE for current risk items; resolved items are FALSE.',
    risk.governed_probability AS RECOVERY_PROB WITH SYNONYMS ('governed recovery probability', 'recovery probability') COMMENT = 'Authoritative governed recovery probability (0-1).',
    risk.ml_second_opinion_score AS ML_SCORE WITH SYNONYMS ('ml win probability', 'ml score') COMMENT = 'Second opinion only. For pipeline it is ML win probability (0-1).',
    risk.ml_score_kind  AS ML_SCORE_TYPE,
    risk.ml_vs_governed_gap AS ML_GOVERNED_DELTA WITH SYNONYMS ('ml disagreement') COMMENT = 'ML win probability minus governed probability (pipeline).',
    customers.account_name     AS CUSTOMER_NAME WITH SYNONYMS ('customer'),
    customers.segment_name     AS SEGMENT WITH SYNONYMS ('segment'),
    customers.industry_name    AS INDUSTRY WITH SYNONYMS ('industry', 'vertical'),
    customers.account_region   AS REGION_NAME,
    customers.account_tier     AS TIER WITH SYNONYMS ('tier'),
    customers.renewal_on       AS RENEWAL_DATE WITH SYNONYMS ('renewal date'),
    customers.latest_csat      AS CSAT WITH SYNONYMS ('csat', 'satisfaction'),
    customers.usage_change     AS USAGE_CHANGE_PCT WITH SYNONYMS ('usage change percent'),
    customers.usage_last_4_weeks  AS USAGE_AVG_LAST_4W,
    customers.usage_prior_8_weeks AS USAGE_AVG_PRIOR_8W,
    customers.open_escalations AS OPEN_P1_P2 WITH SYNONYMS ('p1 p2 tickets', 'open escalations', 'sev1 sev2'),
    customers.health_deteriorating AS HEALTH_DETERIORATING_FLAG WITH SYNONYMS ('deteriorating health', 'declining health'),
    customers.ml_usage_anomaly AS ML_USAGE_ANOMALY_FLAG WITH SYNONYMS ('usage anomaly'),
    actions.action_ref         AS ACTION_ID,
    actions.recommended_action AS ACTION_TEXT WITH SYNONYMS ('action'),
    actions.action_owner       AS OWNER_ROLE WITH SYNONYMS ('action owner', 'owner'),
    actions.first_step_text    AS FIRST_STEP WITH SYNONYMS ('first step'),
    actions.action_status      AS STATUS WITH SYNONYMS ('approval status'),
    actions.action_priority    AS PRIORITY_RANK WITH SYNONYMS ('priority', 'rank'),
    actions.action_due         AS DUE_DATE,
    actions.decided_by         AS DECISION_BY WITH SYNONYMS ('approved by'),
    actions.action_origin      AS ACTION_SOURCE,
    actions.action_category    AS CATEGORY
  )
  METRICS (
    risk.revenue_at_risk     AS SUM(risk.active_at_risk_usd)
      WITH SYNONYMS ('gross revenue at risk', 'exposure', 'at risk', 'revenue exposure')
      COMMENT = 'Gross operational exposure (USD) of active risk items. NOT the forecast gap.',
    risk.recoverable_revenue AS SUM(risk.active_recoverable_usd)
      WITH SYNONYMS ('recoverable', 'recovery potential', 'modeled recovery')
      COMMENT = 'Modeled recoverable value (USD) of active risk items.',
    risk.no_path_revenue     AS SUM(risk.active_no_path_usd) COMMENT = 'Exposure with no modeled recovery path (USD).',
    risk.risk_item_count     AS SUM(risk.active_item_flag) WITH SYNONYMS ('number of risk items', 'count of risks'),
    risk.average_recovery_probability AS AVG(risk.active_recovery_prob) COMMENT = 'Simple average governed recovery probability.',
    risk.recovery_rate       AS DIV0(SUM(risk.active_recoverable_usd), SUM(risk.active_at_risk_usd)) COMMENT = 'Recoverable / at risk.',
    risk.prior_refresh_recoverable AS SUM(risk.prior_recoverable_usd),
    actions.open_action_recovery AS SUM(actions.open_expected_recovery_usd) WITH SYNONYMS ('expected recovery from actions'),
    actions.approved_action_recovery AS SUM(actions.committed_recovery_usd) WITH SYNONYMS ('approved recovery', 'committed recovery'),
    actions.action_count     AS COUNT(actions.ACTION_ID),
    customers.account_count  AS COUNT(customers.CUSTOMER_ID),
    customers.renewal_arr_total AS SUM(customers.arr_up_for_renewal) COMMENT = 'ARR (not recognized Q4 revenue).'
  )
  COMMENT = 'Revenue Recovery Agent semantic layer over the governed decision tables.'
  AI_SQL_GENERATION 'All money is USD. Current exposure: use revenue_at_risk / recoverable_revenue (already restricted to active items) or filter is_active = TRUE. Category values are exactly PIPELINE, FULFILLMENT, BILLING, RENEWAL, SUPPORT_EXPANSION; treat "support" or "expansion" as SUPPORT_EXPANSION. Renewal values are ARR. Never add recoverable revenue to a forecast and never compute target, forecast, gap or scenarios here; the ExecutiveSnapshot tool owns those. Round USD to whole dollars. Order results by the requested metric descending and limit lists to 20 rows unless asked otherwise.'
  AI_QUESTION_CATEGORIZATION 'Questions about Q4 target, current forecast, forecast gap, base revised outlook or upside recovery case belong to the ExecutiveSnapshot / RecoveryScenario tools, not this semantic view.'
  AI_VERIFIED_QUERIES (
    vq_risk_by_category AS (
      QUESTION 'How much revenue is at risk and recoverable by category?'
      ONBOARDING_QUESTION TRUE
      SQL 'SELECT r.risk_category, SUM(r.AT_RISK_USD) AS revenue_at_risk, SUM(r.RECOVERABLE_USD) AS recoverable_revenue, COUNT(*) AS risk_items FROM risk AS r WHERE r.ACTIVE_FLAG GROUP BY r.risk_category ORDER BY revenue_at_risk DESC'
    ),
    vq_top_recoverable_items AS (
      QUESTION 'Which risk items have the most recoverable revenue?'
      ONBOARDING_QUESTION TRUE
      SQL 'SELECT r.risk_item, r.risk_category, r.customer, r.blocker_reason, r.due_on, r.AT_RISK_USD AS revenue_at_risk, r.RECOVERABLE_USD AS recoverable_revenue, r.owner, r.next_best_action FROM risk AS r WHERE r.ACTIVE_FLAG AND r.RECOVERABLE_USD > 0 ORDER BY r.RECOVERABLE_USD DESC LIMIT 20'
    ),
    vq_customer_exposure AS (
      QUESTION 'Which customers have the highest revenue exposure?'
      ONBOARDING_QUESTION TRUE
      SQL 'SELECT r.customer, SUM(r.AT_RISK_USD) AS revenue_at_risk, SUM(r.RECOVERABLE_USD) AS recoverable_revenue, COUNT(*) AS risk_items, LISTAGG(DISTINCT r.risk_category, '', '') AS categories FROM risk AS r WHERE r.ACTIVE_FLAG GROUP BY r.customer ORDER BY revenue_at_risk DESC LIMIT 15'
    ),
    vq_recoverable_fulfillment AS (
      QUESTION 'Which fulfillment risks can be recovered?'
      SQL 'SELECT r.source_record AS order_id, r.customer, r.product, r.recovery_route, r.due_on, r.AT_RISK_USD AS revenue_at_risk, r.RECOVERABLE_USD AS recoverable_revenue FROM risk AS r WHERE r.ACTIVE_FLAG AND r.CATEGORY = ''FULFILLMENT'' AND r.RECOVERABLE_USD > 0 ORDER BY r.RECOVERABLE_USD DESC'
    ),
    vq_pipeline_opportunity AS (
      QUESTION 'Which pipeline deals have the greatest recovery opportunity?'
      SQL 'SELECT r.source_record AS opportunity_id, r.customer, r.region, r.product_line, r.blocker_reason, r.due_on, r.governed_probability, r.ml_second_opinion_score, r.ml_vs_governed_gap, r.AT_RISK_USD AS revenue_at_risk, r.RECOVERABLE_USD AS recoverable_revenue FROM risk AS r WHERE r.ACTIVE_FLAG AND r.CATEGORY = ''PIPELINE'' ORDER BY r.RECOVERABLE_USD DESC LIMIT 20'
    ),
    vq_billing_clearable AS (
      QUESTION 'Which billing exceptions can be cleared before quarter-end?'
      SQL 'SELECT r.source_record AS billing_id, r.customer, r.blocker_reason AS exception_code, r.recovery_route, r.AT_RISK_USD AS revenue_at_risk, r.RECOVERABLE_USD AS recoverable_revenue FROM risk AS r WHERE r.ACTIVE_FLAG AND r.CATEGORY = ''BILLING'' AND r.RECOVERABLE_USD > 0 ORDER BY r.RECOVERABLE_USD DESC'
    ),
    vq_renewal_risk AS (
      QUESTION 'Which customers are at renewal risk?'
      SQL 'SELECT r.customer, r.due_on AS renewal_date, r.blocker_reason, c.latest_csat, c.usage_change, c.open_escalations, c.ml_usage_anomaly, r.AT_RISK_USD AS arr_at_risk, r.RECOVERABLE_USD AS modeled_recovery FROM risk AS r JOIN customers AS c ON c.CUSTOMER_ID = r.CUSTOMER_ID WHERE r.ACTIVE_FLAG AND r.CATEGORY = ''RENEWAL'' ORDER BY r.AT_RISK_USD DESC'
    ),
    vq_expansion_support AS (
      QUESTION 'Which expansion opportunities are threatened by support issues?'
      SQL 'SELECT r.customer, c.latest_csat, c.open_escalations, r.blocker_reason, r.AT_RISK_USD AS expansion_at_risk, r.RECOVERABLE_USD AS recoverable_revenue FROM risk AS r JOIN customers AS c ON c.CUSTOMER_ID = r.CUSTOMER_ID WHERE r.ACTIVE_FLAG AND r.CATEGORY = ''SUPPORT_EXPANSION'' ORDER BY r.AT_RISK_USD DESC'
    ),
    vq_ml_disagreement AS (
      QUESTION 'Where does ML disagree with our governed recovery probability?'
      SQL 'SELECT r.source_record AS opportunity_id, r.customer, r.blocker_reason, r.governed_probability, r.ml_second_opinion_score AS ml_win_probability, r.ml_vs_governed_gap, r.AT_RISK_USD AS revenue_at_risk FROM risk AS r WHERE r.ACTIVE_FLAG AND r.CATEGORY = ''PIPELINE'' AND ABS(r.ML_GOVERNED_DELTA) >= 0.15 ORDER BY ABS(r.ML_GOVERNED_DELTA) * r.AT_RISK_USD DESC LIMIT 20'
    ),
    vq_top_actions_owners AS (
      QUESTION 'What are the top ten recovery actions and who owns them?'
      SQL 'SELECT a.action_priority, a.action_category, a.recommended_action, a.action_owner, a.first_step_text, a.action_due, a.action_status, a.EXPECTED_RECOVERY_USD AS expected_recovery FROM actions AS a WHERE a.STATUS IN (''PROPOSED'', ''APPROVED'', ''IN_PROGRESS'') ORDER BY a.PRIORITY_RANK LIMIT 10'
    ),
    vq_deteriorating_health AS (
      QUESTION 'Which accounts have deteriorating customer health?'
      SQL 'SELECT c.account_name, c.renewal_on, c.usage_last_4_weeks, c.usage_prior_8_weeks, c.latest_csat, c.open_escalations, c.ml_usage_anomaly, c.LEDGER_AT_RISK_USD AS revenue_at_risk FROM customers AS c WHERE c.HEALTH_DETERIORATING_FLAG OR c.ML_USAGE_ANOMALY_FLAG ORDER BY c.LEDGER_AT_RISK_USD DESC LIMIT 20'
    ),
    vq_what_changed AS (
      QUESTION 'What changed since the previous refresh?'
      SQL 'SELECT r.change_since_last_refresh, r.risk_category, COUNT(*) AS items, SUM(r.RECOVERABLE_USD) AS recoverable_now, SUM(r.PREV_RECOVERABLE_USD) AS recoverable_previous FROM risk AS r GROUP BY r.change_since_last_refresh, r.risk_category ORDER BY r.change_since_last_refresh, r.risk_category'
    )
  );

DESCRIBE SEMANTIC VIEW RR_REVENUE_RISK_SEMANTIC;

-- Semantic view sanity query (should match RR_REVENUE_OUTLOOK category totals)
SELECT * FROM SEMANTIC_VIEW(
  RR_REVENUE_RISK_SEMANTIC
  METRICS risk.revenue_at_risk, risk.recoverable_revenue, risk.risk_item_count
  DIMENSIONS risk.risk_category
) ORDER BY revenue_at_risk DESC;

-- ---------------------------------------------------------------------------
-- 2. Cortex Agent
-- ---------------------------------------------------------------------------
CREATE OR REPLACE AGENT RR_REVENUE_RECOVERY_AGENT
  COMMENT = 'NexaSphere Revenue Recovery Agent: investigates Q4 revenue risk, quantifies recoverable revenue from governed Snowflake data, recommends actions, keeps humans in control.'
  PROFILE = '{"display_name": "Revenue Recovery Agent", "avatar": "chart-icon.png", "color": "blue"}'
  FROM SPECIFICATION
$$
models:
  orchestration: auto

orchestration:
  tool_not_accessible: accept
  budget:
    seconds: 300
    tokens: 200000

instructions:
  orchestration: |
    You are the NexaSphere Technologies Revenue Recovery Agent. You investigate Q4 revenue risk using governed Snowflake tools only.
    Begin every non-trivial answer by stating a one-line analysis plan (which tools, in what order). Never reveal private chain-of-thought.

    MONEY RULES
    - Every dollar figure must come from a tool result. Never add, net, re-sum or estimate money yourself.
    - Target, forecast, gap, gross revenue at risk, modeled recoverable, base recovery, base revised outlook, upside case and remaining gap:
      ALWAYS call ExecutiveSnapshot first and quote its values.
    - Gross revenue at risk is NOT the forecast gap. Never present forecast + recoverable as the new forecast.
      Base Revised Outlook (Pipeline + Fulfillment + Billing) and Upside Recovery Case (all five) are illustrative scenarios, never guaranteed.
    - Renewal values are ARR, not recognized Q4 revenue.
    - Governed recovery probability is authoritative. ML scores are a second opinion; explain disagreements, never substitute them.

    ROUTING (progressive drill-down)
    - "How are we doing vs target?" / "How much is at risk?" -> ExecutiveSnapshot.
    - "Why?" / category, blocker, customer, region, product breakdowns, deal/order/invoice lists -> RevenueRiskAnalyst (semantic view over the risk ledger).
    - "What should we do?" / "top actions" / "who owns" / CRO, CFO, Supply Chain asks -> TrustCheck, then RecoveryActions, then DeepRevenueReasoning.
    - Deep "why" across categories, root cause, ML vs governed comparison, executive narrative -> DeepRevenueReasoning (Claude Opus 5.5 over governed evidence).
    - "What if we recover X, Y, Z?" / base or upside scenario -> RecoveryScenario (pass the user's category words). Do not compute it yourself.
    - "How do we close the rest of the gap?" / bridge from forecast to target -> GapClosurePlan (with ExecutiveSnapshot).
    - "What should we put in place so this does not happen again?" -> PreventionPlan (plus DeepRevenueReasoning for the narrative).
    - Confidence / range / probability of closing the gap -> RecoverySimulation, labelled as statistical and non-authoritative.
    - "What changed since the last refresh?" -> WhatChanged (and RevenueRiskAnalyst for detail).
    - "Show me" / chart / visual -> fetch rows with RevenueRiskAnalyst (or use tool output), then data_to_chart.
    - code_execution only for ad-hoc analysis of data already returned by tools; never to produce authoritative money.
    - Do not query raw source facts; the governed decision layer already contains the evidence.

    TRUST
    - Call TrustCheck before presenting any financial recommendation, action plan or expected impact.
    - If TrustCheck overall_status is FAIL: do not present recommendations or impact; report the failed checks and stop.
    - If WARN: proceed but state the warnings under EVIDENCE / TRUST.

    HUMAN CONTROL
    - You can recommend actions but you cannot approve, reject or execute them. Approval is done by an authorized human
      in the Command Center (SP_APPROVE_RECOVERY_ACTION / SP_REJECT_RECOVERY_ACTION). Never claim an action was approved unless its status says so.
  response: |
    Write for executives: concise, specific, numbers in $M with one decimal exactly as returned by the tools.
    For substantive business questions use these headings in order:
    DIRECT ANSWER; CURRENT POSITION; WHAT IS AT RISK; WHY; WHAT IS RECOVERABLE; TOP ACTIONS; EXPECTED IMPACT; RISKS / CAVEATS; EVIDENCE / TRUST.
    For narrow follow-ups answer directly and keep only the headings that add value.
    Always label Base Revised Outlook and Upside Recovery Case as illustrative. Always distinguish gross revenue at risk from the forecast gap.
    Under EVIDENCE / TRUST list the tools used, the as-of date, and the TrustCheck status.
    Show the analysis plan, evidence and conclusions; do not expose internal reasoning.
  sample_questions:
    - question: "We are forecasting below our Q4 target. How much revenue is at risk before quarter-end, why, and how much can we still recover?"
    - question: "Which category is creating the largest revenue risk?"
    - question: "Which pipeline deals should Sales leadership focus on first?"
    - question: "Which warehouses can resolve component shortages?"
    - question: "Where does ML disagree with our governed recovery probability?"
    - question: "What would the revised outlook be if Pipeline, Fulfillment and Billing recovery succeeds?"
    - question: "Show revenue at risk versus recoverable revenue by category."
    - question: "What should the CRO, CFO and Supply Chain leader do this week?"
    - question: "We are $8.2M short. What can we recover, and how do we close the rest?"
    - question: "What should we put in place so this does not happen again next quarter?"

tools:
  - tool_spec:
      type: "generic"
      name: "ExecutiveSnapshot"
      description: "Authoritative governed Q4 position from RR_REVENUE_OUTLOOK: target, forecast, forecast gap, gross revenue at risk, modeled recoverable, per-category at-risk and recoverable, Base Revised Outlook and Upside Recovery Case, accounting note, last trust status. Call FIRST for any of these numbers."
      input_schema:
        type: "object"
        properties: {}
  - tool_spec:
      type: "cortex_analyst_text_to_sql"
      name: "RevenueRiskAnalyst"
      description: "Cortex Analyst over the RR_REVENUE_RISK_SEMANTIC semantic view (governed risk ledger, customer 360, recovery actions). Use for why/where/which questions: breakdowns by category, blocker, risk class, customer, region, product family, due date, owner; lists of deals, orders, invoices, renewals; ML vs governed comparisons; change since last refresh."
  - tool_spec:
      type: "generic"
      name: "DeepRevenueReasoning"
      description: "Claude Opus 5.5 (AI_COMPLETE) deep analytical reasoning over a compact governed evidence package (snapshot, top risk items, blocker mix, ML disagreements, customer health, warehouse transfers, gap drivers, open actions, trust). Use for root cause across categories, ML vs governed explanations, ranked recommendations and executive narratives. Never computes money."
      input_schema:
        type: "object"
        properties:
          P_QUESTION:
            type: "string"
            description: "The executive's question, verbatim, plus any focus (category, customer, role)."
        required: ["P_QUESTION"]
  - tool_spec:
      type: "generic"
      name: "TrustCheck"
      description: "Runs governed trust validation (config lock, reconciliation, lineage, duplicates, nulls, negatives, actions <= recoverable, AI did not alter money, ML did not overwrite governed probability, freshness, benchmarks). Returns overall_status PASS / WARN / FAIL. Call before any financial recommendation."
      input_schema:
        type: "object"
        properties: {}
  - tool_spec:
      type: "generic"
      name: "RecoveryActions"
      description: "Ranked recovery actions with category, customer, action, owner role, first step, due date, governed expected recovery, status and decision attribution. Use for top-N actions, owners, expected recovery of top actions."
      input_schema:
        type: "object"
        properties:
          P_TOP_N:
            type: "number"
            description: "How many actions to return (default 10)."
          P_STATUS:
            type: "string"
            description: "OPEN (default: proposed + approved), PROPOSED, APPROVED, REJECTED or ALL."
        required: ["P_TOP_N", "P_STATUS"]
  - tool_spec:
      type: "generic"
      name: "RecoveryScenario"
      description: "Governed what-if: illustrative outlook and remaining gap if the listed categories recover their modeled recoverable value. Accepts BASE, UPSIDE, or category words such as 'Pipeline, Fulfillment and Billing'."
      input_schema:
        type: "object"
        properties:
          P_CATEGORIES:
            type: "string"
            description: "BASE, UPSIDE, or a comma/and separated list of categories."
        required: ["P_CATEGORIES"]
  - tool_spec:
      type: "generic"
      name: "RecoverySimulation"
      description: "Monte Carlo range (P10/P50/P90) of recovery for chosen categories using governed per-item probabilities, plus probability of covering the forecast gap. Statistical and non-authoritative."
      input_schema:
        type: "object"
        properties:
          P_CATEGORIES:
            type: "string"
            description: "BASE, UPSIDE, or category list."
          P_ITERATIONS:
            type: "number"
            description: "Simulation iterations, 1000-100000 (default 10000)."
        required: ["P_CATEGORIES", "P_ITERATIONS"]
  - tool_spec:
      type: "generic"
      name: "WhatChanged"
      description: "Changes since the previous refresh: counts of NEW/CHANGED/UNCHANGED/RESOLVED items, largest recoverable movements and category totals current vs previous."
      input_schema:
        type: "object"
        properties: {}
  - tool_spec:
      type: "generic"
      name: "GapClosurePlan"
      description: "Gap-closure bridge from current forecast to target: recovery steps by category (governed base categories first, then modeled upside), cumulative illustrative outlook, remaining gap, and Monte Carlo probability of closing the gap after each step."
      input_schema:
        type: "object"
        properties: {}
  - tool_spec:
      type: "generic"
      name: "PreventionPlan"
      description: "Prevention controls proposed for the recurring blocker classes behind this quarter's risk, with owner, estimated preventable exposure (estimate) and launch status. Launching is a human decision."
      input_schema:
        type: "object"
        properties: {}
  - tool_spec:
      type: "data_to_chart"
      name: "data_to_chart"
      description: "Generates charts from data returned by other tools (e.g. revenue at risk vs recoverable by category)."
  - tool_spec:
      type: "code_execution"
      name: "code_execution"

tool_resources:
  ExecutiveSnapshot:
    type: "procedure"
    identifier: "HACKATHON_REVENUE_RISK.SOLUTION.SP_GET_EXECUTIVE_SNAPSHOT"
    execution_environment:
      type: "warehouse"
      warehouse: "RR_WH"
      query_timeout: 60
  RevenueRiskAnalyst:
    semantic_view: "HACKATHON_REVENUE_RISK.SOLUTION.RR_REVENUE_RISK_SEMANTIC"
    execution_environment:
      type: "warehouse"
      warehouse: "RR_WH"
      query_timeout: 120
  DeepRevenueReasoning:
    type: "procedure"
    identifier: "HACKATHON_REVENUE_RISK.SOLUTION.SP_DEEP_REVENUE_REASONING"
    execution_environment:
      type: "warehouse"
      warehouse: "RR_WH"
      query_timeout: 300
  TrustCheck:
    type: "procedure"
    identifier: "HACKATHON_REVENUE_RISK.SOLUTION.SP_RR_TRUST_CHECK"
    execution_environment:
      type: "warehouse"
      warehouse: "RR_WH"
      query_timeout: 120
  RecoveryActions:
    type: "procedure"
    identifier: "HACKATHON_REVENUE_RISK.SOLUTION.SP_GET_RECOVERY_ACTIONS"
    execution_environment:
      type: "warehouse"
      warehouse: "RR_WH"
      query_timeout: 60
  RecoveryScenario:
    type: "procedure"
    identifier: "HACKATHON_REVENUE_RISK.SOLUTION.SP_RECOVERY_SCENARIO"
    execution_environment:
      type: "warehouse"
      warehouse: "RR_WH"
      query_timeout: 60
  RecoverySimulation:
    type: "procedure"
    identifier: "HACKATHON_REVENUE_RISK.SOLUTION.SP_SIMULATE_RECOVERY"
    execution_environment:
      type: "warehouse"
      warehouse: "RR_WH"
      query_timeout: 120
  WhatChanged:
    type: "procedure"
    identifier: "HACKATHON_REVENUE_RISK.SOLUTION.SP_WHAT_CHANGED"
    execution_environment:
      type: "warehouse"
      warehouse: "RR_WH"
      query_timeout: 60
  GapClosurePlan:
    type: "procedure"
    identifier: "HACKATHON_REVENUE_RISK.SOLUTION.SP_GET_GAP_PLAN"
    execution_environment:
      type: "warehouse"
      warehouse: "RR_WH"
      query_timeout: 60
  PreventionPlan:
    type: "procedure"
    identifier: "HACKATHON_REVENUE_RISK.SOLUTION.SP_GET_PREVENTION_PLAN"
    execution_environment:
      type: "warehouse"
      warehouse: "RR_WH"
      query_timeout: 60
  code_execution:
    permission_policy:
      type: "always_ask"
$$;

DESCRIBE AGENT RR_REVENUE_RECOVERY_AGENT;
SHOW AGENTS LIKE 'RR_REVENUE_RECOVERY_AGENT' IN SCHEMA HACKATHON_REVENUE_RISK.SOLUTION;

-- ---------------------------------------------------------------------------
-- 3. Access for executives (adjust role names) + Snowflake CoWork surfacing
-- ---------------------------------------------------------------------------
-- GRANT USAGE ON AGENT RR_REVENUE_RECOVERY_AGENT TO ROLE RR_AGENT_USER;
-- GRANT SELECT ON SEMANTIC VIEW RR_REVENUE_RISK_SEMANTIC TO ROLE RR_AGENT_USER;
--
-- CoWork is the executive surface; the agent above is the decision orchestrator.
-- CoWork lists agents registered with the account's Snowflake Intelligence object.
-- If your account uses that object (verify in Snowsight > AI & ML > Agents > Settings):
-- ALTER SNOWFLAKE INTELLIGENCE SNOWFLAKE_INTELLIGENCE_OBJECT_DEFAULT
--   ADD AGENT HACKATHON_REVENUE_RISK.SOLUTION.RR_REVENUE_RECOVERY_AGENT;
-- Otherwise follow the CoWork getting-started guide, which places agents in SNOWFLAKE_INTELLIGENCE.AGENTS.

-- ---------------------------------------------------------------------------
-- 4. OPTIONAL: pin Claude Opus 5.5 as the orchestration model (public preview).
--    Only if SHOW CORTEX BASE MODELS / the Agents model table lists it for your
--    region. Re-run section 2 with `orchestration: claude-opus-5-5` and then:
--    UPDATE RR_CONFIG SET AGENT_ORCHESTRATION_MODEL = 'claude-opus-5-5';
--    (13_AGENT_TESTS checks the deployed agent matches RR_CONFIG.)
-- ---------------------------------------------------------------------------
