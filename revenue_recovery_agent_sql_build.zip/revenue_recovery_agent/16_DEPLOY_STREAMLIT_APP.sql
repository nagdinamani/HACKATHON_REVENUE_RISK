/* =============================================================================
   16_DEPLOY_STREAMLIT_APP.sql   —   S7.3 Deploy the Streamlit app
   Reproduces streamlit_deploy.md (reference script) for the SOLUTION schema
   used by this build (the reference used DEMO).

   Goal: the files in rr_build/streamlit/ run as the Streamlit in Snowflake app
   REVENUE_AT_RISK_APP in HACKATHON_REVENUE_RISK.SOLUTION, warehouse runtime, RR_WH.

   Files that must be on the stage (same relative paths):
     app.py, ui_common.py, rr_backend.py,
     ask_agent_page.py, overview_page.py, action_board_page.py, trace_page.py, architecture_page.py,
     environment.yml, .streamlit/config.toml

   Prerequisites: 00A–13 and 15 have run (15 creates RR_REVENUE_RECOVERY_APP_AGENT
   and SP_REFRESH_ANALYTICS used by the app).
   ============================================================================= */

USE ROLE ACCOUNTADMIN;
USE WAREHOUSE RR_WH;
USE SCHEMA HACKATHON_REVENUE_RISK.SOLUTION;

CREATE STAGE IF NOT EXISTS RR_APP_STAGE
  DIRECTORY = (ENABLE = TRUE)
  COMMENT = 'Source files of the Revenue-at-Risk Streamlit app';

-- If RR_APP_STAGE already existed from 14 without a directory table:
ALTER STAGE RR_APP_STAGE SET DIRECTORY = (ENABLE = TRUE);

-- Files get onto the stage in one of three ways:
--   A) Copy from the workspace (CoCo), if the workspace supports it
--   B) Manual upload: Horizon Catalog > Catalog > HACKATHON_REVENUE_RISK > SOLUTION > Stages > RR_APP_STAGE > + Files
--      (upload config.toml into the folder .streamlit/)
--   C) From Git: COPY FILES INTO @RR_APP_STAGE FROM @RR_REPO/branches/main/rr_build/streamlit/;
--   D) SnowSQL / Snowflake CLI from a machine holding rr_build/streamlit/ (run from that folder):
--        PUT file://app.py                @RR_APP_STAGE                AUTO_COMPRESS = FALSE OVERWRITE = TRUE;
--        PUT file://ui_common.py          @RR_APP_STAGE                AUTO_COMPRESS = FALSE OVERWRITE = TRUE;
--        PUT file://rr_backend.py         @RR_APP_STAGE                AUTO_COMPRESS = FALSE OVERWRITE = TRUE;
--        PUT file://ask_agent_page.py     @RR_APP_STAGE                AUTO_COMPRESS = FALSE OVERWRITE = TRUE;
--        PUT file://overview_page.py      @RR_APP_STAGE                AUTO_COMPRESS = FALSE OVERWRITE = TRUE;
--        PUT file://action_board_page.py  @RR_APP_STAGE                AUTO_COMPRESS = FALSE OVERWRITE = TRUE;
--        PUT file://trace_page.py         @RR_APP_STAGE                AUTO_COMPRESS = FALSE OVERWRITE = TRUE;
--        PUT file://architecture_page.py  @RR_APP_STAGE                AUTO_COMPRESS = FALSE OVERWRITE = TRUE;
--        PUT file://environment.yml       @RR_APP_STAGE                AUTO_COMPRESS = FALSE OVERWRITE = TRUE;
--        PUT file://.streamlit/config.toml @RR_APP_STAGE/.streamlit   AUTO_COMPRESS = FALSE OVERWRITE = TRUE;
--      or: snow stage copy . @HACKATHON_REVENUE_RISK.SOLUTION.RR_APP_STAGE --recursive --overwrite

ALTER STAGE RR_APP_STAGE REFRESH;
LIST @RR_APP_STAGE;

-- Acceptance: exactly these 10 files (fails loudly if any is missing)
SELECT f.REL_PATH,
       IFF(d.RELATIVE_PATH IS NULL, 'MISSING', 'OK') AS STATUS
FROM (SELECT COLUMN1 AS REL_PATH FROM VALUES
        ('app.py'), ('ui_common.py'), ('rr_backend.py'), ('ask_agent_page.py'), ('overview_page.py'),
        ('action_board_page.py'), ('trace_page.py'), ('architecture_page.py'), ('environment.yml'),
        ('.streamlit/config.toml')) f
LEFT JOIN DIRECTORY(@RR_APP_STAGE) d ON d.RELATIVE_PATH = f.REL_PATH
ORDER BY STATUS DESC, f.REL_PATH;

CREATE OR REPLACE STREAMLIT REVENUE_AT_RISK_APP
  FROM '@HACKATHON_REVENUE_RISK.SOLUTION.RR_APP_STAGE'
  MAIN_FILE = 'app.py'
  QUERY_WAREHOUSE = RR_WH
  TITLE = 'Revenue-at-Risk Agent'
  COMMENT = 'NexaSphere Command Center: Cortex Agent + governed decision engine';

SHOW STREAMLITS LIKE 'REVENUE_AT_RISK_APP';

-- Viewer access (approvers only: the app runs with the owner's rights, so its
-- Approve / Reject / Start / Done / Launch buttons act with the owner's role):
-- GRANT USAGE ON STREAMLIT REVENUE_AT_RISK_APP TO ROLE RR_APPROVER;

-- Acceptance checks:
--   * the SELECT above shows all 10 files as OK, including .streamlit/config.toml
--   * Projects -> Streamlit -> REVENUE_AT_RISK_APP opens on "Ask the Agent"
