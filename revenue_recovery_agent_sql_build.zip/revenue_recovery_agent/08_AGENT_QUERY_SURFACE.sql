/* =============================================================================
   08_AGENT_QUERY_SURFACE.sql
   Read-only custom tools for the Cortex Agent (all return JSON text).

     SP_GET_EXECUTIVE_SNAPSHOT()          authoritative position from RR_REVENUE_OUTLOOK (call FIRST)
     SP_DEEP_REVENUE_REASONING(question)  compact governed evidence package -> AI_COMPLETE claude-opus-5-5
     SP_GET_RECOVERY_ACTIONS(top_n, status) ranked actions with owners, first steps, governed values
     SP_RECOVERY_SCENARIO(categories)     governed what-if: forecast + recovery of chosen categories
     SP_SIMULATE_RECOVERY(categories, n)  Monte Carlo spread of recovery (statistical, non-authoritative)
     SP_WHAT_CHANGED()                    change since previous refresh (ledger CHANGE_STATUS + audit)
     SP_GET_GAP_PLAN()                    gap-closure bridge (RR_GAP_PLAN) with probability per step
     SP_GET_PREVENTION_PLAN()             proposed / launched prevention controls (RR_PREVENTION_PLAN)

   None of these procedures writes money. The agent receives NO approve/reject tool.
   ============================================================================= */

USE DATABASE HACKATHON_REVENUE_RISK;
USE SCHEMA SOLUTION;
USE WAREHOUSE RR_WH;

-- ---------------------------------------------------------------------------
-- ExecutiveSnapshot
-- ---------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE SP_GET_EXECUTIVE_SNAPSHOT()
RETURNS VARCHAR
LANGUAGE SQL
COMMENT = 'Authoritative Q4 target, forecast, gap, gross risk, recoverable, base and upside scenarios. Agent must call this before stating any of these numbers.'
AS
$$
DECLARE
  result VARIANT;
BEGIN
  SELECT OBJECT_CONSTRUCT(
    'source', 'RR_REVENUE_OUTLOOK (governed SQL; authoritative)',
    'as_of_date', o.AS_OF_DATE, 'quarter_start', o.QTR_START, 'quarter_end', o.QTR_END,
    'plan_scenario', o.PLAN_SCENARIO_ID,
    'current_position', OBJECT_CONSTRUCT(
        'q4_target_usd', o.Q4_TARGET_USD, 'q4_forecast_usd', o.Q4_FORECAST_USD,
        'forecast_gap_usd', o.FORECAST_GAP_USD, 'q4_actual_to_date_usd', o.Q4_ACTUAL_TO_DATE_USD),
    'revenue_at_risk', OBJECT_CONSTRUCT(
        'gross_at_risk_usd', o.GROSS_AT_RISK_USD, 'modeled_recoverable_usd', o.MODELED_RECOVERABLE_USD,
        'no_recovery_path_usd', o.NO_PATH_USD, 'risk_item_count', o.RISK_ITEM_COUNT),
    'by_category', ARRAY_CONSTRUCT(
        OBJECT_CONSTRUCT('category', 'PIPELINE', 'label', 'Pipeline', 'at_risk_usd', o.PIPELINE_AT_RISK_USD, 'recoverable_usd', o.PIPELINE_RECOVERABLE_USD, 'value_basis', 'bookings'),
        OBJECT_CONSTRUCT('category', 'FULFILLMENT', 'label', 'Fulfillment', 'at_risk_usd', o.FULFILLMENT_AT_RISK_USD, 'recoverable_usd', o.FULFILLMENT_RECOVERABLE_USD, 'value_basis', 'orders'),
        OBJECT_CONSTRUCT('category', 'BILLING', 'label', 'Billing', 'at_risk_usd', o.BILLING_AT_RISK_USD, 'recoverable_usd', o.BILLING_RECOVERABLE_USD, 'value_basis', 'invoices'),
        OBJECT_CONSTRUCT('category', 'RENEWAL', 'label', 'Renewal', 'at_risk_usd', o.RENEWAL_AT_RISK_USD, 'recoverable_usd', o.RENEWAL_RECOVERABLE_USD, 'value_basis', 'ARR (not recognized Q4 revenue)'),
        OBJECT_CONSTRUCT('category', 'SUPPORT_EXPANSION', 'label', 'Support / Expansion', 'at_risk_usd', o.SUPPORT_EXPANSION_AT_RISK_USD, 'recoverable_usd', o.SUPPORT_EXPANSION_RECOVERABLE_USD, 'value_basis', 'expansion')),
    'scenarios', OBJECT_CONSTRUCT(
        'base_revised_outlook', OBJECT_CONSTRUCT(
            'label', 'Base Revised Outlook', 'nature', 'Illustrative governed base case, not a forecast',
            'categories', o.BASE_RECOVERY_CATEGORIES, 'recovery_usd', o.BASE_RECOVERY_USD,
            'outlook_usd', o.BASE_REVISED_OUTLOOK_USD, 'remaining_gap_usd', o.BASE_REMAINING_GAP_USD),
        'upside_recovery_case', OBJECT_CONSTRUCT(
            'label', 'Upside Recovery Case', 'nature', 'Illustrative maximum modeled recovery, never a guaranteed forecast',
            'categories', 'PIPELINE,FULFILLMENT,BILLING,RENEWAL,SUPPORT_EXPANSION', 'recovery_usd', o.UPSIDE_RECOVERY_USD,
            'outlook_usd', o.UPSIDE_OUTLOOK_USD, 'remaining_gap_usd', o.UPSIDE_REMAINING_GAP_USD)),
    'display_usd_millions', OBJECT_CONSTRUCT(
        'q4_target', '$' || TO_VARCHAR(ROUND(o.Q4_TARGET_USD / 1000000, 1)) || 'M',
        'q4_forecast', '$' || TO_VARCHAR(ROUND(o.Q4_FORECAST_USD / 1000000, 1)) || 'M',
        'forecast_gap', '$' || TO_VARCHAR(ROUND(o.FORECAST_GAP_USD / 1000000, 1)) || 'M',
        'gross_at_risk', '$' || TO_VARCHAR(ROUND(o.GROSS_AT_RISK_USD / 1000000, 1)) || 'M',
        'modeled_recoverable', '$' || TO_VARCHAR(ROUND(o.MODELED_RECOVERABLE_USD / 1000000, 1)) || 'M',
        'pipeline', '$' || TO_VARCHAR(ROUND(o.PIPELINE_AT_RISK_USD / 1000000, 1)) || 'M / $' || TO_VARCHAR(ROUND(o.PIPELINE_RECOVERABLE_USD / 1000000, 1)) || 'M',
        'fulfillment', '$' || TO_VARCHAR(ROUND(o.FULFILLMENT_AT_RISK_USD / 1000000, 1)) || 'M / $' || TO_VARCHAR(ROUND(o.FULFILLMENT_RECOVERABLE_USD / 1000000, 1)) || 'M',
        'billing', '$' || TO_VARCHAR(ROUND(o.BILLING_AT_RISK_USD / 1000000, 1)) || 'M / $' || TO_VARCHAR(ROUND(o.BILLING_RECOVERABLE_USD / 1000000, 1)) || 'M',
        'renewal', '$' || TO_VARCHAR(ROUND(o.RENEWAL_AT_RISK_USD / 1000000, 1)) || 'M / $' || TO_VARCHAR(ROUND(o.RENEWAL_RECOVERABLE_USD / 1000000, 1)) || 'M',
        'support_expansion', '$' || TO_VARCHAR(ROUND(o.SUPPORT_EXPANSION_AT_RISK_USD / 1000000, 1)) || 'M / $' || TO_VARCHAR(ROUND(o.SUPPORT_EXPANSION_RECOVERABLE_USD / 1000000, 1)) || 'M',
        'base_recovery', '$' || TO_VARCHAR(ROUND(o.BASE_RECOVERY_USD / 1000000, 1)) || 'M',
        'base_revised_outlook', '$' || TO_VARCHAR(ROUND(o.BASE_REVISED_OUTLOOK_USD / 1000000, 1)) || 'M',
        'base_remaining_gap', '$' || TO_VARCHAR(ROUND(o.BASE_REMAINING_GAP_USD / 1000000, 1)) || 'M',
        'upside_outlook', '$' || TO_VARCHAR(ROUND(o.UPSIDE_OUTLOOK_USD / 1000000, 1)) || 'M',
        'upside_remaining_gap', '$' || TO_VARCHAR(ROUND(o.UPSIDE_REMAINING_GAP_USD / 1000000, 1)) || 'M'),
    'ml_second_opinion', OBJECT_CONSTRUCT(
        'q4_ml_revenue_forecast_usd', m.F, 'q4_ml_revenue_p10_usd', m.P10, 'q4_ml_revenue_p90_usd', m.P90,
        'ml_probability_of_hitting_target', IFF(m.SD > 0, ROUND(1 / (1 + EXP(-1.702 * ((m.F - o.Q4_TARGET_USD) / m.SD))), 4), NULL),
        'revenue_forecast_method', m.M,
        'q4_shipments_to_date_usd', o.ML_Q4_SHIPMENTS_TO_DATE_USD,
        'q4_shipments_projected_usd', o.ML_Q4_SHIPMENTS_PROJECTED_USD,
        'method', o.ML_REVENUE_METHOD,
        'note', 'Second opinion only; never replaces the governed plan forecast. Probability uses a normal approximation of the summed monthly P10-P90 bands. Shipment figures are a run-rate, not comparable 1:1 with plan revenue.'),
    'accounting_note', o.ACCOUNTING_NOTE,
    'last_trust_status', (SELECT MAX_BY(STATUS, ENDED_AT) FROM RR_REFRESH_AUDIT WHERE STAGE = 'TRUST'),
    'refresh_id', o.REFRESH_ID, 'refreshed_at', o.REFRESHED_AT)
  INTO :result
  FROM RR_REVENUE_OUTLOOK o
  CROSS JOIN (
    SELECT SUM(ML_FORECAST_USD) AS F, SUM(ML_P10_USD) AS P10, SUM(ML_P90_USD) AS P90,
           SQRT(SUM(POWER((ML_P90_USD - ML_P10_USD) / 2.5631, 2))) AS SD, ANY_VALUE(ML_METHOD) AS M
    FROM RR_ML_PLAN_FORECAST
  ) m;
  RETURN TO_JSON(result);
END;
$$;

-- ---------------------------------------------------------------------------
-- DeepRevenueReasoning (Claude Opus 5.5 over governed evidence)
-- ---------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE SP_DEEP_REVENUE_REASONING(P_QUESTION VARCHAR)
RETURNS VARCHAR
LANGUAGE SQL
COMMENT = 'Builds a compact governed evidence package and asks claude-opus-5-5 (AI_COMPLETE) for root-cause, ML-vs-governed comparison, ranked actions and caveats. Never computes money.'
AS
$$
DECLARE
  model     VARCHAR;
  focus     VARCHAR;
  snapshot  VARCHAR;
  evidence  VARIANT;
  prompt    VARCHAR;
  answer    VARCHAR;
  trust_st  VARCHAR;
  result    VARIANT;
BEGIN
  SELECT AI_MODEL INTO :model FROM RR_CONFIG WHERE CONFIG_ID = 1;
  CALL SP_GET_EXECUTIVE_SNAPSHOT() INTO :snapshot;

  -- Question-aware focus: add extra items for the categories the question is about
  SELECT ARRAY_TO_STRING(ARRAY_CONSTRUCT_COMPACT(
           IFF(q ILIKE ANY ('%pipeline%', '%deal%', '%opportunit%', '%sales%', '%cro%'), 'PIPELINE', NULL),
           IFF(q ILIKE ANY ('%fulfil%', '%order%', '%warehouse%', '%inventory%', '%supply%', '%shortage%'), 'FULFILLMENT', NULL),
           IFF(q ILIKE ANY ('%bill%', '%invoice%', '%exception%', '%cfo%', '%cash%'), 'BILLING', NULL),
           IFF(q ILIKE ANY ('%renew%', '%churn%', '%arr%', '%health%', '%usage%'), 'RENEWAL', NULL),
           IFF(q ILIKE ANY ('%support%', '%expansion%', '%csat%', '%escalat%', '%health%'), 'SUPPORT_EXPANSION', NULL)), ',')
    INTO :focus
    FROM (SELECT COALESCE(:P_QUESTION, '') AS q);

  SELECT OBJECT_CONSTRUCT(
    'executive_snapshot', PARSE_JSON(:snapshot),
    'trust', (SELECT OBJECT_CONSTRUCT('status', MAX_BY(STATUS, ENDED_AT), 'checked_at', MAX(ENDED_AT),
                                      'failed_checks', MAX_BY(DETAILS:failed_checks, ENDED_AT))
                FROM RR_REFRESH_AUDIT WHERE STAGE = 'TRUST'),
    'category_briefs', (SELECT OBJECT_AGG(CATEGORY, BRIEF::VARIANT) FROM RR_AI_CATEGORY_BRIEFS),
    'blocker_mix', (SELECT ARRAY_AGG(OBJECT_CONSTRUCT('category', CATEGORY, 'risk_class', RC, 'items', N,
                                                      'at_risk_usd', AR, 'recoverable_usd', REC))
                             WITHIN GROUP (ORDER BY AR DESC)
                    FROM (SELECT CATEGORY, COALESCE(AI_RISK_CLASS, BLOCKER) AS RC, COUNT(*) AS N,
                                 SUM(AT_RISK_USD) AS AR, SUM(RECOVERABLE_USD) AS REC
                            FROM RR_RISK_LEDGER WHERE ACTIVE_FLAG GROUP BY 1, 2
                          QUALIFY ROW_NUMBER() OVER (ORDER BY SUM(AT_RISK_USD) DESC) <= 20)),
    'top_risk_items', (SELECT ARRAY_AGG(OBJECT_CONSTRUCT(
                         'risk_item_id', RISK_ITEM_ID, 'category', CATEGORY, 'customer', CUSTOMER_NAME,
                         'region', REGION_NAME, 'product_family', PRODUCT_FAMILY, 'blocker', BLOCKER,
                         'risk_class', AI_RISK_CLASS, 'at_risk_usd', AT_RISK_USD, 'recoverable_usd', RECOVERABLE_USD,
                         'governed_recovery_prob', RECOVERY_PROB, 'ml_score', ML_SCORE, 'ml_score_type', ML_SCORE_TYPE,
                         'ml_minus_governed', ML_GOVERNED_DELTA, 'due_date', DUE_DATE, 'days_to_due', DAYS_TO_DUE,
                         'recovery_path', RECOVERY_PATH, 'evidence', EVIDENCE_TEXT, 'ai_summary', AI_SUMMARY,
                         'owner', AI_OWNER_ROLE)) WITHIN GROUP (ORDER BY RECOVERABLE_USD DESC)
                       FROM (SELECT l.*,
                                    ROW_NUMBER() OVER (ORDER BY RECOVERABLE_USD DESC, AT_RISK_USD DESC) AS RN_ALL,
                                    ROW_NUMBER() OVER (PARTITION BY CATEGORY ORDER BY RECOVERABLE_USD DESC, AT_RISK_USD DESC) AS RN_CAT
                               FROM RR_RISK_LEDGER l WHERE ACTIVE_FLAG)
                      WHERE RN_ALL <= 15 OR RN_CAT <= 3
                         OR (RN_CAT <= 10 AND POSITION(',' || CATEGORY || ',' IN ',' || :focus || ',') > 0)),
    'ml_vs_governed_disagreements', (SELECT ARRAY_AGG(OBJECT_CONSTRUCT(
                         'opportunity_id', OPPORTUNITY_ID, 'customer', CUSTOMER_NAME, 'stage', STAGE_NAME,
                         'amount_usd', OPPORTUNITY_AMOUNT, 'governed_recovery_prob', GOVERNED_RECOVERY_PROB,
                         'ml_win_prob', ML_WIN_PROB, 'ml_minus_governed', ML_MINUS_GOVERNED, 'ml_method', ML_METHOD,
                         'blocker', RISK_REASON)) WITHIN GROUP (ORDER BY ABS(ML_MINUS_GOVERNED) * OPPORTUNITY_AMOUNT DESC)
                       FROM (SELECT * FROM RR_OPPORTUNITY_360 WHERE IN_RISK_LEDGER AND ML_DISAGREEMENT_FLAG
                             QUALIFY ROW_NUMBER() OVER (ORDER BY ABS(ML_MINUS_GOVERNED) * OPPORTUNITY_AMOUNT DESC) <= 10)),
    'customer_health_signals', (SELECT ARRAY_AGG(OBJECT_CONSTRUCT(
                         'customer', CUSTOMER_NAME, 'renewal_date', RENEWAL_DATE, 'usage_last_4w', USAGE_AVG_LAST_4W,
                         'usage_prior_8w', USAGE_AVG_PRIOR_8W, 'csat', CSAT, 'open_p1_p2', OPEN_P1_P2,
                         'ml_usage_anomaly', ML_USAGE_ANOMALY_FLAG, 'ledger_at_risk_usd', LEDGER_AT_RISK_USD))
                       FROM (SELECT * FROM RR_CUSTOMER_360 WHERE HEALTH_DETERIORATING_FLAG OR ML_USAGE_ANOMALY_FLAG
                             QUALIFY ROW_NUMBER() OVER (ORDER BY LEDGER_AT_RISK_USD DESC) <= 10)),
    'warehouse_transfers', (SELECT ARRAY_AGG(OBJECT_CONSTRUCT('alternate_warehouse', ALTERNATE_WAREHOUSE,
                                    'orders_recovered', N, 'units', U, 'booked_value_usd', V))
                            FROM (SELECT ALTERNATE_WAREHOUSE, COUNT(*) AS N, SUM(ALLOCATED_QTY) AS U, SUM(BOOKED_VALUE) AS V
                                    FROM RR_FULFILLMENT_ALLOCATION WHERE COVERED_FLAG GROUP BY 1)),
    'forecast_gap_drivers', (SELECT ARRAY_AGG(OBJECT_CONSTRUCT('segment', CONTRIBUTOR, 'target_usd', METRIC_CONTROL_TARGET,
                                    'forecast_usd', METRIC_TEST_FORECAST, 'contribution_usd', CONTRIBUTION, 'method', ML_METHOD))
                                    WITHIN GROUP (ORDER BY DRIVER_RANK)
                             FROM (SELECT * FROM RR_ML_GAP_DRIVERS WHERE DRIVER_RANK <= 8)),
    'open_actions', (SELECT ARRAY_AGG(OBJECT_CONSTRUCT('rank', PRIORITY_RANK, 'action_id', ACTION_ID, 'category', CATEGORY,
                                    'customer', CUSTOMER_NAME, 'action', ACTION_TEXT, 'owner', OWNER_ROLE,
                                    'first_step', FIRST_STEP, 'due_date', DUE_DATE,
                                    'expected_recovery_usd', EXPECTED_RECOVERY_USD, 'status', STATUS))
                                    WITHIN GROUP (ORDER BY PRIORITY_RANK)
                     FROM (SELECT * FROM RR_RECOVERY_ACTIONS WHERE STATUS IN ('PROPOSED', 'APPROVED', 'IN_PROGRESS') AND PRIORITY_RANK <= 15)),
    'gap_closure_plan', (SELECT ARRAY_AGG(OBJECT_CONSTRUCT('step', STEP_ORDER, 'category', CATEGORY, 'label', STEP_LABEL,
                                    'expected_usd', EXPECTED_USD, 'cumulative_forecast_usd', CUMULATIVE_FORECAST_USD,
                                    'remaining_gap_usd', REMAINING_GAP_USD, 'needs_approval', NEEDS_APPROVAL,
                                    'prob_close_gap_cumulative', PROB_CLOSE_GAP_CUMULATIVE)) WITHIN GROUP (ORDER BY STEP_ORDER)
                         FROM RR_GAP_PLAN),
    'prevention_plan', (SELECT ARRAY_AGG(OBJECT_CONSTRUCT('control_id', CONTROL_ID, 'category', CATEGORY, 'risk_class', RISK_CLASS,
                                    'control', CONTROL_NAME, 'owner', OWNER, 'est_preventable_usd', EST_PREVENTABLE_USD,
                                    'status', STATUS)) WITHIN GROUP (ORDER BY EST_PREVENTABLE_USD DESC)
                        FROM RR_PREVENTION_PLAN WHERE STATUS IN ('PROPOSED', 'LAUNCHED')),
    'changes_since_previous_refresh', (SELECT OBJECT_AGG(CHANGE_STATUS, N::VARIANT)
                                       FROM (SELECT CHANGE_STATUS, COUNT(*) AS N FROM RR_RISK_LEDGER GROUP BY 1)))
  INTO :evidence;

  prompt := 'You are the deep-reasoning analyst inside the NexaSphere Technologies Revenue Recovery Agent. '
    || 'You receive a governed evidence package computed by Snowflake SQL, Snowflake ML (second opinion) and Cortex AI enrichment.\n\n'
    || 'NON-NEGOTIABLE RULES\n'
    || '1. Do not invent money. Every dollar figure you state must appear verbatim in the evidence (you may convert to $M with one decimal).\n'
    || '2. Do not recalculate, re-add, net or alter any Snowflake value. If a needed figure is absent, say "not in governed evidence" and name the tool/table that would provide it.\n'
    || '3. Gross revenue at risk is NOT the forecast gap. Base Revised Outlook and Upside Recovery Case are illustrative scenarios, never guaranteed forecasts. Renewal values are ARR.\n'
    || '4. Clearly separate EVIDENCE (facts from the package) from INFERENCE (your interpretation). Label inferences.\n'
    || '5. Governed recovery probability is authoritative; ML is a second opinion. Explain material disagreements and what would resolve them; never substitute ML values.\n'
    || '6. If trust.status is FAIL, state that financial recommendations are withheld and list the failed checks instead.\n'
    || '7. Do not reveal private chain-of-thought; present the analysis plan, evidence and conclusions.\n\n'
    || 'TASK: answer the question below. Explain root causes across categories, compare ML vs governed evidence, rank the most credible actions '
    || '(highest recoverable value, nearest deadline, clearest owner), identify caveats, and state which additional governed evidence would raise confidence.\n\n'
    || 'FORMAT (executive, concise, markdown headings): DIRECT ANSWER; CURRENT POSITION; WHAT IS AT RISK; WHY; WHAT IS RECOVERABLE; '
    || 'TOP ACTIONS; EXPECTED IMPACT; RISKS / CAVEATS; EVIDENCE / TRUST.\n\n'
    || 'QUESTION: ' || COALESCE(P_QUESTION, 'Summarize the Q4 revenue recovery position.') || '\n\n'
    || 'GOVERNED EVIDENCE (JSON):\n' || TO_JSON(evidence);

  SELECT AI_COMPLETE(:model, :prompt, {'max_tokens': 4096}) INTO :answer;
  SELECT GET_PATH(:evidence, 'trust.status')::VARCHAR INTO :trust_st;

  result := OBJECT_CONSTRUCT(
    'tool', 'DeepRevenueReasoning',
    'model', model,
    'question', P_QUESTION,
    'focus_categories', focus,
    'answer', answer,
    'guardrails', 'Money values originate from RR_REVENUE_OUTLOOK / RR_RISK_LEDGER; the model was instructed not to compute or alter them.',
    'trust_status', trust_st);

  INSERT INTO AGENT_ACTIONS (LOG_ID, ACTED_AT, ACTOR, ACTOR_ROLE, SURFACE, ACTION_TYPE, TARGET_OBJECT, TARGET_ID, PAYLOAD)
  SELECT UUID_STRING(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, CURRENT_USER(), CURRENT_ROLE(), 'RR_AGENT_TOOL',
         'DEEP_REVENUE_REASONING', 'SP_DEEP_REVENUE_REASONING', NULL,
         OBJECT_CONSTRUCT('question', :P_QUESTION, 'model', :model, 'focus', :focus,
                          'answer_chars', LENGTH(:answer));

  RETURN TO_JSON(result);
END;
$$;

-- ---------------------------------------------------------------------------
-- RecoveryActions (read-only)
-- ---------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE SP_GET_RECOVERY_ACTIONS(P_TOP_N NUMBER, P_STATUS VARCHAR)
RETURNS VARCHAR
LANGUAGE SQL
COMMENT = 'Ranked recovery actions with owner, first step, due date and governed expected recovery. P_STATUS: OPEN (default: proposed, approved, in progress), PROPOSED, APPROVED, IN_PROGRESS, DONE, REJECTED, ALL.'
AS
$$
DECLARE
  result VARIANT;
  n      NUMBER;
  st     VARCHAR;
BEGIN
  n  := COALESCE(P_TOP_N, 10);
  st := UPPER(COALESCE(NULLIF(TRIM(P_STATUS), ''), 'OPEN'));
  SELECT OBJECT_CONSTRUCT(
           'status_filter', :st, 'top_n', :n,
           'actions_returned', COUNT(*),
           'expected_recovery_of_returned_actions_usd', SUM(EXPECTED_RECOVERY_USD),
           'note', 'EXPECTED_RECOVERY_USD equals the governed recoverable value of each risk item. Approval is a human decision.',
           'actions', ARRAY_AGG(OBJECT_CONSTRUCT(
               'rank', PRIORITY_RANK, 'action_id', ACTION_ID, 'risk_item_id', RISK_ITEM_ID, 'category', CATEGORY,
               'customer', CUSTOMER_NAME, 'action', ACTION_TEXT, 'owner', OWNER_ROLE, 'first_step', FIRST_STEP,
               'due_date', DUE_DATE, 'expected_recovery_usd', EXPECTED_RECOVERY_USD, 'status', STATUS,
               'source', ACTION_SOURCE, 'decision_by', DECISION_BY, 'decision_time', DECISION_TIME,
               'blocker', BLOCKER, 'ai_summary', AI_SUMMARY))
             WITHIN GROUP (ORDER BY PRIORITY_RANK NULLS LAST, EXPECTED_RECOVERY_USD DESC))
    INTO :result
    FROM (
      SELECT a.*, l.BLOCKER, l.AI_SUMMARY
      FROM RR_RECOVERY_ACTIONS a
      LEFT JOIN RR_RISK_LEDGER l ON l.RISK_ITEM_ID = a.RISK_ITEM_ID
      WHERE (:st = 'ALL')
         OR (:st = 'OPEN' AND a.STATUS IN ('PROPOSED', 'APPROVED', 'IN_PROGRESS'))
         OR (a.STATUS = :st)
      QUALIFY ROW_NUMBER() OVER (ORDER BY a.PRIORITY_RANK NULLS LAST, a.EXPECTED_RECOVERY_USD DESC) <= :n
    );
  RETURN TO_JSON(result);
END;
$$;

-- ---------------------------------------------------------------------------
-- RecoveryScenario (governed what-if, deterministic)
-- ---------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE SP_RECOVERY_SCENARIO(P_CATEGORIES VARCHAR)
RETURNS VARCHAR
LANGUAGE SQL
COMMENT = 'Governed what-if: illustrative outlook if the listed categories recover their modeled recoverable value. Accepts BASE, UPSIDE/ALL, or a comma list (pipeline, fulfillment, billing, renewal, support).'
AS
$$
DECLARE
  cats   VARCHAR;
  result VARIANT;
BEGIN
  SELECT CASE
           WHEN UPPER(TRIM(COALESCE(:P_CATEGORIES, ''))) IN ('', 'BASE', 'GOVERNED BASE', 'BASE RECOVERY')
             THEN (SELECT REPLACE(BASE_RECOVERY_CATEGORIES, ' ', '') FROM RR_CONFIG WHERE CONFIG_ID = 1)
           WHEN UPPER(TRIM(:P_CATEGORIES)) IN ('ALL', 'UPSIDE', 'UPSIDE RECOVERY', 'MAXIMUM')
             THEN 'PIPELINE,FULFILLMENT,BILLING,RENEWAL,SUPPORT_EXPANSION'
           ELSE (SELECT LISTAGG(DISTINCT CAT, ',') WITHIN GROUP (ORDER BY CAT) FROM (
                   SELECT CASE WHEN UPPER(t.VALUE) LIKE '%PIPE%' OR UPPER(t.VALUE) LIKE '%DEAL%' THEN 'PIPELINE'
                               WHEN UPPER(t.VALUE) LIKE '%FULFIL%' OR UPPER(t.VALUE) LIKE '%ORDER%' THEN 'FULFILLMENT'
                               WHEN UPPER(t.VALUE) LIKE '%BILL%' OR UPPER(t.VALUE) LIKE '%INVOICE%' THEN 'BILLING'
                               WHEN UPPER(t.VALUE) LIKE '%RENEW%' THEN 'RENEWAL'
                               WHEN UPPER(t.VALUE) LIKE '%SUPPORT%' OR UPPER(t.VALUE) LIKE '%EXPANSION%' THEN 'SUPPORT_EXPANSION'
                          END AS CAT
                   FROM TABLE(SPLIT_TO_TABLE(REPLACE(REPLACE(:P_CATEGORIES, ' and ', ','), ';', ','), ',')) t)
                 WHERE CAT IS NOT NULL)
         END
    INTO :cats;

  SELECT OBJECT_CONSTRUCT(
           'scenario', 'Illustrative recovery scenario (governed SQL)',
           'categories', :cats,
           'assumption', 'Assumes the modeled recoverable value of the selected categories is fully incremental to the current forecast. Not a guaranteed forecast. Renewal values are ARR.',
           'q4_target_usd', o.Q4_TARGET_USD,
           'q4_forecast_usd', o.Q4_FORECAST_USD,
           'forecast_gap_usd', o.FORECAST_GAP_USD,
           'scenario_recovery_usd', s.REC,
           'scenario_outlook_usd', o.Q4_FORECAST_USD + s.REC,
           'remaining_gap_usd', o.Q4_TARGET_USD - (o.Q4_FORECAST_USD + s.REC),
           'by_category', s.BY_CAT,
           'display', OBJECT_CONSTRUCT(
               'scenario_recovery', '$' || TO_VARCHAR(ROUND(s.REC / 1000000, 1)) || 'M',
               'scenario_outlook', '$' || TO_VARCHAR(ROUND((o.Q4_FORECAST_USD + s.REC) / 1000000, 1)) || 'M',
               'remaining_gap', '$' || TO_VARCHAR(ROUND((o.Q4_TARGET_USD - (o.Q4_FORECAST_USD + s.REC)) / 1000000, 1)) || 'M'))
    INTO :result
    FROM RR_REVENUE_OUTLOOK o
    CROSS JOIN (
      SELECT COALESCE(SUM(Q4_REVENUE_IMPACT), 0) AS REC,
             OBJECT_AGG(CATEGORY, CR::VARIANT) AS BY_CAT
      FROM (SELECT CATEGORY, SUM(Q4_REVENUE_IMPACT) AS CR FROM RR_RISK_LEDGER
             WHERE ACTIVE_FLAG AND POSITION(',' || CATEGORY || ',' IN ',' || :cats || ',') > 0 GROUP BY 1)
    ) s;
  RETURN TO_JSON(result);
END;
$$;

-- ---------------------------------------------------------------------------
-- RecoverySimulation (Monte Carlo, statistical second opinion on certainty)
-- ---------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE SP_SIMULATE_RECOVERY(P_CATEGORIES VARCHAR, P_ITERATIONS NUMBER)
RETURNS VARCHAR
LANGUAGE PYTHON
RUNTIME_VERSION = '3.11'
PACKAGES = ('snowflake-snowpark-python', 'numpy')
HANDLER = 'run'
COMMENT = 'Monte Carlo spread of recovery: each risk item recovers its at-risk value with its governed probability. Statistical, non-authoritative; its mean equals governed recoverable.'
AS
$$
import json
import numpy as np

ALL = ["PIPELINE", "FULFILLMENT", "BILLING", "RENEWAL", "SUPPORT_EXPANSION"]

def _cats(session, text):
    t = (text or "").strip().upper()
    if t in ("", "BASE", "GOVERNED BASE", "BASE RECOVERY"):
        base = session.sql("SELECT BASE_RECOVERY_CATEGORIES FROM RR_CONFIG WHERE CONFIG_ID = 1").collect()[0][0]
        return [c.strip() for c in base.split(",") if c.strip()]
    if t in ("ALL", "UPSIDE", "UPSIDE RECOVERY", "MAXIMUM"):
        return ALL
    out = []
    for tok in t.replace(" AND ", ",").replace(";", ",").split(","):
        if "PIPE" in tok or "DEAL" in tok: out.append("PIPELINE")
        elif "FULFIL" in tok or "ORDER" in tok: out.append("FULFILLMENT")
        elif "BILL" in tok or "INVOICE" in tok: out.append("BILLING")
        elif "RENEW" in tok: out.append("RENEWAL")
        elif "SUPPORT" in tok or "EXPANSION" in tok: out.append("SUPPORT_EXPANSION")
    return sorted(set(out)) or ALL

def run(session, p_categories, p_iterations):
    cats = _cats(session, p_categories)
    n = int(p_iterations or 10000)
    n = max(1000, min(n, 100000))
    in_list = ",".join("'" + c + "'" for c in cats)
    rows = session.sql(
        "SELECT AT_RISK_USD, RECOVERY_PROB, RECOVERABLE_USD FROM RR_RISK_LEDGER "
        f"WHERE ACTIVE_FLAG AND CATEGORY IN ({in_list})").collect()
    gap = float(session.sql("SELECT FORECAST_GAP_USD FROM RR_REVENUE_OUTLOOK").collect()[0][0])
    if not rows:
        return json.dumps({"categories": cats, "error": "no active risk items for these categories"})
    v = np.array([float(r[0] or 0) for r in rows])
    p = np.clip(np.array([float(r[1] or 0) for r in rows]), 0, 1)
    governed = float(sum(float(r[2] or 0) for r in rows))
    rng = np.random.default_rng(42)
    chunk = max(1, min(n, 2_000_000 // max(1, len(v))))   # bound memory per chunk
    parts, done = [], 0
    while done < n:
        k = min(chunk, n - done)
        parts.append((rng.random((k, len(v))) < p).astype(float) @ v)
        done += k
    totals = np.concatenate(parts)
    pct = lambda q: float(np.percentile(totals, q))
    return json.dumps({
        "tool": "RecoverySimulation",
        "nature": "Statistical Monte Carlo (seed 42). Non-authoritative; governed recoverable remains the official value.",
        "categories": cats, "iterations": n, "risk_items": int(len(v)),
        "governed_recoverable_usd": round(governed, 2),
        "simulated_mean_usd": round(float(totals.mean()), 2),
        "p10_usd": round(pct(10), 2), "p50_usd": round(pct(50), 2), "p90_usd": round(pct(90), 2),
        "probability_recovery_covers_forecast_gap": round(float((totals >= gap).mean()), 4),
        "forecast_gap_usd": round(gap, 2)})
$$;

-- ---------------------------------------------------------------------------
-- WhatChanged
-- ---------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE SP_WHAT_CHANGED()
RETURNS VARCHAR
LANGUAGE SQL
COMMENT = 'What changed since the previous refresh: item status counts, largest recoverable movements, category deltas.'
AS
$$
DECLARE
  result VARIANT;
BEGIN
  SELECT OBJECT_CONSTRUCT(
    'current_refresh', (SELECT MAX(RUN_ID) FROM RR_REFRESH_AUDIT WHERE STAGE = 'REFRESH' AND STATUS = 'SUCCESS'),
    'previous_refresh', (SELECT RUN_ID FROM RR_REFRESH_AUDIT WHERE STAGE = 'REFRESH' AND STATUS = 'SUCCESS'
                          QUALIFY ROW_NUMBER() OVER (ORDER BY ENDED_AT DESC) = 2),
    'item_status_counts', (SELECT OBJECT_AGG(CHANGE_STATUS, N::VARIANT)
                           FROM (SELECT CHANGE_STATUS, COUNT(*) AS N FROM RR_RISK_LEDGER GROUP BY 1)),
    'largest_movements', (SELECT ARRAY_AGG(OBJECT_CONSTRUCT('risk_item_id', RISK_ITEM_ID, 'category', CATEGORY,
                                'customer', CUSTOMER_NAME, 'change', CHANGE_STATUS,
                                'previous_recoverable_usd', PREV_RECOVERABLE_USD, 'current_recoverable_usd', RECOVERABLE_USD,
                                'previous_at_risk_usd', PREV_AT_RISK_USD, 'current_at_risk_usd', AT_RISK_USD))
                          FROM (SELECT * FROM RR_RISK_LEDGER WHERE CHANGE_STATUS IN ('NEW', 'CHANGED', 'RESOLVED', 'REOPENED')
                                QUALIFY ROW_NUMBER() OVER (ORDER BY ABS(COALESCE(RECOVERABLE_USD, 0) - COALESCE(PREV_RECOVERABLE_USD, 0)) DESC) <= 10)),
    'category_totals_current_vs_previous', (
        SELECT ARRAY_AGG(OBJECT_CONSTRUCT('category', CUR.KEY,
                   'current', CUR.VALUE, 'previous', GET(p_audit.PREV_DETAILS:categories, CUR.KEY)))
        FROM (SELECT DETAILS FROM RR_REFRESH_AUDIT WHERE STAGE = 'REFRESH' AND STATUS = 'SUCCESS'
              QUALIFY ROW_NUMBER() OVER (ORDER BY ENDED_AT DESC) = 1) c_audit,
             LATERAL FLATTEN(INPUT => c_audit.DETAILS:categories) CUR,
             (SELECT COALESCE(ANY_VALUE(DETAILS), PARSE_JSON('{}')) AS PREV_DETAILS FROM (
                 SELECT DETAILS FROM RR_REFRESH_AUDIT WHERE STAGE = 'REFRESH' AND STATUS = 'SUCCESS'
                 QUALIFY ROW_NUMBER() OVER (ORDER BY ENDED_AT DESC) = 2)) p_audit),
    'note', 'With the locked as-of date and unchanged source data, every item is expected to be UNCHANGED after a re-run.')
  INTO :result;
  RETURN TO_JSON(result);
END;
$$;


-- ---------------------------------------------------------------------------
-- GapClosurePlan / PreventionPlan (read-only views of the decision planners)
-- ---------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE SP_GET_GAP_PLAN()
RETURNS VARCHAR
LANGUAGE SQL
COMMENT = 'Gap-closure bridge: current forecast, recovery steps by category (base first), cumulative outlook, remaining gap, Monte Carlo probability of closing the gap per step.'
AS
$$
DECLARE
  result VARIANT;
BEGIN
  SELECT OBJECT_CONSTRUCT(
           'tool', 'GapClosurePlan',
           'nature', 'Illustrative bridge. Money = governed ledger recoverable; probabilities are statistical (Monte Carlo, seed 42).',
           'target_usd', MAX(TARGET_USD),
           'steps', ARRAY_AGG(OBJECT_CONSTRUCT('step', STEP_ORDER, 'category', CATEGORY, 'label', STEP_LABEL,
                      'expected_usd', EXPECTED_USD, 'cumulative_forecast_usd', CUMULATIVE_FORECAST_USD,
                      'remaining_gap_usd', REMAINING_GAP_USD, 'in_base_scenario', IN_BASE_SCENARIO,
                      'needs_approval', NEEDS_APPROVAL, 'prob_close_gap_cumulative', PROB_CLOSE_GAP_CUMULATIVE,
                      'items', ITEMS)) WITHIN GROUP (ORDER BY STEP_ORDER),
           'refresh_id', MAX(REFRESH_ID), 'planned_at', MAX(PLANNED_AT))
    INTO :result
    FROM RR_GAP_PLAN;
  RETURN TO_JSON(result);
END;
$$;

CREATE OR REPLACE PROCEDURE SP_GET_PREVENTION_PLAN()
RETURNS VARCHAR
LANGUAGE SQL
COMMENT = 'Prevention controls proposed for recurring blocker classes (estimate of preventable exposure), with launch status.'
AS
$$
DECLARE
  result VARIANT;
BEGIN
  SELECT OBJECT_CONSTRUCT(
           'tool', 'PreventionPlan',
           'nature', 'EST_PREVENTABLE_USD is an estimate (this quarter''s exposure from the targeted blocker class). Launch is a human decision.',
           'controls', ARRAY_AGG(OBJECT_CONSTRUCT('control_id', CONTROL_ID, 'category', CATEGORY, 'risk_class', RISK_CLASS,
                         'control', CONTROL_NAME, 'rationale', RATIONALE, 'owner', OWNER, 'items', ITEMS,
                         'est_preventable_usd', EST_PREVENTABLE_USD, 'status', STATUS, 'review_date', REVIEW_DATE))
                       WITHIN GROUP (ORDER BY EST_PREVENTABLE_USD DESC))
    INTO :result
    FROM RR_PREVENTION_PLAN WHERE STATUS IN ('PROPOSED', 'LAUNCHED');
  RETURN TO_JSON(result);
END;
$$;

-- ---------------------------------------------------------------------------
-- Access template (adjust role names; requires SECURITYADMIN / USERADMIN)
-- ---------------------------------------------------------------------------
-- CREATE ROLE IF NOT EXISTS RR_AGENT_USER;   -- executives / CoWork users (read + agent tools)
-- CREATE ROLE IF NOT EXISTS RR_APPROVER;     -- revenue leaders allowed to approve actions
-- GRANT USAGE ON DATABASE HACKATHON_REVENUE_RISK TO ROLE RR_AGENT_USER;
-- GRANT USAGE ON SCHEMA HACKATHON_REVENUE_RISK.SOLUTION TO ROLE RR_AGENT_USER;
-- GRANT USAGE ON WAREHOUSE RR_WH TO ROLE RR_AGENT_USER;
-- GRANT DATABASE ROLE SNOWFLAKE.CORTEX_USER TO ROLE RR_AGENT_USER;
-- GRANT SELECT ON TABLE RR_RISK_LEDGER, RR_CUSTOMER_360, RR_RECOVERY_ACTIONS, RR_REVENUE_OUTLOOK TO ROLE RR_AGENT_USER;
-- GRANT USAGE ON PROCEDURE SP_GET_EXECUTIVE_SNAPSHOT() TO ROLE RR_AGENT_USER;
-- GRANT USAGE ON PROCEDURE SP_DEEP_REVENUE_REASONING(VARCHAR) TO ROLE RR_AGENT_USER;
-- GRANT USAGE ON PROCEDURE SP_RR_TRUST_CHECK() TO ROLE RR_AGENT_USER;
-- GRANT USAGE ON PROCEDURE SP_GET_RECOVERY_ACTIONS(NUMBER, VARCHAR) TO ROLE RR_AGENT_USER;
-- GRANT USAGE ON PROCEDURE SP_RECOVERY_SCENARIO(VARCHAR) TO ROLE RR_AGENT_USER;
-- GRANT USAGE ON PROCEDURE SP_SIMULATE_RECOVERY(VARCHAR, NUMBER) TO ROLE RR_AGENT_USER;
-- GRANT USAGE ON PROCEDURE SP_WHAT_CHANGED() TO ROLE RR_AGENT_USER;
-- GRANT USAGE ON PROCEDURE SP_GET_GAP_PLAN() TO ROLE RR_AGENT_USER;
-- GRANT USAGE ON PROCEDURE SP_GET_PREVENTION_PLAN() TO ROLE RR_AGENT_USER;
-- GRANT ROLE RR_AGENT_USER TO ROLE RR_APPROVER;
-- GRANT SELECT, UPDATE ON TABLE RR_RECOVERY_ACTIONS TO ROLE RR_APPROVER;
-- GRANT SELECT ON TABLE RR_CONFIG, RR_REFRESH_AUDIT TO ROLE RR_APPROVER;
-- GRANT INSERT ON TABLE AGENT_ACTIONS, PREVENTION_CONTROLS, VERIFIED_ANSWERS TO ROLE RR_APPROVER;
-- GRANT USAGE ON PROCEDURE SP_APPROVE_RECOVERY_ACTION(VARCHAR, VARCHAR) TO ROLE RR_APPROVER;
-- GRANT USAGE ON PROCEDURE SP_REJECT_RECOVERY_ACTION(VARCHAR, VARCHAR) TO ROLE RR_APPROVER;
-- GRANT USAGE ON PROCEDURE SP_RR_MIRROR_DECISION(VARCHAR) TO ROLE RR_APPROVER;
-- GRANT USAGE ON PROCEDURE SP_LAUNCH_PREVENTION_CONTROL(VARCHAR, VARCHAR, VARCHAR, DATE, VARCHAR) TO ROLE RR_APPROVER;
-- GRANT USAGE ON PROCEDURE SP_SAVE_VERIFIED_ANSWER(VARCHAR, VARCHAR, VARCHAR) TO ROLE RR_APPROVER;
-- GRANT USAGE ON PROCEDURE SP_UPDATE_ACTION_STATUS(VARCHAR, VARCHAR, VARCHAR) TO ROLE RR_APPROVER;
-- GRANT USAGE ON PROCEDURE SP_LAUNCH_PLANNED_CONTROL(VARCHAR, VARCHAR, NUMBER, VARCHAR) TO ROLE RR_APPROVER;
-- GRANT SELECT, UPDATE ON TABLE RR_PREVENTION_PLAN TO ROLE RR_APPROVER;

-- ===========================================================================
-- EXECUTE (tool smoke calls)
-- ===========================================================================
CALL SP_GET_EXECUTIVE_SNAPSHOT();
CALL SP_RECOVERY_SCENARIO('Pipeline, Fulfillment and Billing');
CALL SP_RECOVERY_SCENARIO('UPSIDE');
CALL SP_GET_RECOVERY_ACTIONS(5, 'OPEN');
CALL SP_SIMULATE_RECOVERY('BASE', 10000);
CALL SP_WHAT_CHANGED();
CALL SP_GET_GAP_PLAN();
CALL SP_GET_PREVENTION_PLAN();
