/* =============================================================================
   15_STREAMLIT_APP_SUPPORT.sql
   Objects used only by the NexaSphere Command Center (Streamlit, rr_build/streamlit/).
   Run after 12 (agent) and 13 (agent tests).

     SP_REFRESH_ANALYTICS            admin "Rebuild analytics": refresh -> AI enrich -> planners + proposals -> trust,
                                     one RR_REFRESH_AUDIT row per step (RUN_ID 'RA-...')
     RR_REVENUE_RECOVERY_APP_AGENT   same tools, routing and guardrails as RR_REVENUE_RECOVERY_AGENT, but replies
                                     in the app's JSON contract. CoWork keeps the markdown agent.
                                     The spec below is generated from 12 (only the `response` block differs).

   No views are created.
   ============================================================================= */

USE DATABASE HACKATHON_REVENUE_RISK;
USE SCHEMA SOLUTION;
USE WAREHOUSE RR_WH;

-- ---------------------------------------------------------------------------
-- Admin rebuild (caller's rights; runs the same governed chain as the tasks)
-- ---------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE SP_REFRESH_ANALYTICS()
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
COMMENT = 'Command Center admin rebuild: decision layer, incremental AI, planners + proposals, trust check. Logs each step.'
AS
$$
DECLARE
  run_id    VARCHAR DEFAULT ('RA-' || TO_VARCHAR(CURRENT_TIMESTAMP(), 'YYYYMMDDHH24MISSFF3'));
  as_of     DATE;
  step      VARCHAR DEFAULT 'START';
  t0        TIMESTAMP_NTZ;
  res       VARIANT;
  trust_txt VARCHAR;
  err       VARCHAR;
BEGIN
  SELECT AS_OF_DATE INTO :as_of FROM RR_CONFIG WHERE CONFIG_ID = 1;

  step := '1_REFRESH_DECISION_LAYER';
  t0 := CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
  CALL SP_REFRESH_REVENUE_DECISION_LAYER() INTO :res;
  INSERT INTO RR_REFRESH_AUDIT (RUN_ID, STAGE, STATUS, STARTED_AT, ENDED_AT, AS_OF_DATE, ROWS_AFFECTED, DETAILS, RUN_BY)
  SELECT :run_id, :step, 'SUCCESS', :t0, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, :as_of, NULL, :res, CURRENT_USER();

  step := '2_AI_ENRICH';
  t0 := CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
  CALL SP_ENRICH_REVENUE_RISKS_AI(200) INTO :res;
  INSERT INTO RR_REFRESH_AUDIT (RUN_ID, STAGE, STATUS, STARTED_AT, ENDED_AT, AS_OF_DATE, ROWS_AFFECTED, DETAILS, RUN_BY)
  SELECT :run_id, :step, 'SUCCESS', :t0, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, :as_of, NULL, :res, CURRENT_USER();

  step := '3_PLANNERS_AND_PROPOSALS';
  t0 := CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
  CALL SP_PROPOSE_TOP_RECOVERY_ACTIONS(10) INTO :res;
  INSERT INTO RR_REFRESH_AUDIT (RUN_ID, STAGE, STATUS, STARTED_AT, ENDED_AT, AS_OF_DATE, ROWS_AFFECTED, DETAILS, RUN_BY)
  SELECT :run_id, :step, 'SUCCESS', :t0, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, :as_of, NULL, :res, CURRENT_USER();

  step := '4_TRUST_CHECK';
  t0 := CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
  CALL SP_RR_TRUST_CHECK() INTO :trust_txt;
  INSERT INTO RR_REFRESH_AUDIT (RUN_ID, STAGE, STATUS, STARTED_AT, ENDED_AT, AS_OF_DATE, ROWS_AFFECTED, DETAILS, RUN_BY)
  SELECT :run_id, :step, PARSE_JSON(:trust_txt):overall_status::VARCHAR, :t0, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ,
         :as_of, NULL, PARSE_JSON(:trust_txt), CURRENT_USER();

  RETURN TO_JSON(OBJECT_CONSTRUCT('ok', TRUE, 'run_id', run_id,
                                  'trust_status', PARSE_JSON(trust_txt):overall_status::VARCHAR,
                                  'message', 'Analytics rebuilt (' || run_id || ')'));
EXCEPTION
  WHEN OTHER THEN
    err := SQLERRM;
    INSERT INTO RR_REFRESH_AUDIT (RUN_ID, STAGE, STATUS, STARTED_AT, ENDED_AT, AS_OF_DATE, ROWS_AFFECTED, DETAILS, RUN_BY)
    SELECT :run_id, :step, 'FAILED', :t0, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, :as_of, NULL,
           OBJECT_CONSTRUCT('error', :err), CURRENT_USER();
    RETURN TO_JSON(OBJECT_CONSTRUCT('ok', FALSE, 'run_id', run_id, 'failed_step', step, 'error', err));
END;
$$;

-- ---------------------------------------------------------------------------
-- JSON-contract twin of the agent for the Command Center
-- ---------------------------------------------------------------------------
CREATE OR REPLACE AGENT RR_REVENUE_RECOVERY_APP_AGENT
  COMMENT = 'Command Center twin of RR_REVENUE_RECOVERY_AGENT: identical governed tools and guardrails, JSON answer contract for the Streamlit app.'
  PROFILE = '{"display_name": "Revenue-at-Risk Agent (Command Center)", "avatar": "chart-icon.png", "color": "blue"}'
  FROM SPECIFICATION
$$
models:
  orchestration: auto

orchestration:
  tool_not_accessible: accept
  budget:
    seconds: 300
    tokens: 200000

instructions:
  orchestration: |
    You are the NexaSphere Technologies Revenue Recovery Agent. You investigate Q4 revenue risk using governed Snowflake tools only.
    Begin every non-trivial answer by stating a one-line analysis plan (which tools, in what order). Never reveal private chain-of-thought.

    MONEY RULES
    - Every dollar figure must come from a tool result. Never add, net, re-sum or estimate money yourself.
    - Target, forecast, gap, gross revenue at risk, modeled recoverable, base recovery, base revised outlook, upside case and remaining gap:
      ALWAYS call ExecutiveSnapshot first and quote its values.
    - Gross revenue at risk is NOT the forecast gap. Never present forecast + recoverable as the new forecast.
      Base Revised Outlook (Pipeline + Fulfillment + Billing) and Upside Recovery Case (all five) are illustrative scenarios, never guaranteed.
    - Renewal values are ARR, not recognized Q4 revenue.
    - Governed recovery probability is authoritative. ML scores are a second opinion; explain disagreements, never substitute them.

    ROUTING (progressive drill-down)
    - "How are we doing vs target?" / "How much is at risk?" -> ExecutiveSnapshot.
    - "Why?" / category, blocker, customer, region, product breakdowns, deal/order/invoice lists -> RevenueRiskAnalyst (semantic view over the risk ledger).
    - "What should we do?" / "top actions" / "who owns" / CRO, CFO, Supply Chain asks -> TrustCheck, then RecoveryActions, then DeepRevenueReasoning.
    - Deep "why" across categories, root cause, ML vs governed comparison, executive narrative -> DeepRevenueReasoning (Claude Opus 5.5 over governed evidence).
    - "What if we recover X, Y, Z?" / base or upside scenario -> RecoveryScenario (pass the user's category words). Do not compute it yourself.
    - "How do we close the rest of the gap?" / bridge from forecast to target -> GapClosurePlan (with ExecutiveSnapshot).
    - "What should we put in place so this does not happen again?" -> PreventionPlan (plus DeepRevenueReasoning for the narrative).
    - Confidence / range / probability of closing the gap -> RecoverySimulation, labelled as statistical and non-authoritative.
    - "What changed since the last refresh?" -> WhatChanged (and RevenueRiskAnalyst for detail).
    - "Show me" / chart / visual -> fetch rows with RevenueRiskAnalyst (or use tool output), then data_to_chart.
    - code_execution only for ad-hoc analysis of data already returned by tools; never to produce authoritative money.
    - Do not query raw source facts; the governed decision layer already contains the evidence.

    TRUST
    - Call TrustCheck before presenting any financial recommendation, action plan or expected impact.
    - If TrustCheck overall_status is FAIL: do not present recommendations or impact; report the failed checks and stop.
    - If WARN: proceed but state the warnings under EVIDENCE / TRUST.

    HUMAN CONTROL
    - You can recommend actions but you cannot approve, reject or execute them. Approval is done by an authorized human
      in the Command Center (SP_APPROVE_RECOVERY_ACTION / SP_REJECT_RECOVERY_ACTION). Never claim an action was approved unless its status says so.
  response: |
    You are answering inside the NexaSphere Command Center app, which renders your answer from JSON.
    Return ONLY one JSON object: no markdown, no code fences, no text before or after it.
    Keys (all required; use empty arrays/objects when not applicable, never invent content):
    {
      "executive_summary": string - executive prose: one-line analysis plan, then direct answer, why, what to do, expected impact; label scenarios illustrative,
      "metrics": object of USD numbers copied exactly from tool outputs (not millions, not strings); use only these keys when relevant:
                 target, forecast, gap, at_risk, recoverable, no_path, ml_forecast, planned_recovery,
      "root_causes": [ {"category": string, "cause": string, "at_risk_amount": number, "blocker": string, "evidence_id": string (RISK_ITEM_ID, opportunity/order id, or tool name)} ],
      "ranked_actions": [ {"rank": number, "category": string, "action": string, "owner": string, "expected_recovery": number, "action_id": string (ACT-... from RecoveryActions, else omit), "needs_approval": boolean} ],
      "ml_second_opinion": string (governed vs ML comparison, or empty),
      "caveats": [string] (gross risk is not the forecast gap; renewal is ARR; scenarios illustrative; TrustCheck status),
      "needs_approval": boolean (true when any recommended action awaits human approval)
    }
    Every number must appear in a tool result. Never add, net or re-sum money. Keep executive_summary under 180 words.
  sample_questions:
    - question: "We are forecasting below our Q4 target. How much revenue is at risk before quarter-end, why, and how much can we still recover?"
    - question: "Which category is creating the largest revenue risk?"
    - question: "Which pipeline deals should Sales leadership focus on first?"
    - question: "Which warehouses can resolve component shortages?"
    - question: "Where does ML disagree with our governed recovery probability?"
    - question: "What would the revised outlook be if Pipeline, Fulfillment and Billing recovery succeeds?"
    - question: "Show revenue at risk versus recoverable revenue by category."
    - question: "What should the CRO, CFO and Supply Chain leader do this week?"
    - question: "We are $8.2M short. What can we recover, and how do we close the rest?"
    - question: "What should we put in place so this does not happen again next quarter?"

tools:
  - tool_spec:
      type: "generic"
      name: "ExecutiveSnapshot"
      description: "Authoritative governed Q4 position from RR_REVENUE_OUTLOOK: target, forecast, forecast gap, gross revenue at risk, modeled recoverable, per-category at-risk and recoverable, Base Revised Outlook and Upside Recovery Case, accounting note, last trust status. Call FIRST for any of these numbers."
      input_schema:
        type: "object"
        properties: {}
  - tool_spec:
      type: "cortex_analyst_text_to_sql"
      name: "RevenueRiskAnalyst"
      description: "Cortex Analyst over the RR_REVENUE_RISK_SEMANTIC semantic view (governed risk ledger, customer 360, recovery actions). Use for why/where/which questions: breakdowns by category, blocker, risk class, customer, region, product family, due date, owner; lists of deals, orders, invoices, renewals; ML vs governed comparisons; change since last refresh."
  - tool_spec:
      type: "generic"
      name: "DeepRevenueReasoning"
      description: "Claude Opus 5.5 (AI_COMPLETE) deep analytical reasoning over a compact governed evidence package (snapshot, top risk items, blocker mix, ML disagreements, customer health, warehouse transfers, gap drivers, open actions, trust). Use for root cause across categories, ML vs governed explanations, ranked recommendations and executive narratives. Never computes money."
      input_schema:
        type: "object"
        properties:
          P_QUESTION:
            type: "string"
            description: "The executive's question, verbatim, plus any focus (category, customer, role)."
        required: ["P_QUESTION"]
  - tool_spec:
      type: "generic"
      name: "TrustCheck"
      description: "Runs governed trust validation (config lock, reconciliation, lineage, duplicates, nulls, negatives, actions <= recoverable, AI did not alter money, ML did not overwrite governed probability, freshness, benchmarks). Returns overall_status PASS / WARN / FAIL. Call before any financial recommendation."
      input_schema:
        type: "object"
        properties: {}
  - tool_spec:
      type: "generic"
      name: "RecoveryActions"
      description: "Ranked recovery actions with category, customer, action, owner role, first step, due date, governed expected recovery, status and decision attribution. Use for top-N actions, owners, expected recovery of top actions."
      input_schema:
        type: "object"
        properties:
          P_TOP_N:
            type: "number"
            description: "How many actions to return (default 10)."
          P_STATUS:
            type: "string"
            description: "OPEN (default: proposed + approved), PROPOSED, APPROVED, REJECTED or ALL."
        required: ["P_TOP_N", "P_STATUS"]
  - tool_spec:
      type: "generic"
      name: "RecoveryScenario"
      description: "Governed what-if: illustrative outlook and remaining gap if the listed categories recover their modeled recoverable value. Accepts BASE, UPSIDE, or category words such as 'Pipeline, Fulfillment and Billing'."
      input_schema:
        type: "object"
        properties:
          P_CATEGORIES:
            type: "string"
            description: "BASE, UPSIDE, or a comma/and separated list of categories."
        required: ["P_CATEGORIES"]
  - tool_spec:
      type: "generic"
      name: "RecoverySimulation"
      description: "Monte Carlo range (P10/P50/P90) of recovery for chosen categories using governed per-item probabilities, plus probability of covering the forecast gap. Statistical and non-authoritative."
      input_schema:
        type: "object"
        properties:
          P_CATEGORIES:
            type: "string"
            description: "BASE, UPSIDE, or category list."
          P_ITERATIONS:
            type: "number"
            description: "Simulation iterations, 1000-100000 (default 10000)."
        required: ["P_CATEGORIES", "P_ITERATIONS"]
  - tool_spec:
      type: "generic"
      name: "WhatChanged"
      description: "Changes since the previous refresh: counts of NEW/CHANGED/UNCHANGED/RESOLVED items, largest recoverable movements and category totals current vs previous."
      input_schema:
        type: "object"
        properties: {}
  - tool_spec:
      type: "generic"
      name: "GapClosurePlan"
      description: "Gap-closure bridge from current forecast to target: recovery steps by category (governed base categories first, then modeled upside), cumulative illustrative outlook, remaining gap, and Monte Carlo probability of closing the gap after each step."
      input_schema:
        type: "object"
        properties: {}
  - tool_spec:
      type: "generic"
      name: "PreventionPlan"
      description: "Prevention controls proposed for the recurring blocker classes behind this quarter's risk, with owner, estimated preventable exposure (estimate) and launch status. Launching is a human decision."
      input_schema:
        type: "object"
        properties: {}
  - tool_spec:
      type: "data_to_chart"
      name: "data_to_chart"
      description: "Generates charts from data returned by other tools (e.g. revenue at risk vs recoverable by category)."
  - tool_spec:
      type: "code_execution"
      name: "code_execution"

tool_resources:
  ExecutiveSnapshot:
    type: "procedure"
    identifier: "HACKATHON_REVENUE_RISK.SOLUTION.SP_GET_EXECUTIVE_SNAPSHOT"
    execution_environment:
      type: "warehouse"
      warehouse: "RR_WH"
      query_timeout: 60
  RevenueRiskAnalyst:
    semantic_view: "HACKATHON_REVENUE_RISK.SOLUTION.RR_REVENUE_RISK_SEMANTIC"
    execution_environment:
      type: "warehouse"
      warehouse: "RR_WH"
      query_timeout: 120
  DeepRevenueReasoning:
    type: "procedure"
    identifier: "HACKATHON_REVENUE_RISK.SOLUTION.SP_DEEP_REVENUE_REASONING"
    execution_environment:
      type: "warehouse"
      warehouse: "RR_WH"
      query_timeout: 300
  TrustCheck:
    type: "procedure"
    identifier: "HACKATHON_REVENUE_RISK.SOLUTION.SP_RR_TRUST_CHECK"
    execution_environment:
      type: "warehouse"
      warehouse: "RR_WH"
      query_timeout: 120
  RecoveryActions:
    type: "procedure"
    identifier: "HACKATHON_REVENUE_RISK.SOLUTION.SP_GET_RECOVERY_ACTIONS"
    execution_environment:
      type: "warehouse"
      warehouse: "RR_WH"
      query_timeout: 60
  RecoveryScenario:
    type: "procedure"
    identifier: "HACKATHON_REVENUE_RISK.SOLUTION.SP_RECOVERY_SCENARIO"
    execution_environment:
      type: "warehouse"
      warehouse: "RR_WH"
      query_timeout: 60
  RecoverySimulation:
    type: "procedure"
    identifier: "HACKATHON_REVENUE_RISK.SOLUTION.SP_SIMULATE_RECOVERY"
    execution_environment:
      type: "warehouse"
      warehouse: "RR_WH"
      query_timeout: 120
  WhatChanged:
    type: "procedure"
    identifier: "HACKATHON_REVENUE_RISK.SOLUTION.SP_WHAT_CHANGED"
    execution_environment:
      type: "warehouse"
      warehouse: "RR_WH"
      query_timeout: 60
  GapClosurePlan:
    type: "procedure"
    identifier: "HACKATHON_REVENUE_RISK.SOLUTION.SP_GET_GAP_PLAN"
    execution_environment:
      type: "warehouse"
      warehouse: "RR_WH"
      query_timeout: 60
  PreventionPlan:
    type: "procedure"
    identifier: "HACKATHON_REVENUE_RISK.SOLUTION.SP_GET_PREVENTION_PLAN"
    execution_environment:
      type: "warehouse"
      warehouse: "RR_WH"
      query_timeout: 60
  code_execution:
    permission_policy:
      type: "always_ask"
$$;

DESCRIBE AGENT RR_REVENUE_RECOVERY_APP_AGENT;

-- Grants for app viewers (adjust role names):
-- GRANT USAGE ON AGENT RR_REVENUE_RECOVERY_APP_AGENT TO ROLE RR_APPROVER;
-- GRANT USAGE ON PROCEDURE SP_REFRESH_ANALYTICS() TO ROLE RR_APPROVER;

-- Smoke: one JSON answer from the app agent (should parse as JSON with executive_summary)
SELECT TRY_PARSE_JSON(
         SNOWFLAKE.CORTEX.DATA_AGENT_RUN(
           'HACKATHON_REVENUE_RISK.SOLUTION.RR_REVENUE_RECOVERY_APP_AGENT',
           $${"messages": [{"role": "user", "content": [{"type": "text", "text": "Give me the Q4 revenue outlook."}]}]}$$,
           TRUE)) AS APP_AGENT_RESPONSE;
