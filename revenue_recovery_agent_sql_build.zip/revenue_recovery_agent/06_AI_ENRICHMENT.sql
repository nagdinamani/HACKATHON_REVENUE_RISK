/* =============================================================================
   06_AI_ENRICHMENT.sql
   Incremental Cortex AI enrichment: Detect -> Calculate -> Persist -> Hash -> AI-enrich CHANGED rows.

   Roles of each Cortex AI function (each has a distinct job):
     AI_CLASSIFY  -> AI_RISK_CLASS: maps free-text blockers onto a fixed executive taxonomy
                     (cheap, deterministic labels for grouping and routing).
     AI_COMPLETE  -> claude-opus-5-5 (RR_CONFIG.AI_MODEL): structured JSON with next-best action,
                     first step, owner role and an executive summary per risk item.
     AI_AGG       -> RR_AI_CATEGORY_BRIEFS: one executive brief per risk category, aggregated
                     across all items (used to "explain the biggest blockers").

   Guarantees
     * Only rows with AI_ENRICHED_HASH <> AI_INPUT_HASH are sent to the model (token control).
     * AI writes ONLY AI_* columns. Money columns are never touched; SP_RR_TRUST_CHECK
       recomputes RR_LEDGER_ROW_HASH to prove it.
   ============================================================================= */

USE DATABASE HACKATHON_REVENUE_RISK;
USE SCHEMA SOLUTION;
USE WAREHOUSE RR_WH;

CREATE TABLE IF NOT EXISTS RR_AI_CATEGORY_BRIEFS (
  CATEGORY      VARCHAR NOT NULL,
  INPUT_HASH    VARCHAR,
  ITEM_COUNT    NUMBER,
  BRIEF         VARCHAR,
  AI_FUNCTION   VARCHAR,
  GENERATED_AT  TIMESTAMP_NTZ,
  CONSTRAINT PK_RR_BRIEFS PRIMARY KEY (CATEGORY)
) COMMENT = 'AI_AGG executive brief per risk category. Qualitative only; numbers come from the ledger.';

CREATE OR REPLACE PROCEDURE SP_ENRICH_REVENUE_RISKS_AI(P_MAX_ROWS NUMBER)
RETURNS VARIANT
LANGUAGE SQL
COMMENT = 'Incremental Cortex AI enrichment of changed risk-ledger rows (AI_CLASSIFY + AI_COMPLETE claude-opus-5-5 + AI_AGG briefs).'
AS
$$
DECLARE
  run_id       VARCHAR DEFAULT ('AI-' || TO_VARCHAR(CURRENT_TIMESTAMP(), 'YYYYMMDDHH24MISSFF3'));
  started_at   TIMESTAMP_NTZ DEFAULT (CURRENT_TIMESTAMP()::TIMESTAMP_NTZ);
  model        VARCHAR;
  max_tokens   NUMBER;
  pending      NUMBER;
  selected     NUMBER DEFAULT 0;
  enriched     NUMBER DEFAULT 0;
  briefs       NUMBER DEFAULT 0;
  remaining    NUMBER;
  active_count NUMBER;
  summary      VARIANT;
  err_msg      VARCHAR;
BEGIN
  CALL SP_ASSERT_CONFIG_LOCKED();
  SELECT AI_MODEL, AI_MAX_TOKENS INTO :model, :max_tokens FROM RR_CONFIG WHERE CONFIG_ID = 1;

  SELECT COUNT(*) INTO :pending FROM RR_RISK_LEDGER
   WHERE ACTIVE_FLAG AND AI_ENRICHED_HASH IS DISTINCT FROM AI_INPUT_HASH;

  -- -------------------------------------------------------------------------
  -- 1. Select ONLY changed / never-enriched items, highest recoverable value first
  -- -------------------------------------------------------------------------
  CREATE OR REPLACE TEMPORARY TABLE RR_TMP_AI_WORK AS
  SELECT l.RISK_ITEM_ID, l.AI_INPUT_HASH, l.CATEGORY, l.CUSTOMER_NAME, l.PRODUCT_FAMILY, l.REGION_NAME,
         l.BLOCKER, l.RECOVERY_PATH, l.EVIDENCE_TEXT, l.AT_RISK_USD, l.RECOVERABLE_USD, l.RECOVERY_PROB,
         l.VALUE_BASIS, l.ML_SCORE, l.ML_SCORE_TYPE, l.ML_GOVERNED_DELTA, l.DUE_DATE, l.CALCULATION_RULE
  FROM RR_RISK_LEDGER l
  WHERE l.ACTIVE_FLAG
    AND l.AI_ENRICHED_HASH IS DISTINCT FROM l.AI_INPUT_HASH
  QUALIFY ROW_NUMBER() OVER (ORDER BY l.RECOVERABLE_USD DESC NULLS LAST, l.AT_RISK_USD DESC NULLS LAST, l.RISK_ITEM_ID) <= :P_MAX_ROWS;

  SELECT COUNT(*) INTO :selected FROM RR_TMP_AI_WORK;

  IF (selected > 0) THEN
    -- -----------------------------------------------------------------------
    -- 2. AI_CLASSIFY (taxonomy) + AI_COMPLETE (Claude Opus 5.5, structured JSON)
    -- -----------------------------------------------------------------------
    CREATE OR REPLACE TEMPORARY TABLE RR_TMP_AI_RESULTS AS
    SELECT w.RISK_ITEM_ID, w.AI_INPUT_HASH,
           AI_CLASSIFY(
             w.CATEGORY || ' risk. Blocker: ' || COALESCE(w.BLOCKER, 'n/a') || '. ' || COALESCE(w.EVIDENCE_TEXT, ''),
             ['Legal or contract review', 'Executive approval', 'Stakeholder engagement', 'Procurement delay',
              'Security review', 'Budget or pricing objection', 'Component shortage', 'Billing master-data issue',
              'PO mismatch', 'Commercial dispute', 'Product adoption decline', 'Support escalation', 'Other'],
             {'task_description': 'Classify the primary root-cause blocker of an enterprise revenue-risk item.'}
           ):labels[0]::VARCHAR AS AI_RISK_CLASS,
           TRY_PARSE_JSON(AI_COMPLETE(
             :model,
             'You are a senior revenue-operations analyst at NexaSphere Technologies, a B2B enterprise technology company. '
             || 'Interpret ONE governed revenue-risk item computed in Snowflake. Rules: '
             || '(1) Never calculate, change or restate dollar amounts or probabilities; refer to value only qualitatively (e.g. "material"). '
             || '(2) Use only the evidence provided; label any assumption explicitly as an assumption. '
             || '(3) Recommend ONE concrete next-best action achievable before quarter-end (' || TO_VARCHAR(c.QTR_END) || '), '
             || 'the first step to take this week, and the single accountable owner role. '
             || '(4) If an ML second-opinion score is present and disagrees with the governed probability, say so in the summary. '
             || '(5) summary: at most two sentences, executive language, root cause first. '
             || 'Category meanings: PIPELINE = blocked late-stage deal; FULFILLMENT = priority order blocked by component shortage '
             || '(RECOVERY_PATH shows any alternate-warehouse transfer); BILLING = invoice exception on a shipped order; '
             || 'RENEWAL = ARR renewal at risk; SUPPORT_EXPANSION = expansion threatened by poor support health. '
             || 'Evidence JSON: ' || TO_JSON(OBJECT_CONSTRUCT(
                  'risk_item_id', w.RISK_ITEM_ID, 'category', w.CATEGORY, 'customer', w.CUSTOMER_NAME,
                  'product_family', w.PRODUCT_FAMILY, 'region', w.REGION_NAME, 'blocker', w.BLOCKER,
                  'recovery_path', w.RECOVERY_PATH, 'evidence', w.EVIDENCE_TEXT, 'value_basis', w.VALUE_BASIS,
                  'governed_recovery_probability', w.RECOVERY_PROB, 'ml_score', w.ML_SCORE,
                  'ml_score_type', w.ML_SCORE_TYPE, 'ml_minus_governed', w.ML_GOVERNED_DELTA,
                  'due_date', w.DUE_DATE, 'governed_rule', w.CALCULATION_RULE)),
             OBJECT_CONSTRUCT('max_tokens', :max_tokens),
             {'type': 'json',
              'schema': {'type': 'object',
                         'properties': {
                           'next_best_action': {'type': 'string'},
                           'first_step':       {'type': 'string'},
                           'owner_role':       {'type': 'string',
                                                'enum': ['CRO', 'CFO', 'Regional Sales VP', 'Deal Desk Lead', 'Legal Counsel',
                                                         'Supply Chain Director', 'Logistics Manager',
                                                         'Billing Operations Manager', 'Accounts Receivable Lead',
                                                         'Customer Success Director', 'Support Director']},
                           'summary':          {'type': 'string'}},
                         'required': ['next_best_action', 'first_step', 'owner_role', 'summary']}}
           )) AS J
    FROM RR_TMP_AI_WORK w
    CROSS JOIN (SELECT QTR_END FROM RR_CONFIG WHERE CONFIG_ID = 1) c;

    -- -----------------------------------------------------------------------
    -- 3. Persist AI columns ONLY (never money). Failed parses are retried next run.
    -- -----------------------------------------------------------------------
    UPDATE RR_RISK_LEDGER t SET
      AI_RISK_CLASS       = r.AI_RISK_CLASS,
      AI_NEXT_BEST_ACTION = r.J:next_best_action::VARCHAR,
      AI_FIRST_STEP       = r.J:first_step::VARCHAR,
      AI_OWNER_ROLE       = r.J:owner_role::VARCHAR,
      AI_SUMMARY          = r.J:summary::VARCHAR,
      AI_MODEL            = :model,
      AI_ENRICHED_HASH    = r.AI_INPUT_HASH,
      AI_ENRICHED_AT      = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
    FROM RR_TMP_AI_RESULTS r
    WHERE t.RISK_ITEM_ID = r.RISK_ITEM_ID
      AND r.J:next_best_action IS NOT NULL;
    enriched := SQLROWCOUNT;
  END IF;

  -- -------------------------------------------------------------------------
  -- 4. AI_AGG category briefs — regenerate only categories whose evidence set changed
  -- -------------------------------------------------------------------------
  CREATE OR REPLACE TEMPORARY TABLE RR_TMP_BRIEF_HASH AS
  SELECT CATEGORY,
         SHA2(LISTAGG(AI_INPUT_HASH, '|') WITHIN GROUP (ORDER BY RISK_ITEM_ID), 256) AS H,
         COUNT(*) AS N
  FROM RR_RISK_LEDGER WHERE ACTIVE_FLAG GROUP BY 1;

  MERGE INTO RR_AI_CATEGORY_BRIEFS t
  USING (
    SELECT l.CATEGORY, hh.H, hh.N,
           AI_AGG(
             COALESCE(l.CUSTOMER_NAME, 'Unknown customer') || ' | blocker: ' || COALESCE(l.BLOCKER, 'n/a')
               || ' | ' || COALESCE(l.EVIDENCE_TEXT, ''),
             'You are briefing the CFO and CRO of NexaSphere Technologies on one revenue-risk category. '
             || 'Identify the 3 to 5 dominant blockers, the common root causes, and the recovery levers that apply. '
             || 'Do not state dollar amounts, counts or percentages; governed SQL supplies all numbers separately. '
             || 'Answer in under 120 words of plain executive language.') AS BRIEF
    FROM RR_RISK_LEDGER l
    JOIN RR_TMP_BRIEF_HASH hh ON hh.CATEGORY = l.CATEGORY
    LEFT JOIN RR_AI_CATEGORY_BRIEFS b ON b.CATEGORY = l.CATEGORY
    WHERE l.ACTIVE_FLAG
      AND b.INPUT_HASH IS DISTINCT FROM hh.H
    GROUP BY l.CATEGORY, hh.H, hh.N
  ) s
  ON t.CATEGORY = s.CATEGORY
  WHEN MATCHED THEN UPDATE SET
    t.INPUT_HASH = s.H, t.ITEM_COUNT = s.N, t.BRIEF = s.BRIEF, t.AI_FUNCTION = 'AI_AGG',
    t.GENERATED_AT = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
  WHEN NOT MATCHED THEN INSERT (CATEGORY, INPUT_HASH, ITEM_COUNT, BRIEF, AI_FUNCTION, GENERATED_AT)
    VALUES (s.CATEGORY, s.H, s.N, s.BRIEF, 'AI_AGG', CURRENT_TIMESTAMP()::TIMESTAMP_NTZ);
  briefs := SQLROWCOUNT;

  DELETE FROM RR_AI_CATEGORY_BRIEFS WHERE CATEGORY NOT IN (SELECT CATEGORY FROM RR_TMP_BRIEF_HASH);

  -- -------------------------------------------------------------------------
  -- 5. Audit
  -- -------------------------------------------------------------------------
  SELECT COUNT(*) INTO :remaining FROM RR_RISK_LEDGER
   WHERE ACTIVE_FLAG AND AI_ENRICHED_HASH IS DISTINCT FROM AI_INPUT_HASH;
  SELECT COUNT(*) INTO :active_count FROM RR_RISK_LEDGER WHERE ACTIVE_FLAG;

  summary := OBJECT_CONSTRUCT('run_id', run_id, 'model', model, 'pending_before', pending,
                              'selected_for_ai', selected, 'enriched', enriched,
                              'skipped_unchanged', active_count - pending,
                              'category_briefs_regenerated', briefs, 'pending_after', remaining);

  INSERT INTO RR_REFRESH_AUDIT (RUN_ID, STAGE, STATUS, STARTED_AT, ENDED_AT, AS_OF_DATE, ROWS_AFFECTED, DETAILS, RUN_BY)
  SELECT :run_id, 'AI_ENRICH', 'SUCCESS', :started_at, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ,
         (SELECT AS_OF_DATE FROM RR_CONFIG WHERE CONFIG_ID = 1), :enriched, :summary, CURRENT_USER();

  RETURN summary;

EXCEPTION
  WHEN OTHER THEN
    err_msg := SQLERRM;
    INSERT INTO RR_REFRESH_AUDIT (RUN_ID, STAGE, STATUS, STARTED_AT, ENDED_AT, AS_OF_DATE, ROWS_AFFECTED, DETAILS, RUN_BY)
    SELECT :run_id, 'AI_ENRICH', 'FAILED', :started_at, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ,
           (SELECT AS_OF_DATE FROM RR_CONFIG WHERE CONFIG_ID = 1), 0,
           OBJECT_CONSTRUCT('error', :err_msg, 'model', :model), CURRENT_USER();
    RAISE;
END;
$$;

-- ===========================================================================
-- EXECUTE
-- ===========================================================================
CALL SP_ENRICH_REVENUE_RISKS_AI(200);

-- Run it again: only the remaining backlog (if any) is sent to the model. Once
-- PENDING_AFTER = 0, further calls make ZERO model calls until evidence changes
-- (incremental proof — compare SELECTED_FOR_AI in the two results).
CALL SP_ENRICH_REVENUE_RISKS_AI(200);

SELECT CATEGORY, AI_RISK_CLASS, COUNT(*) AS ITEMS,
       COUNT_IF(AI_ENRICHED_HASH = AI_INPUT_HASH) AS ENRICHED_CURRENT
FROM RR_RISK_LEDGER WHERE ACTIVE_FLAG
GROUP BY 1, 2 ORDER BY 1, 3 DESC;

SELECT * FROM RR_AI_CATEGORY_BRIEFS ORDER BY CATEGORY;
