# Revenue Recovery Agent — NexaSphere Technologies

**Snowflake + Anthropic hackathon · `HACKATHON_REVENUE_RISK.SOLUTION`**

> *"We are forecasting below our Q4 target. How much revenue is at risk before quarter-end, why, and how much can we still recover?"*

Snowflake detects and calculates the financial truth. Snowflake ML provides an independent second opinion. Cortex Analyst retrieves governed business evidence. The Cortex Agent plans the investigation and orchestrates the tools. Claude Opus 5.5 performs deep analytical reasoning over that trusted evidence. The agent recommends the highest-value actions, validates the numbers, and keeps humans in control of execution.

**What → Why → What is at risk → What is recoverable → What should we do → Expected impact** — with every dollar grounded in Snowflake SQL.

---

## 1. Ground rules this build follows

| Rule | How it is enforced |
|---|---|
| No synthetic data | Only the existing source tables are read. The only `GENERATOR` use is a week calendar used to zero-fill weeks in ML time series. |
| No invented columns | Every source column used is listed in a column contract in `01`, checked against `INFORMATION_SCHEMA.COLUMNS`; the build **stops** if any is missing. Column names come from your `GET_DDL` output. |
| Few persistent views | **Zero** regular views. Persisted decision tables (compute once, query many). The only view is the required semantic view. |
| Locked configuration | `RR_CONFIG` + `SP_ASSERT_CONFIG_LOCKED` (called by every stage) + trust check + validation tests. |
| SQL computes money | Five deterministic mechanisms in `SP_REFRESH_REVENUE_DECISION_LAYER`. |
| ML is a second opinion | ML writes only `ML_*` columns / `RR_ML_*` tables; a trust check proves governed probabilities were not overwritten. |
| Claude never changes money | AI writes only `AI_*` columns; the trust check recomputes the governed row hash to prove it. |
| Expected values are tests, not inputs | Test `V-GOV-01/02` scans calculation procedure source for the benchmark table and for hard-coded totals. |
| Humans approve | Approve/reject procedures are caller's-rights, require an approver role, and are never given to the agent. |
| Cortex Search | Intentionally not used (no unstructured / file data in scope). |

---

## 2. Architecture (maps to your diagram)

```
SOURCE TABLES (DIM_*, FACT_*)                       ── read-only
      │  01 column contract (hard stop)
      ▼
SP_REFRESH_SECOND_OPINION ── RR_ML_* (Snowflake ML: CLASSIFICATION · ANOMALY_DETECTION ·
      │                                FORECAST ×2 · TOP_INSIGHTS, statistical fallback)
      ▼
SP_REFRESH_REVENUE_DECISION_LAYER (Task 1)
      ├─ RR_PRODUCT_INVENTORY_360 → SP_ALLOCATE_ALTERNATE_INVENTORY (Python optimiser)
      ├─ 5 governed mechanisms → RR_RISK_LEDGER  (ROW_HASH · AI_INPUT_HASH · CHANGE_STATUS · lineage query id)
      ├─ RR_OPPORTUNITY_360 · RR_CUSTOMER_360
      └─ RR_REVENUE_OUTLOOK (target · forecast · gap · gross risk · base + upside scenarios)
      ▼
SP_ENRICH_REVENUE_RISKS_AI (Task 2, changed rows only)
      AI_CLASSIFY → risk class · AI_COMPLETE claude-opus-5-5 → action/owner/summary · AI_AGG → category briefs
      ▼
SP_PROPOSE_TOP_RECOVERY_ACTIONS (Task 3, trust-gated) → RR_RECOVERY_ACTIONS (PROPOSED)
      ▼
RR_REVENUE_RISK_SEMANTIC (semantic view + 12 verified queries)
      ▼
RR_REVENUE_RECOVERY_AGENT (orchestration: auto)
  ├─ ExecutiveSnapshot      SP_GET_EXECUTIVE_SNAPSHOT
  ├─ RevenueRiskAnalyst     Cortex Analyst → semantic view
  ├─ DeepRevenueReasoning   SP_DEEP_REVENUE_REASONING → AI_COMPLETE claude-opus-5-5
  ├─ TrustCheck             SP_RR_TRUST_CHECK
  ├─ RecoveryActions · RecoveryScenario · RecoverySimulation · WhatChanged
  ├─ GapClosurePlan · PreventionPlan
  ├─ data_to_chart
  └─ code_execution
      ▼
Surfaces: Snowflake CoWork (executives) · Streamlit app REVENUE_AT_RISK_APP (ask, approve, launch) ·
          Claude Desktop via managed MCP server (read-only role) · CoCo (engineering)
      ▼
Human decision → SP_APPROVE / SP_REJECT / SP_UPDATE_ACTION_STATUS / SP_LAUNCH_PLANNED_CONTROL
               → RR_RECOVERY_ACTIONS / RR_PREVENTION_PLAN → RECOVERY_ACTIONS + PREVENTION_CONTROLS + AGENT_ACTIONS
```

### Why each Snowflake feature is here

| Feature | Purpose in this solution |
|---|---|
| Stored procedures (SQL + Python) | Deterministic money, inventory optimiser, Monte Carlo, agent tools |
| Persisted decision tables | Agent queries a compact governed layer instead of joining raw facts |
| `SNOWFLAKE.ML.CLASSIFICATION` | Independent win probability to challenge the governed pipeline probability |
| `SNOWFLAKE.ML.ANOMALY_DETECTION` | Usage-change anomalies as evidence for renewal / expansion risk |
| `SNOWFLAKE.ML.FORECAST` (×2) | Shipment run-rate to quarter-end; unit demand vs inventory coverage |
| `SNOWFLAKE.ML.TOP_INSIGHTS` | Which region × product segments drive forecast-vs-target gap |
| `AI_CLASSIFY` | Map free-text blockers to a fixed executive taxonomy |
| `AI_COMPLETE` + `claude-opus-5-5` | Per-item next-best action/owner/summary (structured JSON) and deep cross-category reasoning |
| `AI_AGG` | One executive brief per category ("explain the biggest blockers") |
| Semantic view + verified queries | Business vocabulary and trusted SQL for Cortex Analyst |
| Cortex Agent | Plans and orchestrates tools with progressive drill-down |
| Data to Chart | "Show me visually" |
| Code execution | Ad-hoc analysis of tool output (never authoritative money) |
| Tasks | Refresh → enrich changed rows → propose actions |
| CoWork | Executive interaction surface for the agent (not the decision engine) |
| CoCo / Cortex Code | Engineering environment used to inspect objects, iterate SQL/specs and run tests |
| Managed MCP server, masking, row access (optional) | Claude Desktop access under a read-only, pseudonymised role |

---

## 3. Prerequisites

1. A role that owns `HACKATHON_REVENUE_RISK.SOLUTION` (e.g. `SYSADMIN`). Call it `<BUILD_ROLE>`.
2. One-time `ACCOUNTADMIN` grants. These are listed, commented, in `00A` §2:
   * `SNOWFLAKE.CORTEX_USER`
   * cross-region inference, which Opus 5.5 typically needs
   * `CREATE SNOWFLAKE.ML.*`
   * `CREATE AGENT / SEMANTIC VIEW / TASK`
   * `EXECUTE TASK`
3. `claude-opus-5-5` must answer the `AI_COMPLETE` check in `00A`.

---

## 4. Exact execution sequence

Run each file top-to-bottom in a Snowsight worksheet, or use `snow sql -f <file>`. Each file ends with an **EXECUTE** section containing the calls shown below. You do not need to type them separately.

| Step | File | Key calls | Gate |
|---|---|---|---|
| 1 | `00_RESET_GENERATED_OBJECTS.sql` | — | Drops RR objects only |
| 2 | `00A_HACKATHON_WAREHOUSE_AND_CORTEX_CHECK.sql` | `AI_COMPLETE('claude-opus-5-5', …)` | Must return text |
| 3 | `01_PREFLIGHT_AND_CONFIG.sql` | `CALL SP_ASSERT_CONFIG_LOCKED();` | **Stops** if a contracted column is missing |
| 4 | `02_SECOND_OPINION_OUTPUTS.sql` | `CALL SP_REFRESH_SECOND_OPINION();` | |
| 5 | `03_OPTIONAL_NATIVE_SNOWFLAKE_ML.sql` *(optional)* | trains 5 models; `CALL SP_REFRESH_SECOND_OPINION();` | Falls back per model |
| 6 | `04_DECISION_LAYER_OBJECTS.sql` | — | |
| 7 | `05_REFRESH_DECISION_LAYER.sql` | `CALL SP_REFRESH_REVENUE_DECISION_LAYER();` | Stops on ambiguous plan scenario / duplicates |
| 8 | `06_AI_ENRICHMENT.sql` | `CALL SP_ENRICH_REVENUE_RISKS_AI(200);` (×2, shows incremental) | |
| 9 | `07_ACTION_AND_TRUST.sql` | `CALL SP_PROPOSE_TOP_RECOVERY_ACTIONS(10);` (runs the gap-closure and prevention planners first) `CALL SP_RR_TRUST_CHECK();` | Proposals refused if trust FAILS |
| 10 | `08_AGENT_QUERY_SURFACE.sql` | tool smoke calls | |
| 11 | `09_VALIDATION.sql` | `CALL SP_RUN_VALIDATION();` | **STOP on any failure** |
| 12 | `11_FINAL_SMOKE_TEST.sql` | `CALL SP_RUN_SMOKE_TEST();` | **STOP on any failure** |
| 13 | `12_SEMANTIC_VIEW_AND_CORTEX_AGENT.sql` | creates semantic view + agent | Refuses unless 09 and 11 succeeded |
| 14 | `13_AGENT_TESTS.sql` | `CALL SP_RUN_AGENT_TESTS('CORE');` then optionally `('ALL')` | Human review of transcripts |
| 15 | `10_SCHEDULED_TASKS_CREATE_SUSPENDED.sql` | tasks created **suspended** | |
| 16 | *(explicit)* | `CALL SP_ENABLE_RR_TASKS(TRUE);` | Requires validation + smoke + trust PASS + sign-off |
| 17 | `14_OPTIONAL_MCP_GOVERNANCE_AND_COMMAND_CENTER.sql` *(optional)* | MCP server, masking and row-access policies | |
| 18 | `15_STREAMLIT_APP_SUPPORT.sql` | `SP_REFRESH_ANALYTICS()`; creates the JSON app agent `RR_REVENUE_RECOVERY_APP_AGENT` | Run after 12 |
| 19 | `16_DEPLOY_STREAMLIT_APP.sql` | creates `RR_APP_STAGE`, uploads the 10 app files, `CREATE STREAMLIT REVENUE_AT_RISK_APP` | All 10 files must be listed on the stage |

Steps 1–12 are also concatenated in **`RUN_CORE_BUILD_IN_ORDER.sql`**. It includes the optional native-ML block; delete that block if your role lacks Snowflake ML privileges.

Human decisions (Command Center or SQL, as an approver):

```sql
CALL SP_APPROVE_RECOVERY_ACTION('<ACTION_ID>', 'Approved in weekly revenue call');
CALL SP_REJECT_RECOVERY_ACTION('<ACTION_ID>', 'Already escalated by the account team');
```

---

## 5. First run: calibrating rule parameters (please read)

The scripts were written against your schema DDL and current Snowflake documentation. They have **not been executed against your account**: this session has no Snowflake connection, so the category totals have not yet been observed.

The five mechanisms are deterministic and driven by governed parameters in `RR_CONFIG` (a few, such as the renewal usage-decline threshold, are not specified by the business case). If `09` stops on a category test:

1. Open the **calibration profile** at the end of `01` (§7a–7i). It shows how the real data behaves under each rule:
   * distinct stages, statuses and exception codes
   * Q4 totals per plan scenario
   * a renewal sensitivity grid
   * CSAT / P1-P2 sensitivity
   * inventory snapshot coverage
2. Set the matching **rule parameter** in the `INSERT INTO RR_CONFIG` of `01`, then re-run from `01`. Examples: `PLAN_SCENARIO_ID`, `RENEWAL_USAGE_DECLINE_PCT`, `PIPELINE_STAGE_FILTER`, `FULFILLMENT_Q4_PROMISE_ONLY`.
3. **Never** edit the expected totals or the locked values to make a test pass. `V-GOV-02` will catch hard-coded totals in procedures.

Known first-run decision points:

* **`FACT_REVENUE_PLAN` scenarios.** If Q4 contains more than one `SCENARIO_ID`, `05` stops and asks you to set `PLAN_SCENARIO_ID`. See §7b.
* **`USAGE_CHANGE_PCT` scale.** If it is stored as a fraction (−0.22) rather than percent points (−22), set the threshold accordingly. See §7f.
* **Shared alternate inventory.** It is allocated in priority order: earliest promise date, then highest value. `FULFILLMENT_ALLOCATION_POLICY` switches between best-fit and largest-pool.

---

## 6. The five governed risk mechanisms

| Category | Population (as of 2026-10-15) | At risk | Recoverable |
|---|---|---|---|
| Pipeline | Open opportunities closing in Q4 that carry a blocker | `OPPORTUNITY_AMOUNT` | amount × governed `RECOVERY_PROBABILITY` |
| Fulfillment | Orders with reason **"Priority order blocked by component shortage"**, unshipped | `BOOKED_VALUE` | full value only if **one** alternate warehouse with the same product covers the full quantity after earlier allocations |
| Billing | Exceptions on orders shipped on or before the as-of date, not paid/resolved | `AMOUNT` | `RESOLVABLE_FLAG = 'Y'` and not a commercial dispute |
| Renewal | Renewals through quarter-end with usage decline, P1/P2 tickets, or another health risk reason | `RENEWAL_ARR` (**ARR**) | ARR × governed `RECOVERY_PROBABILITY` |
| Support / Expansion | Expansion value where CSAT ≤ **3.2** and open P1/P2 ≥ 1 | `AT_RISK_EXPANSION_VALUE` | value × `SUPPORT_RECOVERY_PROBABILITY` |

Each ledger row also carries:

* `CALCULATION_RULE` — the rule in plain English
* `SOURCE_QUERY_ID` — lineage to the query that produced it
* a stable `EVIDENCE_TEXT`, with no volatile fields, so AI is not re-triggered daily

**Accounting distinction.** Gross revenue at risk ($12.4M) is operational exposure, not the $8.2M forecast gap. The two scenarios are always labelled as illustrative:

* **Base Revised Outlook** = forecast + Pipeline + Fulfillment + Billing recovery
* **Upside Recovery Case** = forecast + all five categories, never a guaranteed forecast

---

## 7. Agent routing (progressive drill-down)

| Question type | Tools |
|---|---|
| How are we doing vs target? How much is at risk? | ExecutiveSnapshot |
| Why? Which customers / deals / orders / invoices? | RevenueRiskAnalyst (semantic view) |
| What should we do? Top actions, owners, CRO/CFO/Supply Chain this week | TrustCheck → RecoveryActions → DeepRevenueReasoning |
| Root cause across categories; ML vs governed | DeepRevenueReasoning (Claude Opus 5.5) |
| What if we recover Pipeline, Fulfillment and Billing? | RecoveryScenario (governed SQL) |
| How confident are we? | RecoverySimulation (statistical, non-authoritative) |
| What changed since the last refresh? | WhatChanged |
| Show me visually | RevenueRiskAnalyst → data_to_chart |

The response contract has nine sections: DIRECT ANSWER · CURRENT POSITION · WHAT IS AT RISK · WHY · WHAT IS RECOVERABLE · TOP ACTIONS · EXPECTED IMPACT · RISKS / CAVEATS · EVIDENCE / TRUST.

**Orchestration model.** Snowflake's Cortex Agents docs recommend `orchestration: auto`, and Opus 5.5 orchestration is listed as public preview. The agent therefore uses `auto`, and Claude Opus 5.5 is invoked explicitly through `AI_COMPLETE` in the DeepRevenueReasoning tool and in enrichment. `12` §4 shows how to pin `claude-opus-5-5` once your account confirms support.

**CoWork.** CoWork is the executive surface for this same agent. Grant `USAGE` on the agent, then register it with your account's Snowflake Intelligence object (see `12` §3).

**CoCo.** CoCo is the engineering loop, not the business agent. Use it to:

* inspect objects (`DESCRIBE AGENT`, the semantic view)
* iterate on the five rule SQL blocks against the calibration profile
* refactor procedures
* run `09` / `11` / `13`
* debug query profiles

---

## 8. Demo script (primary question + 20)

1. Ask the primary question. The expected shape is:
   * Target **$125.0M**, forecast **$116.8M**, gap **$8.2M**
   * Gross risk **$12.4M**, recoverable **$6.4M**
   * By category: Pipeline 4.1 / 1.9 · Fulfillment 3.2 / 1.7 · Billing 1.6 / 1.4 · Renewal 2.3 / 0.9 · Support 1.2 / 0.5
   * Base recovery **$5.0M** → **$121.8M** illustrative outlook, residual gap **$3.2M**, clearly distinct from the $6.4M maximum
2. Then ask:
   * "Where does ML disagree with our governed probability?" (governed vs ML win probability)
   * "Which warehouses can resolve component shortages?" (optimiser output)
   * "Show revenue at risk versus recoverable by category." (chart)
   * "What should the CRO, CFO and Supply Chain leader do this week?" (trust-gated actions)
3. Approve one action in the Command Center, then ask "Who owns the approved actions?"

All 21 questions are scripted in `13_AGENT_TESTS.sql` with expected tool families and figures.

---

## 9. Objects created

**Tables**

| Group | Tables |
|---|---|
| Configuration and fixtures | `RR_CONFIG`, `RR_ACCEPTANCE_BENCHMARKS` (test fixture) |
| Audit, trust and tests | `RR_REFRESH_AUDIT`, `RR_TRUST_RESULTS`, `RR_VALIDATION_RESULTS`, `RR_AGENT_TEST_LOG` |
| ML second opinion | `RR_ML_DEAL_SCORES`, `RR_ML_USAGE_ANOMALIES`, `RR_ML_REVENUE_FORECAST`, `RR_ML_DEMAND_FORECAST`, `RR_ML_GAP_DRIVERS`, `RR_ML_PLAN_FORECAST` (monthly Q4 forecast, P10/P90) |
| 360 decision tables | `RR_CUSTOMER_360`, `RR_OPPORTUNITY_360`, `RR_PRODUCT_INVENTORY_360`, `RR_FULFILLMENT_ALLOCATION` |
| Ledger, outlook and actions | `RR_RISK_LEDGER`, `RR_REVENUE_OUTLOOK`, `RR_AI_CATEGORY_BRIEFS`, `RR_RECOVERY_ACTIONS` |
| Planners | `RR_GAP_PLAN` (gap-closure waterfall + Monte Carlo cumulative probability), `RR_PREVENTION_PLAN` (proposed / launched controls) |
| Optional (`14`) | `RR_REGION_ACCESS` |

**Other objects**

* **Function:** `RR_LEDGER_ROW_HASH`
* **ML models:** `RR_DEAL_WIN_CLASSIFIER`, `RR_USAGE_ANOMALY_MODEL`, `RR_REVENUE_FORECAST_MODEL`, `RR_DEMAND_FORECAST_MODEL`, `RR_PLAN_FORECAST_MODEL`, `RR_GAP_INSIGHTS`
* **Semantic view:** `RR_REVENUE_RISK_SEMANTIC`
* **Agents:** `RR_REVENUE_RECOVERY_AGENT` (CoWork, markdown answers) and `RR_REVENUE_RECOVERY_APP_AGENT` (`15`, same tools, JSON answers for the app)
* **Tasks:** `TASK_RR_REFRESH` → `TASK_RR_AI_ENRICH` → `TASK_RR_PROPOSE_ACTIONS`
* **Optional (`14`):** `RR_REVENUE_RECOVERY_MCP`, masking and row-access policies
* **Streamlit (`15`, `16`):** procedures `SP_REFRESH_ANALYTICS`, `SP_UPDATE_ACTION_STATUS`, `SP_LAUNCH_PLANNED_CONTROL`, `SP_GET_GAP_PLAN`, `SP_GET_PREVENTION_PLAN`; stage `RR_APP_STAGE`; app `REVENUE_AT_RISK_APP`

**Pre-existing tables** (insert / merge only, by human decisions or audit): `AGENT_ACTIONS`, `RECOVERY_ACTIONS`, `PREVENTION_CONTROLS`, `VERIFIED_ANSWERS`.

---

## 10. Self-review (section 29)

✅ = satisfied in the code as delivered. ⏳ = enforced by a deterministic test but **not yet observed**, because the scripts have not been run in your account.

| Check | Status |
|---|---|
| Source columns inspected rather than guessed | ✅ From your `GET_DDL`; re-verified at runtime by the `01` contract (124 columns, hard stop) |
| Oct 15 as-of date preserved | ✅ `RR_CONFIG`, lock assertion, `V-CFG-01` |
| CSAT 3.2 preserved | ✅ |
| Original fulfillment reason preserved | ✅ Exact string, exact-match rule |
| Claude Opus 5.5 configuration preserved | ✅ `AI_MODEL = 'claude-opus-5-5'` |
| No Sonnet model; no other as-of dates | ✅ Grep-verified across all files |
| Pipeline 4.1 / 1.9 | ⏳ `V-CAT-PIPELINE-*` |
| Fulfillment 3.2 / 1.7 | ⏳ `V-CAT-FULFILLMENT-*` |
| Billing 1.6 / 1.4 | ⏳ `V-CAT-BILLING-*` |
| Renewal 2.3 / 0.9 | ⏳ `V-CAT-RENEWAL-*` (may need §5 calibration) |
| Support 1.2 / 0.5 | ⏳ `V-CAT-SUPPORT-*` |
| Total 12.4 / 6.4 | ⏳ `V-TOT-*` |
| $12.4M not represented as the $8.2M gap | ✅ Separate columns, accounting note, `V-OUT-RISK-NOT-GAP`, agent instructions |
| Base recovery $5.0M; base outlook $121.8M | ⏳ `V-OUT-BASE-*` (arithmetic identities ✅ in the trust check) |
| Cortex Agent and semantic view actually created | ✅ Created by `12`; verified by `13` deployment checks |
| Verified queries included | ✅ 12 queries, including the 5 required |
| Cortex Analyst used | ✅ `RevenueRiskAnalyst` tool |
| Claude Opus 5.5 deep-reasoning tool used | ✅ `SP_DEEP_REVENUE_REASONING` |
| `AI_CLASSIFY` / `AI_COMPLETE` have clear roles | ✅ Taxonomy vs structured recommendations / deep reasoning (plus `AI_AGG` briefs) |
| ML is a second opinion | ✅ Plus trust check `ML_DID_NOT_OVERWRITE_GOVERNED_PROB` |
| Data to Chart available | ✅ |
| TrustCheck before financial recommendations | ✅ Agent instructions, proposal gate, smoke test |
| Human approval required | ✅ Caller's-rights approver procedures; no approval tool on the agent |
| Tasks initially suspended | ✅ Enabled only via `SP_ENABLE_RR_TASKS(TRUE)` |
| README contains exact execution order | ✅ §4 |

---

## 11. Documentation consulted

* [CREATE AGENT](https://docs.snowflake.com/en/sql-reference/sql/create-agent)
* [Create and manage agents](https://docs.snowflake.com/en/user-guide/snowflake-cortex/cortex-agents-manage)
* [Cortex Agents models](https://docs.snowflake.com/en/user-guide/snowflake-cortex/cortex-agents)
* [Code execution tool](https://docs.snowflake.com/en/user-guide/snowflake-cortex/cortex-agents-code-execution-tool)
* [CREATE SEMANTIC VIEW](https://docs.snowflake.com/en/sql-reference/sql/create-semantic-view)
* [Top Insights](https://docs.snowflake.com/en/user-guide/ml-functions/top-insights)
* [CREATE MCP SERVER](https://docs.snowflake.com/en/sql-reference/sql/create-mcp-server)
* [AI_COMPLETE](https://docs.snowflake.com/en/sql-reference/functions/ai_complete-prompt-object)
* [Claude Opus 5.5 on Cortex AI](https://www.snowflake.com/en/blog/claude-opus-5-5-cortex-ai/)
* [CoWork getting started](https://docs.snowflake.com/en/user-guide/snowflake-cortex/snowflake-cowork/getting-started)

---

## 12. Streamlit app (`streamlit/`)

Five pages, built from `UI_PROMPT.md`: **Ask the Agent** (chat + Insights panel), **Overview** (governed numbers, no LLM call),
**Action Board** (approve / reject / start / done, prevention-control launch, audit trail, Admin → Rebuild analytics),
**Reasoning Trace** and **Architecture**. All data comes through `rr_backend.py`.

* `rr_backend.py` keeps its public functions and return shapes, but its internals were changed to read the `SOLUTION` decision tables.
  The page queries are written inline in the module (`LOGICAL_VIEWS`), so no database views are created.
* Charts are drawn only from governed tables, chosen by the tools and SQL the agent actually used (`charts_for`, `CHART_QUERIES`).
* The trust badge reads PASSED only when two things hold. First, every $ figure in the answer matches a number returned by a tool. Second, the latest governed `SP_RR_TRUST_CHECK` did not fail.
* The app runs with its owner's rights. For that reason the viewer's name is appended to every approval note, and `AGENT_ACTIONS` records the app owner as the actor.
* Status lifecycle: `PROPOSED → APPROVED → IN_PROGRESS → DONE` (or `REJECTED`); superseded proposals are hidden.

