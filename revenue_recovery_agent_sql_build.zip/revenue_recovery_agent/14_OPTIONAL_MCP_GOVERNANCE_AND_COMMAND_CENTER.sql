/* =============================================================================
   14_OPTIONAL_MCP_GOVERNANCE_AND_COMMAND_CENTER.sql   (OPTIONAL — architecture extras)

   Implements the remaining surfaces from the architecture diagram:
     A. Masking + row access for the read-only AI role (MCP_CLAUDE_ROLE) and
        region-scoped account managers.
     B. Snowflake-managed MCP server so Claude Desktop (Recovery Owners) reaches
        the SAME governed tools and agent.
     C. NexaSphere Command Center (Streamlit) — deployed by 16_DEPLOY_STREAMLIT_APP.sql
        from rr_build/streamlit/ (5-page app; support objects in 15).

   Nothing here changes the governed numbers; run after 13.
   Cortex Search is intentionally NOT used (no unstructured/file data in scope).
   ============================================================================= */

USE DATABASE HACKATHON_REVENUE_RISK;
USE SCHEMA SOLUTION;
USE WAREHOUSE RR_WH;

-- ---------------------------------------------------------------------------
-- A. Governance: masking + row access (applied to RR_* decision tables only)
-- ---------------------------------------------------------------------------
-- USE ROLE SECURITYADMIN;
-- CREATE ROLE IF NOT EXISTS MCP_CLAUDE_ROLE;   -- read-only role used by Claude Desktop via MCP
-- GRANT ROLE MCP_CLAUDE_ROLE TO ROLE SYSADMIN;
-- USE ROLE <BUILD_ROLE>;

CREATE MASKING POLICY IF NOT EXISTS RR_MASK_CUSTOMER_NAME AS (VAL VARCHAR) RETURNS VARCHAR ->
  CASE WHEN IS_ROLE_IN_SESSION('MCP_CLAUDE_ROLE') THEN 'Customer-' || LEFT(SHA2(VAL, 256), 8)
       ELSE VAL END
  COMMENT = 'Pseudonymises customer names for the read-only AI role.';

ALTER TABLE RR_RISK_LEDGER      MODIFY COLUMN CUSTOMER_NAME SET MASKING POLICY RR_MASK_CUSTOMER_NAME;
ALTER TABLE RR_CUSTOMER_360     MODIFY COLUMN CUSTOMER_NAME SET MASKING POLICY RR_MASK_CUSTOMER_NAME;
ALTER TABLE RR_OPPORTUNITY_360  MODIFY COLUMN CUSTOMER_NAME SET MASKING POLICY RR_MASK_CUSTOMER_NAME;
ALTER TABLE RR_RECOVERY_ACTIONS MODIFY COLUMN CUSTOMER_NAME SET MASKING POLICY RR_MASK_CUSTOMER_NAME;

-- Source-table policies change pre-existing objects; enable deliberately:
-- CREATE MASKING POLICY IF NOT EXISTS RR_MASK_MARGIN AS (VAL NUMBER(8,4)) RETURNS NUMBER(8,4) ->
--   CASE WHEN IS_ROLE_IN_SESSION('MCP_CLAUDE_ROLE') THEN NULL ELSE VAL END;
-- ALTER TABLE DIM_PRODUCT  MODIFY COLUMN MARGIN_PCT    SET MASKING POLICY RR_MASK_MARGIN;
-- ALTER TABLE DIM_CUSTOMER MODIFY COLUMN CUSTOMER_NAME SET MASKING POLICY RR_MASK_CUSTOMER_NAME;

-- Region-scoped visibility for account managers. Mapping rows are maintained by admins
-- (no rows are generated here). Roles not in the mapping and not listed as
-- unrestricted see nothing; owner/admin roles see everything.
CREATE TABLE IF NOT EXISTS RR_REGION_ACCESS (
  ROLE_NAME   VARCHAR NOT NULL,
  REGION_NAME VARCHAR NOT NULL
) COMMENT = 'Role -> region visibility for RR_RISK_LEDGER (maintained by admins).';

CREATE ROW ACCESS POLICY IF NOT EXISTS RR_REGION_ROW_ACCESS AS (REGION VARCHAR) RETURNS BOOLEAN ->
  IS_ROLE_IN_SESSION('ACCOUNTADMIN') OR IS_ROLE_IN_SESSION('SYSADMIN')
  OR IS_ROLE_IN_SESSION('RR_APPROVER') OR IS_ROLE_IN_SESSION('RR_AGENT_USER') OR IS_ROLE_IN_SESSION('MCP_CLAUDE_ROLE')
  OR EXISTS (SELECT 1 FROM HACKATHON_REVENUE_RISK.SOLUTION.RR_REGION_ACCESS a
              WHERE a.REGION_NAME = REGION AND IS_ROLE_IN_SESSION(a.ROLE_NAME))
  COMMENT = 'Account managers see only their regions; leadership and AI roles see all.';

-- Enable after populating RR_REGION_ACCESS (the build role must be covered above):
-- ALTER TABLE RR_RISK_LEDGER ADD ROW ACCESS POLICY RR_REGION_ROW_ACCESS ON (REGION_NAME);

-- ---------------------------------------------------------------------------
-- B. Snowflake-managed MCP server (Claude Desktop -> governed tools)
-- ---------------------------------------------------------------------------
CREATE OR REPLACE MCP SERVER RR_REVENUE_RECOVERY_MCP
  FROM SPECIFICATION $$
    tools:
      - name: "revenue-recovery-agent"
        type: "CORTEX_AGENT_RUN"
        identifier: "HACKATHON_REVENUE_RISK.SOLUTION.RR_REVENUE_RECOVERY_AGENT"
        title: "Revenue Recovery Agent"
        description: "Ask the governed NexaSphere Revenue Recovery Agent about Q4 revenue risk, recovery and actions."
        annotations:
          readOnlyHint: true
          destructiveHint: false
          openWorldHint: false
      - name: "revenue-risk-analyst"
        type: "CORTEX_ANALYST_MESSAGE"
        identifier: "HACKATHON_REVENUE_RISK.SOLUTION.RR_REVENUE_RISK_SEMANTIC"
        title: "Revenue Risk Analyst"
        description: "Cortex Analyst over the governed revenue risk semantic view."
      - name: "executive-snapshot"
        type: "GENERIC"
        identifier: "HACKATHON_REVENUE_RISK.SOLUTION.SP_GET_EXECUTIVE_SNAPSHOT"
        title: "Executive Snapshot"
        description: "Authoritative Q4 target, forecast, gap, revenue at risk, recoverable and scenarios."
        annotations:
          readOnlyHint: true
          destructiveHint: false
          idempotentHint: true
          openWorldHint: false
        config:
          type: "procedure"
          warehouse: "RR_WH"
          input_schema:
            type: "object"
            properties: {}
      - name: "trust-check"
        type: "GENERIC"
        identifier: "HACKATHON_REVENUE_RISK.SOLUTION.SP_RR_TRUST_CHECK"
        title: "Trust Check"
        description: "Governed reconciliation and lineage checks; PASS / WARN / FAIL."
        annotations:
          readOnlyHint: true
          destructiveHint: false
          openWorldHint: false
        config:
          type: "procedure"
          warehouse: "RR_WH"
          input_schema:
            type: "object"
            properties: {}
      - name: "recovery-actions"
        type: "GENERIC"
        identifier: "HACKATHON_REVENUE_RISK.SOLUTION.SP_GET_RECOVERY_ACTIONS"
        title: "Recovery Actions"
        description: "Ranked recovery actions with owners and governed expected recovery (read-only)."
        annotations:
          readOnlyHint: true
          destructiveHint: false
          idempotentHint: true
          openWorldHint: false
        config:
          type: "procedure"
          warehouse: "RR_WH"
          input_schema:
            type: "object"
            properties:
              P_TOP_N:
                description: "Number of actions"
                type: "number"
              P_STATUS:
                description: "OPEN, PROPOSED, APPROVED, REJECTED or ALL"
                type: "string"
  $$;

DESCRIBE MCP SERVER RR_REVENUE_RECOVERY_MCP;

-- Grants for the read-only AI role used by Claude Desktop:
-- GRANT USAGE ON MCP SERVER RR_REVENUE_RECOVERY_MCP TO ROLE MCP_CLAUDE_ROLE;
-- GRANT USAGE ON DATABASE HACKATHON_REVENUE_RISK TO ROLE MCP_CLAUDE_ROLE;
-- GRANT USAGE ON SCHEMA HACKATHON_REVENUE_RISK.SOLUTION TO ROLE MCP_CLAUDE_ROLE;
-- GRANT USAGE ON WAREHOUSE RR_WH TO ROLE MCP_CLAUDE_ROLE;
-- GRANT USAGE ON AGENT RR_REVENUE_RECOVERY_AGENT TO ROLE MCP_CLAUDE_ROLE;
-- GRANT SELECT ON SEMANTIC VIEW RR_REVENUE_RISK_SEMANTIC TO ROLE MCP_CLAUDE_ROLE;
-- GRANT SELECT ON TABLE RR_RISK_LEDGER, RR_CUSTOMER_360, RR_RECOVERY_ACTIONS TO ROLE MCP_CLAUDE_ROLE;
-- GRANT USAGE ON PROCEDURE SP_GET_EXECUTIVE_SNAPSHOT() TO ROLE MCP_CLAUDE_ROLE;
-- GRANT USAGE ON PROCEDURE SP_RR_TRUST_CHECK() TO ROLE MCP_CLAUDE_ROLE;
-- GRANT USAGE ON PROCEDURE SP_GET_RECOVERY_ACTIONS(NUMBER, VARCHAR) TO ROLE MCP_CLAUDE_ROLE;
-- (No approve / reject procedures are granted to MCP_CLAUDE_ROLE.)

-- ---------------------------------------------------------------------------
-- C. NexaSphere Command Center
--    The multi-page Streamlit app lives in rr_build/streamlit/ and is deployed by
--    16_DEPLOY_STREAMLIT_APP.sql (stage RR_APP_STAGE, app REVENUE_AT_RISK_APP).
-- ---------------------------------------------------------------------------
