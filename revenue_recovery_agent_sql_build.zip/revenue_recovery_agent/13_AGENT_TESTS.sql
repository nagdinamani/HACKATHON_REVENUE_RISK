/* =============================================================================
   13_AGENT_TESTS.sql
   Behavioural tests of RR_REVENUE_RECOVERY_AGENT through SNOWFLAKE.CORTEX.DATA_AGENT_RUN.

   * Deployment checks: agent exists, orchestration model matches RR_CONFIG.
   * Question suite: the primary demo question + the 20 additional demo questions.
     For each answer we check (a) the expected tool family was used, (b) TrustCheck
     was called where recommendations are expected, (c) governed figures appear
     where the answer must quote them.
   * Agent answers are LLM output: results are recorded for HUMAN REVIEW and do
     not raise. Tasks are only enabled after a human signs off
     (CALL SP_ENABLE_RR_TASKS(TRUE) in 10).

   P_MODE: 'CORE' (5 questions, cheaper) or 'ALL' (21 questions).
   ============================================================================= */

USE DATABASE HACKATHON_REVENUE_RISK;
USE SCHEMA SOLUTION;
USE WAREHOUSE RR_WH;

-- ---------------------------------------------------------------------------
-- Deployment checks
-- ---------------------------------------------------------------------------
SHOW AGENTS LIKE 'RR_REVENUE_RECOVERY_AGENT' IN SCHEMA HACKATHON_REVENUE_RISK.SOLUTION;
SHOW SEMANTIC VIEWS LIKE 'RR_REVENUE_RISK_SEMANTIC' IN SCHEMA HACKATHON_REVENUE_RISK.SOLUTION;

DESCRIBE AGENT RR_REVENUE_RECOVERY_AGENT;
SELECT IFF(TO_JSON(OBJECT_CONSTRUCT(*)) ILIKE '%orchestration: ' || (SELECT AGENT_ORCHESTRATION_MODEL FROM RR_CONFIG WHERE CONFIG_ID = 1) || '%',
           'PASS', 'FAIL') AS AGENT_MODEL_MATCHES_CONFIG,
       IFF(TO_JSON(OBJECT_CONSTRUCT(*)) ILIKE '%SP_DEEP_REVENUE_REASONING%', 'PASS', 'FAIL') AS DEEP_REASONING_TOOL_WIRED,
       IFF(TO_JSON(OBJECT_CONSTRUCT(*)) ILIKE '%RR_REVENUE_RISK_SEMANTIC%', 'PASS', 'FAIL') AS ANALYST_TOOL_WIRED,
       IFF(TO_JSON(OBJECT_CONSTRUCT(*)) ILIKE '%data_to_chart%', 'PASS', 'FAIL') AS DATA_TO_CHART_WIRED,
       IFF(TO_JSON(OBJECT_CONSTRUCT(*)) ILIKE '%SP_APPROVE_RECOVERY_ACTION%', 'FAIL', 'PASS') AS NO_APPROVAL_TOOL
FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));

-- ---------------------------------------------------------------------------
-- Test log
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS RR_AGENT_TEST_LOG (
  TEST_RUN_ID         VARCHAR NOT NULL,
  QID                 VARCHAR NOT NULL,
  QUESTION            VARCHAR,
  RESPONSE            VARIANT,
  ANSWER_TEXT         VARCHAR,
  EXPECTED_TOOLS      VARCHAR,
  EXPECTED_STRINGS    VARCHAR,
  TOOL_CHECK          BOOLEAN,
  TRUST_CHECK_CALLED  BOOLEAN,
  STRING_CHECK        BOOLEAN,
  STATUS              VARCHAR COMMENT 'PASS | REVIEW | ERROR',
  TESTED_AT           TIMESTAMP_NTZ
) COMMENT = 'Agent behavioural test transcripts for human review.';

CREATE OR REPLACE PROCEDURE SP_RUN_AGENT_TESTS(P_MODE VARCHAR)
RETURNS VARIANT
LANGUAGE SQL
EXECUTE AS CALLER
COMMENT = 'Runs the demo question suite against RR_REVENUE_RECOVERY_AGENT and records checks for human review.'
AS
$$
DECLARE
  run_id   VARCHAR DEFAULT ('AT-' || TO_VARCHAR(CURRENT_TIMESTAMP(), 'YYYYMMDDHH24MISSFF3'));
  mode     VARCHAR;
  qid      VARCHAR;
  q        VARCHAR;
  body     VARCHAR;
  resp     VARIANT;
  answer   VARCHAR;
  summary  VARIANT;
BEGIN
  mode := UPPER(COALESCE(P_MODE, 'CORE'));

  -- QID | question | expected tools (any of, |-separated) | strings that must appear (all of) | expect TrustCheck | core
  CREATE OR REPLACE TEMPORARY TABLE RR_TMP_AGENT_Q (QID VARCHAR, QUESTION VARCHAR, ANY_TOOLS VARCHAR, ALL_STRINGS VARCHAR, EXPECT_TRUST BOOLEAN, IN_CORE BOOLEAN);
  INSERT INTO RR_TMP_AGENT_Q VALUES
   ('Q00', 'We are forecasting below our Q4 target. How much revenue is at risk before quarter-end, why, and how much can we still recover?',
           'ExecutiveSnapshot', '125.0|116.8|8.2|12.4|6.4|5.0|121.8|3.2', TRUE, TRUE),
   ('Q01', 'Which category is creating the largest revenue risk?', 'ExecutiveSnapshot|RevenueRiskAnalyst', '', FALSE, FALSE),
   ('Q02', 'Why is pipeline revenue at risk?', 'RevenueRiskAnalyst|DeepRevenueReasoning', '', FALSE, FALSE),
   ('Q03', 'Which pipeline deals should Sales leadership focus on first?', 'RevenueRiskAnalyst|RecoveryActions|DeepRevenueReasoning', '', FALSE, FALSE),
   ('Q04', 'Which fulfillment orders can still be recovered?', 'RevenueRiskAnalyst', '', FALSE, FALSE),
   ('Q05', 'Which warehouses can resolve component shortages?', 'RevenueRiskAnalyst|DeepRevenueReasoning', '', FALSE, FALSE),
   ('Q06', 'Which billing exceptions can be cleared before quarter-end?', 'RevenueRiskAnalyst', '', FALSE, FALSE),
   ('Q07', 'Which customers are at renewal risk?', 'RevenueRiskAnalyst', '', FALSE, FALSE),
   ('Q08', 'Which accounts have deteriorating customer health?', 'RevenueRiskAnalyst', '', FALSE, FALSE),
   ('Q09', 'Which expansion opportunities are threatened by support issues?', 'RevenueRiskAnalyst', '', FALSE, FALSE),
   ('Q10', 'Where does ML disagree with our governed recovery probability?', 'RevenueRiskAnalyst|DeepRevenueReasoning', '', FALSE, FALSE),
   ('Q11', 'What are the top ten recovery actions?', 'RecoveryActions|RevenueRiskAnalyst', '', TRUE, FALSE),
   ('Q12', 'Who owns those actions?', 'RecoveryActions|RevenueRiskAnalyst', '', FALSE, FALSE),
   ('Q13', 'What is the expected recovery from the top five actions?', 'RecoveryActions', '', FALSE, FALSE),
   ('Q14', 'What is our base recovery scenario?', 'ExecutiveSnapshot|RecoveryScenario', '5.0|121.8|3.2', FALSE, TRUE),
   ('Q15', 'What is the upside recovery scenario?', 'ExecutiveSnapshot|RecoveryScenario', '6.4|123.2|1.8', FALSE, FALSE),
   ('Q16', 'What would the revised outlook be if Pipeline, Fulfillment and Billing recovery succeeds?', 'RecoveryScenario|ExecutiveSnapshot', '121.8|3.2', FALSE, TRUE),
   ('Q17', 'Show revenue at risk versus recoverable revenue by category.', 'data_to_chart', '', FALSE, TRUE),
   ('Q18', 'Explain the biggest blockers in executive language.', 'DeepRevenueReasoning|RevenueRiskAnalyst', '', FALSE, FALSE),
   ('Q19', 'What changed since the previous refresh?', 'WhatChanged|RevenueRiskAnalyst', '', FALSE, FALSE),
   ('Q20', 'What should the CRO, CFO and Supply Chain leader do this week?', 'RecoveryActions|DeepRevenueReasoning', '', TRUE, TRUE);

  IF (mode <> 'ALL') THEN
    DELETE FROM RR_TMP_AGENT_Q WHERE NOT IN_CORE;
  END IF;

  LET c1 CURSOR FOR SELECT QID, QUESTION FROM RR_TMP_AGENT_Q ORDER BY QID;
  FOR rec IN c1 DO
    qid := rec.QID;
    q := rec.QUESTION;
    body := TO_JSON(OBJECT_CONSTRUCT('messages', ARRAY_CONSTRUCT(
              OBJECT_CONSTRUCT('role', 'user', 'content', ARRAY_CONSTRUCT(OBJECT_CONSTRUCT('type', 'text', 'text', q))))));
    BEGIN
      SELECT TRY_PARSE_JSON(SNOWFLAKE.CORTEX.DATA_AGENT_RUN(
               'HACKATHON_REVENUE_RISK.SOLUTION.RR_REVENUE_RECOVERY_AGENT', :body, TRUE))
        INTO :resp;
    EXCEPTION
      WHEN OTHER THEN
        resp := OBJECT_CONSTRUCT('error', SQLERRM);
    END;

    SELECT COALESCE(LISTAGG(f.VALUE:text::VARCHAR, '\n'), '') INTO :answer
      FROM TABLE(FLATTEN(INPUT => GET(:resp, 'content'), OUTER => TRUE)) f
     WHERE f.VALUE:type::VARCHAR = 'text';

    INSERT INTO RR_AGENT_TEST_LOG (TEST_RUN_ID, QID, QUESTION, RESPONSE, ANSWER_TEXT, EXPECTED_TOOLS, EXPECTED_STRINGS, TESTED_AT)
    SELECT :run_id, :qid, :q, :resp, :answer, t.ANY_TOOLS, t.ALL_STRINGS, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
    FROM RR_TMP_AGENT_Q t WHERE t.QID = :qid;
  END FOR;

  -- Evaluate (tool names are searched in the full response JSON; figures in the final answer text)
  UPDATE RR_AGENT_TEST_LOG l
     SET TOOL_CHECK = e.TOOL_OK,
         TRUST_CHECK_CALLED = e.TRUST_OK,
         STRING_CHECK = e.STR_OK,
         STATUS = CASE WHEN l.RESPONSE:error IS NOT NULL THEN 'ERROR'
                       WHEN e.TOOL_OK AND e.STR_OK AND (NOT e.EXPECT_TRUST OR e.TRUST_OK) THEN 'PASS'
                       ELSE 'REVIEW' END
    FROM (
      SELECT x.QID, q.EXPECT_TRUST,
             COALESCE(tt.HITS, 0) > 0 AS TOOL_OK,
             CONTAINS(TO_JSON(x.RESPONSE), '"TrustCheck"') AS TRUST_OK,
             COALESCE(ss.MISSING, 0) = 0 AS STR_OK
      FROM RR_AGENT_TEST_LOG x
      JOIN RR_TMP_AGENT_Q q ON q.QID = x.QID
      LEFT JOIN (
        SELECT l2.QID, COUNT_IF(CONTAINS(TO_JSON(l2.RESPONSE), '"' || s.VALUE || '"')) AS HITS
        FROM RR_AGENT_TEST_LOG l2
        JOIN RR_TMP_AGENT_Q q2 ON q2.QID = l2.QID,
        LATERAL SPLIT_TO_TABLE(q2.ANY_TOOLS, '|') s
        WHERE l2.TEST_RUN_ID = :run_id
        GROUP BY 1) tt ON tt.QID = x.QID
      LEFT JOIN (
        SELECT l3.QID, COUNT_IF(NOT CONTAINS(COALESCE(NULLIF(l3.ANSWER_TEXT, ''), TO_JSON(l3.RESPONSE)), s.VALUE)) AS MISSING
        FROM RR_AGENT_TEST_LOG l3
        JOIN RR_TMP_AGENT_Q q3 ON q3.QID = l3.QID,
        LATERAL SPLIT_TO_TABLE(q3.ALL_STRINGS, '|') s
        WHERE l3.TEST_RUN_ID = :run_id AND q3.ALL_STRINGS <> ''
        GROUP BY 1) ss ON ss.QID = x.QID
      WHERE x.TEST_RUN_ID = :run_id
    ) e
   WHERE l.TEST_RUN_ID = :run_id AND l.QID = e.QID;

  SELECT OBJECT_CONSTRUCT('test_run_id', :run_id, 'mode', :mode, 'questions', COUNT(*),
                          'pass', COUNT_IF(STATUS = 'PASS'), 'review', COUNT_IF(STATUS = 'REVIEW'),
                          'error', COUNT_IF(STATUS = 'ERROR'),
                          'needs_review', ARRAY_AGG(IFF(STATUS <> 'PASS', QID, NULL)))
    INTO :summary
    FROM RR_AGENT_TEST_LOG WHERE TEST_RUN_ID = :run_id;

  INSERT INTO RR_REFRESH_AUDIT (RUN_ID, STAGE, STATUS, STARTED_AT, ENDED_AT, AS_OF_DATE, ROWS_AFFECTED, DETAILS, RUN_BY)
  SELECT :run_id, 'AGENT_TESTS', IFF(GET(:summary, 'pass')::NUMBER = GET(:summary, 'questions')::NUMBER, 'SUCCESS', 'REVIEW'),
         CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ,
         (SELECT AS_OF_DATE FROM RR_CONFIG WHERE CONFIG_ID = 1), GET(:summary, 'questions')::NUMBER, :summary, CURRENT_USER();

  RETURN summary;
END;
$$;

-- ===========================================================================
-- EXECUTE
-- ===========================================================================
CALL SP_RUN_AGENT_TESTS('CORE');      -- 5 questions
-- CALL SP_RUN_AGENT_TESTS('ALL');    -- all 21 demo questions

SELECT QID, STATUS, TOOL_CHECK, TRUST_CHECK_CALLED, STRING_CHECK, QUESTION, LEFT(ANSWER_TEXT, 1500) AS ANSWER_PREVIEW
FROM RR_AGENT_TEST_LOG
WHERE TEST_RUN_ID = (SELECT MAX(TEST_RUN_ID) FROM RR_AGENT_TEST_LOG)
ORDER BY QID;

-- Human review checklist for each answer:
--   [ ] every $ figure matches SP_GET_EXECUTIVE_SNAPSHOT / ledger
--   [ ] gross risk is not presented as the forecast gap
--   [ ] Base Revised Outlook / Upside Recovery Case labelled illustrative
--   [ ] renewal treated as ARR
--   [ ] TrustCheck status reported for recommendations
--   [ ] no claim that an action was approved by the agent
-- When satisfied: CALL SP_ENABLE_RR_TASKS(TRUE);   (file 10)
