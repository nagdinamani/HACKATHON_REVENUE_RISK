/* =============================================================================
   07_ACTION_AND_TRUST.sql
   Trust validation + human-in-the-loop action engine.

     RR_TRUST_RESULTS                 every check of every trust run
     RR_RECOVERY_ACTIONS              proposed / approved / rejected / superseded actions
     SP_RR_TRUST_CHECK()              reconciliation, lineage, integrity, config lock, freshness,
                                      AI-tamper proof, ML-non-overwrite proof, benchmarks
     SP_PLAN_GAP_CLOSURE              gap-closure planner (Python): forecast -> category steps -> target, Monte Carlo per step
     SP_PLAN_PREVENTION_CONTROLS      prevention planner: recurring blocker classes -> proposed controls
     SP_PROPOSE_TOP_RECOVERY_ACTIONS  runs both planners, then AI/rule recommendations -> PROPOSED only (refuses if trust FAILS)
     SP_UPDATE_ACTION_STATUS          human progress update APPROVED -> IN_PROGRESS -> DONE
     SP_LAUNCH_PLANNED_CONTROL        human launch of a planned prevention control
     SP_APPROVE_RECOVERY_ACTION       human decision (caller's rights, approver role required)
     SP_REJECT_RECOVERY_ACTION        human decision (caller's rights, approver role + reason required)
     SP_RR_MIRROR_DECISION            mirrors human decisions into pre-existing RECOVERY_ACTIONS
     SP_LAUNCH_PREVENTION_CONTROL     human-launched prevention control -> PREVENTION_CONTROLS
     SP_SAVE_VERIFIED_ANSWER          human-curated answer -> VERIFIED_ANSWERS

   AI can recommend. Humans approve. The agent is never given approve/reject tools.
   ============================================================================= */

USE DATABASE HACKATHON_REVENUE_RISK;
USE SCHEMA SOLUTION;
USE WAREHOUSE RR_WH;

-- ---------------------------------------------------------------------------
-- Tables
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS RR_TRUST_RESULTS (
  TRUST_RUN_ID  VARCHAR NOT NULL,
  CHECK_NAME    VARCHAR NOT NULL,
  CHECK_GROUP   VARCHAR,
  SEVERITY      VARCHAR COMMENT 'CRITICAL | WARN',
  STATUS        VARCHAR COMMENT 'PASS | FAIL',
  EXPECTED      VARCHAR,
  ACTUAL        VARCHAR,
  CHECKED_AT    TIMESTAMP_NTZ
) COMMENT = 'Results of SP_RR_TRUST_CHECK runs.';

CREATE TABLE IF NOT EXISTS RR_RECOVERY_ACTIONS (
  ACTION_ID              VARCHAR NOT NULL,
  RISK_ITEM_ID           VARCHAR NOT NULL,
  CATEGORY               VARCHAR,
  CUSTOMER_ID            VARCHAR,
  CUSTOMER_NAME          VARCHAR,
  ACTION_TEXT            VARCHAR,
  OWNER_ROLE             VARCHAR,
  FIRST_STEP             VARCHAR,
  DUE_DATE               DATE,
  EXPECTED_RECOVERY_USD  NUMBER(18,2) COMMENT 'Equals the governed RECOVERABLE_USD of the risk item; never AI-generated.',
  PRIORITY_RANK          NUMBER,
  PRIORITY_SCORE         NUMBER(18,2) COMMENT 'Recoverable x urgency (deterministic).',
  STATUS                 VARCHAR      COMMENT 'PROPOSED | APPROVED | IN_PROGRESS | DONE | REJECTED | SUPERSEDED',
  ACTION_SOURCE          VARCHAR      COMMENT 'AI_RECOMMENDED (claude-opus-5-5) | RULE_TEMPLATE',
  PROPOSED_BY            VARCHAR,
  PROPOSED_AT            TIMESTAMP_NTZ,
  DECISION_BY            VARCHAR,
  DECISION_TIME          TIMESTAMP_NTZ,
  NOTES                  VARCHAR,
  SOURCE_ROW_HASH        VARCHAR,
  SOURCE_AI_HASH         VARCHAR,
  REFRESH_ID             VARCHAR,
  AS_OF_DATE             DATE,
  UPDATED_AT             TIMESTAMP_NTZ,
  CONSTRAINT PK_RR_ACTIONS PRIMARY KEY (ACTION_ID)
) COMMENT = 'Recovery action engine. AI recommends (PROPOSED); only humans APPROVE / REJECT.';

CREATE TABLE IF NOT EXISTS RR_GAP_PLAN (
  STEP_ORDER                 NUMBER NOT NULL COMMENT '0 = current forecast; 1..n = recovery steps',
  CATEGORY                   VARCHAR,
  STEP_LABEL                 VARCHAR,
  EXPECTED_USD               NUMBER(18,2) COMMENT 'Governed recoverable value of the step (sum of ledger RECOVERABLE_USD)',
  CUMULATIVE_FORECAST_USD    NUMBER(18,2) COMMENT 'Forecast + recoverable of this and all earlier steps (illustrative)',
  REMAINING_GAP_USD          NUMBER(18,2),
  IN_BASE_SCENARIO           BOOLEAN,
  NEEDS_APPROVAL             BOOLEAN      COMMENT 'TRUE for modeled / estimate steps outside the governed base scenario',
  PROB_CLOSE_GAP_CUMULATIVE  NUMBER(8,4)  COMMENT 'Monte Carlo share of runs where recovery through this step covers the forecast gap (statistical)',
  ITEMS                      NUMBER,
  TARGET_USD                 NUMBER(18,2),
  REFRESH_ID                 VARCHAR,
  AS_OF_DATE                 DATE,
  PLANNED_AT                 TIMESTAMP_NTZ,
  CONSTRAINT PK_RR_GAP_PLAN PRIMARY KEY (STEP_ORDER)
) COMMENT = 'Gap-closure bridge: base-scenario categories first, then modeled upside. Money from the ledger; probabilities statistical.';

CREATE TABLE IF NOT EXISTS RR_PREVENTION_PLAN (
  CONTROL_ID           VARCHAR NOT NULL,
  CATEGORY             VARCHAR,
  RISK_CLASS           VARCHAR,
  CONTROL_NAME         VARCHAR,
  RATIONALE            VARCHAR,
  OWNER                VARCHAR,
  ITEMS                NUMBER,
  EST_PREVENTABLE_USD  NUMBER(18,2) COMMENT 'Estimate: this quarter''s exposure caused by the blocker class the control targets',
  STATUS               VARCHAR COMMENT 'PROPOSED | LAUNCHED | RETIRED',
  LAUNCHED_CONTROL_ID  VARCHAR COMMENT 'PREVENTION_CONTROLS.CONTROL_ID once launched',
  LAUNCHED_BY          VARCHAR,
  LAUNCHED_AT          TIMESTAMP_NTZ,
  REVIEW_DATE          DATE,
  AS_OF_DATE           DATE,
  UPDATED_AT           TIMESTAMP_NTZ,
  CONSTRAINT PK_RR_PREV_PLAN PRIMARY KEY (CONTROL_ID)
) COMMENT = 'Prevention planner output: controls against recurring blocker classes. Launch is a human action.';

-- ---------------------------------------------------------------------------
-- SP_RR_TRUST_CHECK
-- ---------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE SP_RR_TRUST_CHECK()
RETURNS VARCHAR
LANGUAGE SQL
COMMENT = 'Trust validation of the governed revenue numbers. Returns JSON with overall_status PASS | WARN | FAIL.'
AS
$$
DECLARE
  trust_run_id VARCHAR DEFAULT ('TR-' || TO_VARCHAR(CURRENT_TIMESTAMP(), 'YYYYMMDDHH24MISSFF3'));
  started_at   TIMESTAMP_NTZ DEFAULT (CURRENT_TIMESTAMP()::TIMESTAMP_NTZ);
  bench_sev    VARCHAR;
  overall      VARCHAR;
  result       VARIANT;
BEGIN
  SELECT IFF(UPPER(TRUST_BENCHMARK_SEVERITY) = 'CRITICAL', 'CRITICAL', 'WARN') INTO :bench_sev
    FROM RR_CONFIG WHERE CONFIG_ID = 1;

  INSERT INTO RR_TRUST_RESULTS (TRUST_RUN_ID, CHECK_NAME, CHECK_GROUP, SEVERITY, STATUS, EXPECTED, ACTUAL, CHECKED_AT)
  WITH c AS (SELECT * FROM RR_CONFIG WHERE CONFIG_ID = 1),
  led AS (SELECT * FROM RR_RISK_LEDGER WHERE ACTIVE_FLAG),
  o AS (SELECT * FROM RR_REVENUE_OUTLOOK),
  cat AS (
    SELECT CATEGORY, SUM(AT_RISK_USD) AS AR, SUM(RECOVERABLE_USD) AS RC FROM led GROUP BY 1
  ),
  catcmp AS (
    SELECT MAX(ABS(d.DIFF)) AS MAX_DIFF FROM (
      SELECT COALESCE((SELECT AR FROM cat WHERE CATEGORY = 'PIPELINE'), 0) - o.PIPELINE_AT_RISK_USD AS DIFF FROM o
      UNION ALL SELECT COALESCE((SELECT RC FROM cat WHERE CATEGORY = 'PIPELINE'), 0) - o.PIPELINE_RECOVERABLE_USD FROM o
      UNION ALL SELECT COALESCE((SELECT AR FROM cat WHERE CATEGORY = 'FULFILLMENT'), 0) - o.FULFILLMENT_AT_RISK_USD FROM o
      UNION ALL SELECT COALESCE((SELECT RC FROM cat WHERE CATEGORY = 'FULFILLMENT'), 0) - o.FULFILLMENT_RECOVERABLE_USD FROM o
      UNION ALL SELECT COALESCE((SELECT AR FROM cat WHERE CATEGORY = 'BILLING'), 0) - o.BILLING_AT_RISK_USD FROM o
      UNION ALL SELECT COALESCE((SELECT RC FROM cat WHERE CATEGORY = 'BILLING'), 0) - o.BILLING_RECOVERABLE_USD FROM o
      UNION ALL SELECT COALESCE((SELECT AR FROM cat WHERE CATEGORY = 'RENEWAL'), 0) - o.RENEWAL_AT_RISK_USD FROM o
      UNION ALL SELECT COALESCE((SELECT RC FROM cat WHERE CATEGORY = 'RENEWAL'), 0) - o.RENEWAL_RECOVERABLE_USD FROM o
      UNION ALL SELECT COALESCE((SELECT AR FROM cat WHERE CATEGORY = 'SUPPORT_EXPANSION'), 0) - o.SUPPORT_EXPANSION_AT_RISK_USD FROM o
      UNION ALL SELECT COALESCE((SELECT RC FROM cat WHERE CATEGORY = 'SUPPORT_EXPANSION'), 0) - o.SUPPORT_EXPANSION_RECOVERABLE_USD FROM o
    ) d
  ),
  bench_actual AS (
    SELECT 'PIPELINE_AT_RISK' AS K, PIPELINE_AT_RISK_USD AS V FROM o
    UNION ALL SELECT 'PIPELINE_RECOVERABLE', PIPELINE_RECOVERABLE_USD FROM o
    UNION ALL SELECT 'FULFILLMENT_AT_RISK', FULFILLMENT_AT_RISK_USD FROM o
    UNION ALL SELECT 'FULFILLMENT_RECOVERABLE', FULFILLMENT_RECOVERABLE_USD FROM o
    UNION ALL SELECT 'BILLING_AT_RISK', BILLING_AT_RISK_USD FROM o
    UNION ALL SELECT 'BILLING_RECOVERABLE', BILLING_RECOVERABLE_USD FROM o
    UNION ALL SELECT 'RENEWAL_AT_RISK', RENEWAL_AT_RISK_USD FROM o
    UNION ALL SELECT 'RENEWAL_RECOVERABLE', RENEWAL_RECOVERABLE_USD FROM o
    UNION ALL SELECT 'SUPPORT_EXPANSION_AT_RISK', SUPPORT_EXPANSION_AT_RISK_USD FROM o
    UNION ALL SELECT 'SUPPORT_EXPANSION_RECOVERABLE', SUPPORT_EXPANSION_RECOVERABLE_USD FROM o
    UNION ALL SELECT 'GROSS_AT_RISK', GROSS_AT_RISK_USD FROM o
    UNION ALL SELECT 'MODELED_RECOVERABLE', MODELED_RECOVERABLE_USD FROM o
    UNION ALL SELECT 'Q4_TARGET', Q4_TARGET_USD FROM o
    UNION ALL SELECT 'Q4_FORECAST', Q4_FORECAST_USD FROM o
    UNION ALL SELECT 'FORECAST_GAP', FORECAST_GAP_USD FROM o
    UNION ALL SELECT 'BASE_RECOVERY', BASE_RECOVERY_USD FROM o
    UNION ALL SELECT 'BASE_REVISED_OUTLOOK', BASE_REVISED_OUTLOOK_USD FROM o
    UNION ALL SELECT 'BASE_REMAINING_GAP', BASE_REMAINING_GAP_USD FROM o
    UNION ALL SELECT 'UPSIDE_RECOVERY', UPSIDE_RECOVERY_USD FROM o
    UNION ALL SELECT 'UPSIDE_OUTLOOK', UPSIDE_OUTLOOK_USD FROM o
    UNION ALL SELECT 'UPSIDE_REMAINING_GAP', UPSIDE_REMAINING_GAP_USD FROM o
  ),
  checks AS (
    -- CONFIGURATION
    SELECT 'CONFIG_LOCK' AS CHECK_NAME, 'CONFIGURATION' AS CHECK_GROUP, 'CRITICAL' AS SEVERITY,
           (c.AS_OF_DATE = '2026-10-15'::DATE AND c.QTR_START = '2026-10-01'::DATE AND c.QTR_END = '2026-12-31'::DATE
            AND c.SUPPORT_MAX_CSAT = 3.2
            AND c.FULFILLMENT_RISK_REASON = 'Priority order blocked by component shortage'
            AND c.AI_MODEL = 'claude-opus-5-5') AS PASSED,
           'locked demo configuration' AS EXPECTED,
           TO_VARCHAR(OBJECT_CONSTRUCT('as_of', c.AS_OF_DATE, 'qtr_start', c.QTR_START, 'qtr_end', c.QTR_END,
                                       'csat', c.SUPPORT_MAX_CSAT, 'fulfillment_reason', c.FULFILLMENT_RISK_REASON,
                                       'ai_model', c.AI_MODEL)) AS ACTUAL
    FROM c
    UNION ALL
    SELECT 'CONFIG_SINGLE_ROW', 'CONFIGURATION', 'CRITICAL', (SELECT COUNT(*) FROM RR_CONFIG) = 1, '1',
           TO_VARCHAR((SELECT COUNT(*) FROM RR_CONFIG))
    UNION ALL
    SELECT 'OUTLOOK_AS_OF_MATCHES_CONFIG', 'CONFIGURATION', 'CRITICAL',
           (SELECT COUNT(*) FROM o) = 1 AND (SELECT MAX(AS_OF_DATE) FROM o) = (SELECT AS_OF_DATE FROM c),
           TO_VARCHAR((SELECT AS_OF_DATE FROM c)), TO_VARCHAR((SELECT MAX(AS_OF_DATE) FROM o))
    -- INTEGRITY
    UNION ALL
    SELECT 'LEDGER_NOT_EMPTY', 'INTEGRITY', 'CRITICAL', (SELECT COUNT(*) FROM led) > 0, '> 0',
           TO_VARCHAR((SELECT COUNT(*) FROM led))
    UNION ALL
    SELECT 'ALL_FIVE_CATEGORIES_PRESENT', 'INTEGRITY', 'CRITICAL', (SELECT COUNT(DISTINCT CATEGORY) FROM led) = 5, '5',
           TO_VARCHAR((SELECT COUNT(DISTINCT CATEGORY) FROM led))
    UNION ALL
    SELECT 'NO_DUPLICATE_RISK_ITEMS', 'INTEGRITY', 'CRITICAL',
           (SELECT COUNT(*) - COUNT(DISTINCT RISK_ITEM_ID) FROM RR_RISK_LEDGER) = 0
           AND (SELECT COUNT(*) FROM (SELECT CATEGORY, SOURCE_ID FROM led GROUP BY 1, 2 HAVING COUNT(*) > 1)) = 0,
           '0', TO_VARCHAR((SELECT COUNT(*) - COUNT(DISTINCT RISK_ITEM_ID) FROM RR_RISK_LEDGER))
    UNION ALL
    SELECT 'NO_NULL_CRITICAL_IDENTIFIERS', 'INTEGRITY', 'CRITICAL',
           (SELECT COUNT_IF(RISK_ITEM_ID IS NULL OR CATEGORY IS NULL OR SOURCE_ID IS NULL OR CUSTOMER_ID IS NULL
                            OR AT_RISK_USD IS NULL OR RECOVERABLE_USD IS NULL) FROM led) = 0,
           '0', TO_VARCHAR((SELECT COUNT_IF(RISK_ITEM_ID IS NULL OR CATEGORY IS NULL OR SOURCE_ID IS NULL OR CUSTOMER_ID IS NULL
                            OR AT_RISK_USD IS NULL OR RECOVERABLE_USD IS NULL) FROM led))
    UNION ALL
    SELECT 'NO_NEGATIVE_FINANCIALS', 'INTEGRITY', 'CRITICAL',
           (SELECT COUNT_IF(AT_RISK_USD < 0 OR RECOVERABLE_USD < 0 OR NO_PATH_USD < 0) FROM led) = 0,
           '0', TO_VARCHAR((SELECT COUNT_IF(AT_RISK_USD < 0 OR RECOVERABLE_USD < 0 OR NO_PATH_USD < 0) FROM led))
    UNION ALL
    SELECT 'RECOVERABLE_LE_AT_RISK', 'INTEGRITY', 'CRITICAL',
           (SELECT COUNT_IF(RECOVERABLE_USD > AT_RISK_USD + 0.01) FROM led) = 0,
           '0', TO_VARCHAR((SELECT COUNT_IF(RECOVERABLE_USD > AT_RISK_USD + 0.01) FROM led))
    UNION ALL
    SELECT 'NO_PATH_IDENTITY', 'INTEGRITY', 'CRITICAL',
           (SELECT COUNT_IF(ABS(NO_PATH_USD - (AT_RISK_USD - RECOVERABLE_USD)) > 0.01) FROM led) = 0,
           '0', TO_VARCHAR((SELECT COUNT_IF(ABS(NO_PATH_USD - (AT_RISK_USD - RECOVERABLE_USD)) > 0.01) FROM led))
    UNION ALL
    SELECT 'RECOVERY_PROB_IN_0_1', 'INTEGRITY', 'CRITICAL',
           (SELECT COUNT_IF(RECOVERY_PROB < 0 OR RECOVERY_PROB > 1) FROM led) = 0,
           '0', TO_VARCHAR((SELECT COUNT_IF(RECOVERY_PROB < 0 OR RECOVERY_PROB > 1) FROM led))
    -- RECONCILIATION
    UNION ALL
    SELECT 'RISK_TOTAL_RECONCILES', 'RECONCILIATION', 'CRITICAL',
           ABS(COALESCE((SELECT SUM(AT_RISK_USD) FROM led), 0) - COALESCE((SELECT GROSS_AT_RISK_USD FROM o), -1)) < 1,
           TO_VARCHAR((SELECT GROSS_AT_RISK_USD FROM o)), TO_VARCHAR((SELECT SUM(AT_RISK_USD) FROM led))
    UNION ALL
    SELECT 'RECOVERABLE_TOTAL_RECONCILES', 'RECONCILIATION', 'CRITICAL',
           ABS(COALESCE((SELECT SUM(RECOVERABLE_USD) FROM led), 0) - COALESCE((SELECT MODELED_RECOVERABLE_USD FROM o), -1)) < 1,
           TO_VARCHAR((SELECT MODELED_RECOVERABLE_USD FROM o)), TO_VARCHAR((SELECT SUM(RECOVERABLE_USD) FROM led))
    UNION ALL
    SELECT 'CATEGORY_RECONCILIATION', 'RECONCILIATION', 'CRITICAL',
           COALESCE((SELECT MAX_DIFF FROM catcmp), 999) < 1, 'max |diff| < 1 USD',
           TO_VARCHAR((SELECT MAX_DIFF FROM catcmp))
    UNION ALL
    SELECT 'SCENARIO_ARITHMETIC', 'RECONCILIATION', 'CRITICAL',
           (SELECT ABS(FORECAST_GAP_USD - (Q4_TARGET_USD - Q4_FORECAST_USD)) < 1
               AND ABS(BASE_REVISED_OUTLOOK_USD - (Q4_FORECAST_USD + BASE_RECOVERY_USD)) < 1
               AND ABS(BASE_REMAINING_GAP_USD - (Q4_TARGET_USD - BASE_REVISED_OUTLOOK_USD)) < 1
               AND ABS(UPSIDE_RECOVERY_USD - MODELED_RECOVERABLE_USD) < 1
               AND ABS(UPSIDE_OUTLOOK_USD - (Q4_FORECAST_USD + UPSIDE_RECOVERY_USD)) < 1
               AND ABS(UPSIDE_REMAINING_GAP_USD - (Q4_TARGET_USD - UPSIDE_OUTLOOK_USD)) < 1 FROM o),
           'gap / base / upside identities hold', 'see RR_REVENUE_OUTLOOK'
    UNION ALL
    SELECT 'GROSS_RISK_DISTINCT_FROM_GAP', 'RECONCILIATION', 'CRITICAL',
           (SELECT GROSS_AT_RISK_USD IS NOT NULL AND FORECAST_GAP_USD IS NOT NULL
                   AND ACCOUNTING_NOTE ILIKE '%NOT the forecast gap%' FROM o),
           'gross risk and forecast gap computed and labelled separately',
           TO_VARCHAR((SELECT OBJECT_CONSTRUCT('gross_at_risk', GROSS_AT_RISK_USD, 'forecast_gap', FORECAST_GAP_USD) FROM o))
    -- LINEAGE
    UNION ALL
    SELECT 'SOURCE_LINEAGE_PRESENT', 'LINEAGE', 'CRITICAL',
           (SELECT COUNT_IF(SOURCE_QUERY_ID IS NULL OR CALCULATION_RULE IS NULL OR SOURCE_TABLE IS NULL) FROM led) = 0,
           '0 rows without query id / rule', TO_VARCHAR((SELECT COUNT_IF(SOURCE_QUERY_ID IS NULL OR CALCULATION_RULE IS NULL OR SOURCE_TABLE IS NULL) FROM led))
    UNION ALL
    SELECT 'SOURCE_RECORDS_EXIST', 'LINEAGE', 'CRITICAL',
           (SELECT COUNT(*) FROM led l
              LEFT JOIN FACT_OPPORTUNITY fo ON l.CATEGORY = 'PIPELINE' AND fo.OPPORTUNITY_ID = l.SOURCE_ID
              LEFT JOIN FACT_ORDER ord     ON l.CATEGORY = 'FULFILLMENT' AND ord.ORDER_ID = l.SOURCE_ID
              LEFT JOIN FACT_BILLING fb    ON l.CATEGORY = 'BILLING' AND fb.BILLING_ID = l.SOURCE_ID
              LEFT JOIN DIM_CUSTOMER dc    ON l.CATEGORY IN ('RENEWAL', 'SUPPORT_EXPANSION') AND dc.CUSTOMER_ID = l.SOURCE_ID
             WHERE COALESCE(fo.OPPORTUNITY_ID, ord.ORDER_ID, fb.BILLING_ID, dc.CUSTOMER_ID) IS NULL) = 0,
           '0 orphan risk items', 'see ledger'
    UNION ALL
    SELECT 'AI_DID_NOT_ALTER_MONEY', 'LINEAGE', 'CRITICAL',
           (SELECT COUNT_IF(ROW_HASH IS DISTINCT FROM RR_LEDGER_ROW_HASH(CATEGORY, SOURCE_ID, CUSTOMER_ID, PRODUCT_ID,
                     AT_RISK_USD, RECOVERABLE_USD, RECOVERY_PROB, DUE_DATE, BLOCKER, RECOVERY_PATH, EVIDENCE_TEXT)) FROM led) = 0,
           '0 rows whose governed hash changed after refresh',
           TO_VARCHAR((SELECT COUNT_IF(ROW_HASH IS DISTINCT FROM RR_LEDGER_ROW_HASH(CATEGORY, SOURCE_ID, CUSTOMER_ID, PRODUCT_ID,
                     AT_RISK_USD, RECOVERABLE_USD, RECOVERY_PROB, DUE_DATE, BLOCKER, RECOVERY_PATH, EVIDENCE_TEXT)) FROM led))
    UNION ALL
    SELECT 'ML_DID_NOT_OVERWRITE_GOVERNED_PROB', 'LINEAGE', 'CRITICAL',
           (SELECT COUNT(*) FROM led l JOIN FACT_OPPORTUNITY fo ON l.CATEGORY = 'PIPELINE' AND fo.OPPORTUNITY_ID = l.SOURCE_ID
             WHERE ABS(COALESCE(l.RECOVERY_PROB, 0)
                       - COALESCE(LEAST(GREATEST(IFF(fo.RECOVERY_PROBABILITY > 1, fo.RECOVERY_PROBABILITY / 100, fo.RECOVERY_PROBABILITY), 0), 1), 0)) > 0.0001) = 0,
           'ledger RECOVERY_PROB = source RECOVERY_PROBABILITY', 'see ledger'
    -- ACTIONS / HUMAN CONTROL
    UNION ALL
    SELECT 'ACTIONS_LE_RECOVERABLE', 'ACTIONS', 'CRITICAL',
           (SELECT COUNT(*) FROM (
              SELECT a.RISK_ITEM_ID, SUM(a.EXPECTED_RECOVERY_USD) AS E, MAX(l.RECOVERABLE_USD) AS R
              FROM RR_RECOVERY_ACTIONS a JOIN RR_RISK_LEDGER l ON l.RISK_ITEM_ID = a.RISK_ITEM_ID
              WHERE a.STATUS IN ('PROPOSED', 'APPROVED', 'IN_PROGRESS', 'DONE') AND l.ACTIVE_FLAG
              GROUP BY 1 HAVING SUM(a.EXPECTED_RECOVERY_USD) > MAX(l.RECOVERABLE_USD) + 0.01)) = 0,
           '0 risk items with open action value above recoverable', 'see RR_RECOVERY_ACTIONS'
    UNION ALL
    SELECT 'DECISIONS_ARE_HUMAN_ATTRIBUTED', 'ACTIONS', 'CRITICAL',
           (SELECT COUNT_IF(STATUS IN ('APPROVED', 'IN_PROGRESS', 'DONE', 'REJECTED') AND (DECISION_BY IS NULL OR DECISION_TIME IS NULL))
              FROM RR_RECOVERY_ACTIONS) = 0,
           '0 unattributed decisions', 'see RR_RECOVERY_ACTIONS'
    UNION ALL
    SELECT 'NO_OPEN_ACTIONS_ON_RESOLVED_ITEMS', 'ACTIONS', 'WARN',
           (SELECT COUNT(*) FROM RR_RECOVERY_ACTIONS a JOIN RR_RISK_LEDGER l ON l.RISK_ITEM_ID = a.RISK_ITEM_ID
             WHERE a.STATUS = 'PROPOSED' AND NOT l.ACTIVE_FLAG) = 0,
           '0', 'see RR_RECOVERY_ACTIONS'
    UNION ALL
    SELECT 'GAP_PLAN_RECONCILES', 'RECONCILIATION', 'CRITICAL',
           (SELECT COUNT(*) FROM RR_GAP_PLAN) > 1
           AND ABS(COALESCE((SELECT MAX_BY(CUMULATIVE_FORECAST_USD, STEP_ORDER) FROM RR_GAP_PLAN), 0) - COALESCE((SELECT UPSIDE_OUTLOOK_USD FROM o), -1)) < 1
           AND ABS(COALESCE((SELECT SUM(EXPECTED_USD) FROM RR_GAP_PLAN WHERE IN_BASE_SCENARIO), 0) - COALESCE((SELECT BASE_RECOVERY_USD FROM o), -1)) < 1
           AND (SELECT MAX(REFRESH_ID) FROM RR_GAP_PLAN) = (SELECT REFRESH_ID FROM o),
           'gap plan ends at the upside outlook; base steps = base recovery; same refresh',
           TO_VARCHAR((SELECT MAX_BY(CUMULATIVE_FORECAST_USD, STEP_ORDER) FROM RR_GAP_PLAN))
    -- FRESHNESS
    UNION ALL
    SELECT 'LEDGER_FRESHNESS', 'FRESHNESS', 'WARN',
           DATEDIFF(hour, (SELECT MAX(REFRESHED_AT) FROM led), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ) <= (SELECT TRUST_FRESHNESS_HOURS FROM c),
           '<= ' || TO_VARCHAR((SELECT TRUST_FRESHNESS_HOURS FROM c)) || ' hours',
           TO_VARCHAR((SELECT MAX(REFRESHED_AT) FROM led))
    UNION ALL
    SELECT 'OUTLOOK_REFRESH_MATCHES_LEDGER', 'FRESHNESS', 'CRITICAL',
           (SELECT REFRESH_ID FROM o) = (SELECT MAX(REFRESH_ID) FROM led),
           TO_VARCHAR((SELECT MAX(REFRESH_ID) FROM led)), TO_VARCHAR((SELECT REFRESH_ID FROM o))
    -- BENCHMARKS (acceptance fixture; severity from RR_CONFIG.TRUST_BENCHMARK_SEVERITY)
    UNION ALL
    SELECT 'BENCHMARK_' || b.METRIC_KEY, 'BENCHMARK', :bench_sev,
           ROUND(a.V / 1000000, 1) = b.EXPECTED_USD_M,
           TO_VARCHAR(b.EXPECTED_USD_M) || 'M', COALESCE(TO_VARCHAR(ROUND(a.V / 1000000, 1)), 'NULL') || 'M'
    FROM RR_ACCEPTANCE_BENCHMARKS b LEFT JOIN bench_actual a ON a.K = b.METRIC_KEY
  )
  SELECT :trust_run_id, CHECK_NAME, CHECK_GROUP, SEVERITY, IFF(COALESCE(PASSED, FALSE), 'PASS', 'FAIL'),
         EXPECTED, ACTUAL, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
  FROM checks;

  SELECT CASE WHEN COUNT_IF(STATUS = 'FAIL' AND SEVERITY = 'CRITICAL') > 0 THEN 'FAIL'
              WHEN COUNT_IF(STATUS = 'FAIL') > 0 THEN 'WARN' ELSE 'PASS' END,
         OBJECT_CONSTRUCT(
           'trust_run_id', :trust_run_id,
           'overall_status', CASE WHEN COUNT_IF(STATUS = 'FAIL' AND SEVERITY = 'CRITICAL') > 0 THEN 'FAIL'
                                  WHEN COUNT_IF(STATUS = 'FAIL') > 0 THEN 'WARN' ELSE 'PASS' END,
           'checks_run', COUNT(*),
           'checks_passed', COUNT_IF(STATUS = 'PASS'),
           'failed_checks', ARRAY_AGG(IFF(STATUS = 'FAIL',
                               OBJECT_CONSTRUCT('check', CHECK_NAME, 'severity', SEVERITY, 'expected', EXPECTED, 'actual', ACTUAL),
                               NULL)),
           'as_of_date', (SELECT AS_OF_DATE FROM RR_CONFIG WHERE CONFIG_ID = 1),
           'ledger_refreshed_at', (SELECT MAX(REFRESHED_AT) FROM RR_RISK_LEDGER WHERE ACTIVE_FLAG),
           'guidance', 'If overall_status = FAIL, do not present financial recommendations; report the failed checks.')
    INTO :overall, :result
    FROM RR_TRUST_RESULTS WHERE TRUST_RUN_ID = :trust_run_id;

  INSERT INTO RR_REFRESH_AUDIT (RUN_ID, STAGE, STATUS, STARTED_AT, ENDED_AT, AS_OF_DATE, ROWS_AFFECTED, DETAILS, RUN_BY)
  SELECT :trust_run_id, 'TRUST', :overall, :started_at, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ,
         (SELECT AS_OF_DATE FROM RR_CONFIG WHERE CONFIG_ID = 1),
         (SELECT COUNT(*) FROM RR_TRUST_RESULTS WHERE TRUST_RUN_ID = :trust_run_id), :result, CURRENT_USER();

  RETURN TO_JSON(result);
END;
$$;


-- ---------------------------------------------------------------------------
-- SP_PLAN_GAP_CLOSURE — gap-closure planner (decision procedure, Python)
--   Step 0 = current forecast. Then governed base-scenario categories (largest
--   recoverable first), then modeled categories (needs approval / estimate).
--   Money = sums of ledger RECOVERABLE_USD. PROB_CLOSE_GAP_CUMULATIVE is a seeded
--   Monte Carlo (each item recovers its at-risk value with its governed probability).
-- ---------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE SP_PLAN_GAP_CLOSURE(P_ITERATIONS NUMBER)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.11'
PACKAGES = ('snowflake-snowpark-python', 'numpy')
HANDLER = 'run'
COMMENT = 'Gap-closure bridge from current forecast to target by category, with Monte Carlo probability of closing the gap per step.'
AS
$$
from datetime import datetime
import numpy as np
from snowflake.snowpark.types import (StructType, StructField, StringType, DoubleType, DateType,
                                      BooleanType, TimestampType, LongType)

LABELS = {"PIPELINE": "Unblock late-stage pipeline", "FULFILLMENT": "Transfer alternate inventory",
          "BILLING": "Clear billing exceptions", "RENEWAL": "Save at-risk renewals (ARR)",
          "SUPPORT_EXPANSION": "Rescue expansions via support"}

def run(session, p_iterations):
    n = max(1000, min(int(p_iterations or 10000), 50000))
    o = session.sql("SELECT Q4_TARGET_USD, Q4_FORECAST_USD, FORECAST_GAP_USD, BASE_RECOVERY_CATEGORIES, "
                    "REFRESH_ID, AS_OF_DATE FROM RR_REVENUE_OUTLOOK").collect()[0]
    target, forecast, gap = float(o[0]), float(o[1]), float(o[2])
    base = [c.strip() for c in (o[3] or "").split(",") if c.strip()]
    by = {}
    for r in session.sql("SELECT CATEGORY, AT_RISK_USD, RECOVERY_PROB, RECOVERABLE_USD "
                         "FROM RR_RISK_LEDGER WHERE ACTIVE_FLAG").collect():
        by.setdefault(r[0], []).append((float(r[1] or 0), float(r[2] or 0), float(r[3] or 0)))
    rec = {c: sum(x[2] for x in v) for c, v in by.items()}
    order = (sorted([c for c in by if c in base], key=lambda c: -rec[c])
             + sorted([c for c in by if c not in base], key=lambda c: -rec[c]))

    rng = np.random.default_rng(42)
    now = datetime.utcnow()
    total = np.zeros(n)
    cum = forecast
    rows = [(0, None, "Current forecast", 0.0, round(forecast, 2), round(target - forecast, 2),
             False, False, 0.0, 0, round(target, 2), o[4], o[5], now)]
    for i, c in enumerate(order, 1):
        v = np.array([x[0] for x in by[c]])
        p = np.clip(np.array([x[1] for x in by[c]]), 0, 1)
        chunk = max(1, min(n, 2_000_000 // max(1, len(v))))
        for s0 in range(0, n, chunk):
            k = min(chunk, n - s0)
            total[s0:s0 + k] += (rng.random((k, len(v))) < p).astype(float) @ v
        cum += rec[c]
        rows.append((i, c, LABELS.get(c, c), round(rec[c], 2), round(cum, 2), round(target - cum, 2),
                     c in base, c not in base, round(float((total >= gap).mean()), 4), len(v),
                     round(target, 2), o[4], o[5], now))

    schema = StructType([
        StructField("STEP_ORDER", LongType()), StructField("CATEGORY", StringType()),
        StructField("STEP_LABEL", StringType()), StructField("EXPECTED_USD", DoubleType()),
        StructField("CUMULATIVE_FORECAST_USD", DoubleType()), StructField("REMAINING_GAP_USD", DoubleType()),
        StructField("IN_BASE_SCENARIO", BooleanType()), StructField("NEEDS_APPROVAL", BooleanType()),
        StructField("PROB_CLOSE_GAP_CUMULATIVE", DoubleType()), StructField("ITEMS", LongType()),
        StructField("TARGET_USD", DoubleType()), StructField("REFRESH_ID", StringType()),
        StructField("AS_OF_DATE", DateType()), StructField("PLANNED_AT", TimestampType())])
    session.sql("TRUNCATE TABLE RR_GAP_PLAN").collect()
    session.create_dataframe(rows, schema=schema).write.mode("append").save_as_table(
        "RR_GAP_PLAN", column_order="name")
    return {"steps": len(rows), "iterations": n, "order": order,
            "final_cumulative_usd": round(cum, 2), "base_categories": base}
$$;

-- ---------------------------------------------------------------------------
-- SP_PLAN_PREVENTION_CONTROLS — prevention planner (deterministic)
--   Top-2 recurring blocker classes per category (AI_CLASSIFY class, else blocker)
--   -> one proposed control each. Launched controls are never overwritten.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE SP_PLAN_PREVENTION_CONTROLS()
RETURNS VARIANT
LANGUAGE SQL
COMMENT = 'Proposes prevention controls for the recurring blocker classes behind this quarter''s revenue risk.'
AS
$$
DECLARE
  merged   NUMBER DEFAULT 0;
  retired  NUMBER DEFAULT 0;
  proposed NUMBER DEFAULT 0;
BEGIN
  CREATE OR REPLACE TEMPORARY TABLE RR_TMP_PREV AS
  WITH cls AS (
    SELECT CATEGORY, COALESCE(NULLIF(TRIM(AI_RISK_CLASS), ''), NULLIF(TRIM(BLOCKER), ''), 'Other') AS RISK_CLASS,
           COUNT(*) AS ITEMS, SUM(AT_RISK_USD) AS AR
    FROM RR_RISK_LEDGER WHERE ACTIVE_FLAG
    GROUP BY 1, 2
    QUALIFY ROW_NUMBER() OVER (PARTITION BY CATEGORY ORDER BY SUM(AT_RISK_USD) DESC, RISK_CLASS) <= 2
  )
  SELECT 'PC-' || LEFT(CATEGORY, 3) || '-' || LEFT(SHA2(CATEGORY || '|' || RISK_CLASS, 256), 8) AS CONTROL_ID,
         CATEGORY, RISK_CLASS, ITEMS, AR,
         CASE CATEGORY
           WHEN 'PIPELINE'    THEN 'Deal-desk stage gate 30 days before close for deals blocked by: ' || RISK_CLASS
           WHEN 'FULFILLMENT' THEN 'Weekly component-shortage review with automatic alternate-warehouse sourcing (' || RISK_CLASS || ')'
           WHEN 'BILLING'     THEN 'Pre-invoice validation rule to stop: ' || RISK_CLASS
           WHEN 'RENEWAL'     THEN 'Health-triggered save play 120 days before renewal (' || RISK_CLASS || ')'
           ELSE 'Escalation SLA: no expansion proposal while P1/P2 tickets are open (' || RISK_CLASS || ')' END AS CONTROL_NAME,
         CASE CATEGORY
           WHEN 'PIPELINE' THEN 'Deal Desk Lead' WHEN 'FULFILLMENT' THEN 'Supply Chain Director'
           WHEN 'BILLING' THEN 'Billing Operations Manager' WHEN 'RENEWAL' THEN 'Customer Success Director'
           ELSE 'Support Director' END AS OWNER,
         'Recurring blocker this quarter: ' || RISK_CLASS || ' (' || ITEMS || ' risk items in ' || CATEGORY
           || '). The control targets the root cause before next quarter.' AS RATIONALE,
         (SELECT AS_OF_DATE FROM RR_CONFIG WHERE CONFIG_ID = 1) AS AS_OF_DATE
  FROM cls;

  MERGE INTO RR_PREVENTION_PLAN t
  USING RR_TMP_PREV s
     ON t.CONTROL_ID = s.CONTROL_ID
  WHEN MATCHED THEN UPDATE SET
    t.ITEMS = s.ITEMS, t.EST_PREVENTABLE_USD = s.AR, t.RATIONALE = s.RATIONALE,
    t.CONTROL_NAME = IFF(t.STATUS = 'LAUNCHED', t.CONTROL_NAME, s.CONTROL_NAME),
    t.OWNER = IFF(t.STATUS = 'LAUNCHED', t.OWNER, s.OWNER),
    t.STATUS = IFF(t.STATUS = 'RETIRED', 'PROPOSED', t.STATUS),
    t.AS_OF_DATE = s.AS_OF_DATE,
    t.UPDATED_AT = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
  WHEN NOT MATCHED THEN INSERT (CONTROL_ID, CATEGORY, RISK_CLASS, CONTROL_NAME, RATIONALE, OWNER, ITEMS,
    EST_PREVENTABLE_USD, STATUS, AS_OF_DATE, UPDATED_AT)
  VALUES (s.CONTROL_ID, s.CATEGORY, s.RISK_CLASS, s.CONTROL_NAME, s.RATIONALE, s.OWNER, s.ITEMS, s.AR, 'PROPOSED',
          s.AS_OF_DATE, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ);
  merged := SQLROWCOUNT;

  UPDATE RR_PREVENTION_PLAN SET STATUS = 'RETIRED', UPDATED_AT = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
   WHERE STATUS = 'PROPOSED' AND CONTROL_ID NOT IN (SELECT CONTROL_ID FROM RR_TMP_PREV);
  retired := SQLROWCOUNT;

  SELECT COUNT(*) INTO :proposed FROM RR_PREVENTION_PLAN WHERE STATUS = 'PROPOSED';
  RETURN OBJECT_CONSTRUCT('controls_upserted', merged, 'controls_retired', retired, 'proposed_now', proposed);
END;
$$;

-- ---------------------------------------------------------------------------
-- SP_PROPOSE_TOP_RECOVERY_ACTIONS — recommendations only (status PROPOSED)
--   Priority score = RECOVERABLE_USD x (1 + urgency), urgency rises linearly
--   from 0 (>= 45 days to due) to 0.5 (due now / overdue). Deterministic.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE SP_PROPOSE_TOP_RECOVERY_ACTIONS(P_TOP_N NUMBER)
RETURNS VARIANT
LANGUAGE SQL
COMMENT = 'Proposes the highest-value recovery actions (PROPOSED only). Refuses to propose when trust check FAILS.'
AS
$$
DECLARE
  run_id       VARCHAR DEFAULT ('PA-' || TO_VARCHAR(CURRENT_TIMESTAMP(), 'YYYYMMDDHH24MISSFF3'));
  started_at   TIMESTAMP_NTZ DEFAULT (CURRENT_TIMESTAMP()::TIMESTAMP_NTZ);
  trust_json   VARCHAR;
  trust_status VARCHAR;
  gap_plan     VARIANT;
  prev_plan    VARIANT;
  superseded   NUMBER DEFAULT 0;
  inserted     NUMBER DEFAULT 0;
  summary      VARIANT;
BEGIN
  CALL SP_ASSERT_CONFIG_LOCKED();
  -- Decision planners first (deterministic money from the ledger), then trust, then proposals
  CALL SP_PLAN_GAP_CLOSURE(10000) INTO :gap_plan;
  CALL SP_PLAN_PREVENTION_CONTROLS() INTO :prev_plan;
  CALL SP_RR_TRUST_CHECK() INTO :trust_json;
  trust_status := PARSE_JSON(trust_json):overall_status::VARCHAR;

  IF (trust_status = 'FAIL') THEN
    summary := OBJECT_CONSTRUCT('run_id', run_id, 'status', 'SKIPPED_TRUST_FAIL', 'trust', PARSE_JSON(trust_json));
    INSERT INTO RR_REFRESH_AUDIT (RUN_ID, STAGE, STATUS, STARTED_AT, ENDED_AT, AS_OF_DATE, ROWS_AFFECTED, DETAILS, RUN_BY)
    SELECT :run_id, 'PROPOSE_ACTIONS', 'SKIPPED', :started_at, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ,
           (SELECT AS_OF_DATE FROM RR_CONFIG WHERE CONFIG_ID = 1), 0, :summary, CURRENT_USER();
    RETURN summary;
  END IF;

  -- Supersede stale proposals (risk resolved, governed evidence or AI recommendation changed)
  UPDATE RR_RECOVERY_ACTIONS a
     SET STATUS = 'SUPERSEDED',
         NOTES = COALESCE(a.NOTES || ' | ', '') || 'Superseded by ' || :run_id || ': risk item resolved or its evidence changed.',
         UPDATED_AT = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
    FROM RR_RISK_LEDGER l
   WHERE a.RISK_ITEM_ID = l.RISK_ITEM_ID
     AND a.STATUS = 'PROPOSED'
     AND (NOT l.ACTIVE_FLAG
          OR a.SOURCE_ROW_HASH IS DISTINCT FROM l.ROW_HASH
          OR a.SOURCE_AI_HASH IS DISTINCT FROM l.AI_ENRICHED_HASH);
  superseded := SQLROWCOUNT;

  INSERT INTO RR_RECOVERY_ACTIONS (ACTION_ID, RISK_ITEM_ID, CATEGORY, CUSTOMER_ID, CUSTOMER_NAME, ACTION_TEXT,
    OWNER_ROLE, FIRST_STEP, DUE_DATE, EXPECTED_RECOVERY_USD, PRIORITY_RANK, PRIORITY_SCORE, STATUS, ACTION_SOURCE,
    PROPOSED_BY, PROPOSED_AT, SOURCE_ROW_HASH, SOURCE_AI_HASH, REFRESH_ID, AS_OF_DATE, UPDATED_AT)
  WITH c AS (SELECT * FROM RR_CONFIG WHERE CONFIG_ID = 1),
  cand AS (
    SELECT l.*,
           ROUND(l.RECOVERABLE_USD * (1 + LEAST(GREATEST(45 - COALESCE(l.DAYS_TO_DUE, 45), 0), 45) / 90), 2) AS PRIORITY_SCORE
    FROM RR_RISK_LEDGER l
    WHERE l.ACTIVE_FLAG AND l.RECOVERABLE_USD > 0
    QUALIFY ROW_NUMBER() OVER (ORDER BY PRIORITY_SCORE DESC, l.RISK_ITEM_ID) <= :P_TOP_N
  )
  SELECT 'ACT-' || TO_VARCHAR(CURRENT_TIMESTAMP(), 'YYYYMMDDHH24MISS') || '-' || x.RISK_ITEM_ID,
         x.RISK_ITEM_ID, x.CATEGORY, x.CUSTOMER_ID, x.CUSTOMER_NAME,
         COALESCE(x.AI_NEXT_BEST_ACTION, CASE x.CATEGORY
           WHEN 'PIPELINE'          THEN 'Run an executive-sponsored deal-desk review to clear the blocker: ' || COALESCE(x.BLOCKER, 'n/a')
           WHEN 'FULFILLMENT'       THEN COALESCE(x.RECOVERY_PATH, 'Expedite component supply') || ' and expedite shipment before quarter-end'
           WHEN 'BILLING'           THEN COALESCE(x.RECOVERY_PATH, 'Resolve billing exception') || ' before quarter-end close'
           WHEN 'RENEWAL'           THEN 'Launch a renewal save plan addressing: ' || COALESCE(x.BLOCKER, 'customer health decline')
           ELSE 'Resolve open P1/P2 escalations and restore CSAT before the expansion decision' END),
         COALESCE(x.AI_OWNER_ROLE, CASE x.CATEGORY
           WHEN 'PIPELINE' THEN 'Regional Sales VP' WHEN 'FULFILLMENT' THEN 'Supply Chain Director'
           WHEN 'BILLING' THEN 'Billing Operations Manager' WHEN 'RENEWAL' THEN 'Customer Success Director'
           ELSE 'Support Director' END),
         COALESCE(x.AI_FIRST_STEP, CASE x.CATEGORY
           WHEN 'PIPELINE' THEN 'Schedule a blocker-resolution call with the customer decision maker this week'
           WHEN 'FULFILLMENT' THEN 'Raise the inter-warehouse transfer order and confirm carrier capacity'
           WHEN 'BILLING' THEN 'Correct the master data / PO reference and re-issue the invoice'
           WHEN 'RENEWAL' THEN 'Book an executive business review with the account sponsor'
           ELSE 'Assign a named escalation manager to every open P1/P2 ticket' END),
         IFF(COALESCE(x.DAYS_TO_DUE, 0) < 0, DATEADD(day, 7, c.AS_OF_DATE), LEAST(COALESCE(x.DUE_DATE, c.QTR_END), c.QTR_END)),
         x.RECOVERABLE_USD,
         NULL,
         x.PRIORITY_SCORE,
         'PROPOSED',
         IFF(x.AI_NEXT_BEST_ACTION IS NOT NULL, 'AI_RECOMMENDED', 'RULE_TEMPLATE'),
         CURRENT_USER(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ,
         x.ROW_HASH, x.AI_ENRICHED_HASH, x.REFRESH_ID, c.AS_OF_DATE, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
  FROM cand x
  CROSS JOIN c
  WHERE NOT EXISTS (SELECT 1 FROM RR_RECOVERY_ACTIONS a
                     WHERE a.RISK_ITEM_ID = x.RISK_ITEM_ID AND a.STATUS IN ('PROPOSED', 'APPROVED', 'IN_PROGRESS', 'DONE'));
  inserted := SQLROWCOUNT;

  -- Re-rank all open actions
  UPDATE RR_RECOVERY_ACTIONS t
     SET PRIORITY_RANK = r.RNK
    FROM (SELECT ACTION_ID, ROW_NUMBER() OVER (ORDER BY PRIORITY_SCORE DESC, ACTION_ID) AS RNK
            FROM RR_RECOVERY_ACTIONS WHERE STATUS IN ('PROPOSED', 'APPROVED', 'IN_PROGRESS')) r
   WHERE t.ACTION_ID = r.ACTION_ID;
  UPDATE RR_RECOVERY_ACTIONS SET PRIORITY_RANK = NULL WHERE STATUS IN ('REJECTED', 'SUPERSEDED', 'DONE');

  summary := OBJECT_CONSTRUCT('run_id', run_id, 'status', 'SUCCESS', 'trust_status', trust_status,
                              'superseded', superseded, 'proposed', inserted, 'top_n', P_TOP_N,
                              'gap_plan', gap_plan, 'prevention_plan', prev_plan);
  INSERT INTO RR_REFRESH_AUDIT (RUN_ID, STAGE, STATUS, STARTED_AT, ENDED_AT, AS_OF_DATE, ROWS_AFFECTED, DETAILS, RUN_BY)
  SELECT :run_id, 'PROPOSE_ACTIONS', 'SUCCESS', :started_at, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ,
         (SELECT AS_OF_DATE FROM RR_CONFIG WHERE CONFIG_ID = 1), :inserted, :summary, CURRENT_USER();
  RETURN summary;
END;
$$;

-- ---------------------------------------------------------------------------
-- Mirror a human decision into the pre-existing Command Center table
-- ---------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE SP_RR_MIRROR_DECISION(P_ACTION_ID VARCHAR)
RETURNS VARCHAR
LANGUAGE SQL
COMMENT = 'Upserts a human-decided RR action into RECOVERY_ACTIONS (Command Center) when enabled in RR_CONFIG.'
AS
$$
DECLARE
  mirror BOOLEAN;
BEGIN
  SELECT COALESCE(MIRROR_TO_RECOVERY_ACTIONS, FALSE) INTO :mirror FROM RR_CONFIG WHERE CONFIG_ID = 1;
  IF (NOT mirror) THEN RETURN 'MIRROR_DISABLED'; END IF;

  MERGE INTO RECOVERY_ACTIONS t
  USING (
    SELECT a.ACTION_ID, 'RR_REVENUE_RECOVERY_AGENT' AS SOURCE,
           CASE a.CATEGORY WHEN 'PIPELINE' THEN 'DEAL_ACCELERATION' WHEN 'FULFILLMENT' THEN 'INVENTORY_TRANSFER'
                           WHEN 'BILLING' THEN 'BILLING_FIX' WHEN 'RENEWAL' THEN 'RENEWAL_SAVE'
                           ELSE 'SUPPORT_RECOVERY' END AS LEVER_TYPE,
           a.CATEGORY, a.RISK_ITEM_ID, a.CUSTOMER_NAME, a.ACTION_TEXT AS TITLE, a.OWNER_ROLE AS OWNER_TEAM,
           a.FIRST_STEP, a.EXPECTED_RECOVERY_USD::FLOAT AS EXPECTED_RECOVERY_USD,
           IFF(p.MARGIN_PCT IS NULL, NULL, (a.EXPECTED_RECOVERY_USD * p.MARGIN_PCT)::FLOAT) AS GROSS_MARGIN_USD,
           a.PRIORITY_RANK, a.DUE_DATE, a.STATUS, a.DECISION_BY, a.DECISION_TIME, a.NOTES
    FROM RR_RECOVERY_ACTIONS a
    LEFT JOIN RR_RISK_LEDGER l ON l.RISK_ITEM_ID = a.RISK_ITEM_ID
    LEFT JOIN DIM_PRODUCT p ON p.PRODUCT_ID = l.PRODUCT_ID
    WHERE a.ACTION_ID = :P_ACTION_ID AND a.STATUS IN ('APPROVED', 'IN_PROGRESS', 'DONE', 'REJECTED')
  ) s
  ON t.ACTION_ID = s.ACTION_ID
  WHEN MATCHED THEN UPDATE SET
    t.STATUS = s.STATUS, t.DECIDED_BY = s.DECISION_BY, t.DECIDED_AT = s.DECISION_TIME,
    t.NOTE = s.NOTES, t.UPDATED_AT = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
  WHEN NOT MATCHED THEN INSERT (ACTION_ID, SOURCE, LEVER_TYPE, CATEGORY, RISK_ITEM_ID, CUSTOMER_NAME, TITLE, OWNER_TEAM,
    FIRST_STEP, EXPECTED_RECOVERY_USD, GROSS_MARGIN_USD, PRIORITY_RANK, DUE_DATE, STATUS, DECIDED_BY, DECIDED_AT, NOTE, UPDATED_AT)
  VALUES (s.ACTION_ID, s.SOURCE, s.LEVER_TYPE, s.CATEGORY, s.RISK_ITEM_ID, s.CUSTOMER_NAME, s.TITLE, s.OWNER_TEAM,
    s.FIRST_STEP, s.EXPECTED_RECOVERY_USD, s.GROSS_MARGIN_USD, s.PRIORITY_RANK, s.DUE_DATE, s.STATUS, s.DECISION_BY,
    s.DECISION_TIME, s.NOTES, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ);
  RETURN 'MIRRORED';
END;
$$;

-- ---------------------------------------------------------------------------
-- Human decisions (caller's rights: DECISION_BY is the real human user)
-- ---------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE SP_APPROVE_RECOVERY_ACTION(P_ACTION_ID VARCHAR, P_NOTES VARCHAR)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
COMMENT = 'HUMAN approval of a PROPOSED recovery action. Requires an approver role. Never exposed to the agent.'
AS
$$
DECLARE
  roles       VARCHAR;
  authorized  NUMBER;
  found       NUMBER;
  st          VARCHAR;
  exp_usd     NUMBER(18,2);
  rec_usd     NUMBER(18,2);
  is_active   BOOLEAN;
  mirror_res  VARCHAR;
  not_authorized EXCEPTION (-20301, 'Not authorized: caller holds none of RR_CONFIG.APPROVER_ROLES.');
  not_found      EXCEPTION (-20302, 'Recovery action not found.');
  bad_state      EXCEPTION (-20303, 'Only PROPOSED actions can be approved.');
  over_limit     EXCEPTION (-20304, 'Refused: risk item inactive or expected recovery exceeds governed recoverable value.');
BEGIN
  SELECT APPROVER_ROLES INTO :roles FROM RR_CONFIG WHERE CONFIG_ID = 1;
  SELECT COUNT(*) INTO :authorized
    FROM TABLE(FLATTEN(INPUT => PARSE_JSON(CURRENT_AVAILABLE_ROLES()))) f,
         TABLE(SPLIT_TO_TABLE(:roles, ',')) r
   WHERE UPPER(f.VALUE::VARCHAR) = UPPER(TRIM(r.VALUE));
  IF (authorized = 0) THEN RAISE not_authorized; END IF;

  SELECT COUNT(*) INTO :found FROM RR_RECOVERY_ACTIONS WHERE ACTION_ID = :P_ACTION_ID;
  IF (found = 0) THEN RAISE not_found; END IF;

  SELECT a.STATUS, a.EXPECTED_RECOVERY_USD, l.RECOVERABLE_USD, l.ACTIVE_FLAG
    INTO :st, :exp_usd, :rec_usd, :is_active
    FROM RR_RECOVERY_ACTIONS a LEFT JOIN RR_RISK_LEDGER l ON l.RISK_ITEM_ID = a.RISK_ITEM_ID
   WHERE a.ACTION_ID = :P_ACTION_ID;
  IF (st <> 'PROPOSED') THEN RAISE bad_state; END IF;
  IF (NOT COALESCE(is_active, FALSE) OR exp_usd > rec_usd + 0.01) THEN RAISE over_limit; END IF;

  UPDATE RR_RECOVERY_ACTIONS
     SET STATUS = 'APPROVED', DECISION_BY = CURRENT_USER(), DECISION_TIME = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ,
         NOTES = COALESCE(NOTES || ' | ', '') || 'APPROVED: ' || COALESCE(:P_NOTES, ''),
         UPDATED_AT = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
   WHERE ACTION_ID = :P_ACTION_ID AND STATUS = 'PROPOSED';

  INSERT INTO AGENT_ACTIONS (LOG_ID, ACTED_AT, ACTOR, ACTOR_ROLE, SURFACE, ACTION_TYPE, TARGET_OBJECT, TARGET_ID, PAYLOAD)
  SELECT UUID_STRING(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, CURRENT_USER(), CURRENT_ROLE(), 'RR_HUMAN_DECISION',
         'APPROVE_RECOVERY_ACTION', 'RR_RECOVERY_ACTIONS', :P_ACTION_ID,
         OBJECT_CONSTRUCT('expected_recovery_usd', :exp_usd, 'governed_recoverable_usd', :rec_usd, 'notes', :P_NOTES);

  CALL SP_RR_MIRROR_DECISION(:P_ACTION_ID) INTO :mirror_res;
  RETURN 'APPROVED ' || P_ACTION_ID || ' by ' || CURRENT_USER() || ' (' || mirror_res || ')';
END;
$$;

CREATE OR REPLACE PROCEDURE SP_REJECT_RECOVERY_ACTION(P_ACTION_ID VARCHAR, P_NOTES VARCHAR)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
COMMENT = 'HUMAN rejection of a PROPOSED recovery action (reason required). Never exposed to the agent.'
AS
$$
DECLARE
  roles       VARCHAR;
  authorized  NUMBER;
  found       NUMBER;
  st          VARCHAR;
  mirror_res  VARCHAR;
  not_authorized EXCEPTION (-20301, 'Not authorized: caller holds none of RR_CONFIG.APPROVER_ROLES.');
  not_found      EXCEPTION (-20302, 'Recovery action not found.');
  bad_state      EXCEPTION (-20303, 'Only PROPOSED actions can be rejected.');
  no_reason      EXCEPTION (-20305, 'A rejection reason (P_NOTES) is required.');
BEGIN
  IF (NULLIF(TRIM(COALESCE(P_NOTES, '')), '') IS NULL) THEN RAISE no_reason; END IF;
  SELECT APPROVER_ROLES INTO :roles FROM RR_CONFIG WHERE CONFIG_ID = 1;
  SELECT COUNT(*) INTO :authorized
    FROM TABLE(FLATTEN(INPUT => PARSE_JSON(CURRENT_AVAILABLE_ROLES()))) f,
         TABLE(SPLIT_TO_TABLE(:roles, ',')) r
   WHERE UPPER(f.VALUE::VARCHAR) = UPPER(TRIM(r.VALUE));
  IF (authorized = 0) THEN RAISE not_authorized; END IF;

  SELECT COUNT(*) INTO :found FROM RR_RECOVERY_ACTIONS WHERE ACTION_ID = :P_ACTION_ID;
  IF (found = 0) THEN RAISE not_found; END IF;
  SELECT STATUS INTO :st FROM RR_RECOVERY_ACTIONS WHERE ACTION_ID = :P_ACTION_ID;
  IF (st <> 'PROPOSED') THEN RAISE bad_state; END IF;

  UPDATE RR_RECOVERY_ACTIONS
     SET STATUS = 'REJECTED', DECISION_BY = CURRENT_USER(), DECISION_TIME = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ,
         NOTES = COALESCE(NOTES || ' | ', '') || 'REJECTED: ' || :P_NOTES, PRIORITY_RANK = NULL,
         UPDATED_AT = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
   WHERE ACTION_ID = :P_ACTION_ID AND STATUS = 'PROPOSED';

  INSERT INTO AGENT_ACTIONS (LOG_ID, ACTED_AT, ACTOR, ACTOR_ROLE, SURFACE, ACTION_TYPE, TARGET_OBJECT, TARGET_ID, PAYLOAD)
  SELECT UUID_STRING(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, CURRENT_USER(), CURRENT_ROLE(), 'RR_HUMAN_DECISION',
         'REJECT_RECOVERY_ACTION', 'RR_RECOVERY_ACTIONS', :P_ACTION_ID, OBJECT_CONSTRUCT('notes', :P_NOTES);

  CALL SP_RR_MIRROR_DECISION(:P_ACTION_ID) INTO :mirror_res;
  RETURN 'REJECTED ' || P_ACTION_ID || ' by ' || CURRENT_USER() || ' (' || mirror_res || ')';
END;
$$;

-- ---------------------------------------------------------------------------
-- Prevention controls and verified answers (human-curated write-back)
-- ---------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE SP_LAUNCH_PREVENTION_CONTROL(
  P_CATEGORY VARCHAR, P_CONTROL_NAME VARCHAR, P_OWNER VARCHAR, P_REVIEW_DATE DATE, P_NOTE VARCHAR)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
COMMENT = 'HUMAN launch of a prevention control (e.g. weekly component-shortage review). Writes PREVENTION_CONTROLS.'
AS
$$
DECLARE
  roles      VARCHAR;
  authorized NUMBER;
  control_id VARCHAR DEFAULT ('PC-' || UUID_STRING());
  not_authorized EXCEPTION (-20301, 'Not authorized: caller holds none of RR_CONFIG.APPROVER_ROLES.');
BEGIN
  SELECT APPROVER_ROLES INTO :roles FROM RR_CONFIG WHERE CONFIG_ID = 1;
  SELECT COUNT(*) INTO :authorized
    FROM TABLE(FLATTEN(INPUT => PARSE_JSON(CURRENT_AVAILABLE_ROLES()))) f,
         TABLE(SPLIT_TO_TABLE(:roles, ',')) r
   WHERE UPPER(f.VALUE::VARCHAR) = UPPER(TRIM(r.VALUE));
  IF (authorized = 0) THEN RAISE not_authorized; END IF;

  INSERT INTO PREVENTION_CONTROLS (CONTROL_ID, CATEGORY, CONTROL_NAME, OWNER, STATUS, LAUNCHED_BY, LAUNCHED_AT, REVIEW_DATE, NOTE)
  SELECT :control_id, :P_CATEGORY, :P_CONTROL_NAME, :P_OWNER, 'LAUNCHED', CURRENT_USER(),
         CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, :P_REVIEW_DATE, :P_NOTE;

  INSERT INTO AGENT_ACTIONS (LOG_ID, ACTED_AT, ACTOR, ACTOR_ROLE, SURFACE, ACTION_TYPE, TARGET_OBJECT, TARGET_ID, PAYLOAD)
  SELECT UUID_STRING(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, CURRENT_USER(), CURRENT_ROLE(), 'RR_HUMAN_DECISION',
         'LAUNCH_PREVENTION_CONTROL', 'PREVENTION_CONTROLS', :control_id,
         OBJECT_CONSTRUCT('category', :P_CATEGORY, 'control_name', :P_CONTROL_NAME, 'owner', :P_OWNER);
  RETURN 'LAUNCHED ' || control_id;
END;
$$;

CREATE OR REPLACE PROCEDURE SP_SAVE_VERIFIED_ANSWER(P_QUESTION VARCHAR, P_ANSWER_TEXT VARCHAR, P_SQL_TEXT VARCHAR)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
COMMENT = 'HUMAN-curated save of an agent answer into VERIFIED_ANSWERS, stamped with the latest trust status.'
AS
$$
DECLARE
  answer_id    VARCHAR DEFAULT ('VA-' || UUID_STRING());
  trust_status VARCHAR;
BEGIN
  SELECT COALESCE(MAX_BY(STATUS, ENDED_AT), 'NOT_RUN') INTO :trust_status
    FROM RR_REFRESH_AUDIT WHERE STAGE = 'TRUST';
  INSERT INTO VERIFIED_ANSWERS (ANSWER_ID, QUESTION, ANSWER_TEXT, SQL_TEXT, TRUST_STATUS, SAVED_BY, SURFACE, SAVED_AT)
  SELECT :answer_id, :P_QUESTION, :P_ANSWER_TEXT, :P_SQL_TEXT, :trust_status, CURRENT_USER(), 'RR_REVENUE_RECOVERY_AGENT',
         CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
  INSERT INTO AGENT_ACTIONS (LOG_ID, ACTED_AT, ACTOR, ACTOR_ROLE, SURFACE, ACTION_TYPE, TARGET_OBJECT, TARGET_ID, PAYLOAD)
  SELECT UUID_STRING(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, CURRENT_USER(), CURRENT_ROLE(), 'RR_HUMAN_DECISION',
         'SAVE_VERIFIED_ANSWER', 'VERIFIED_ANSWERS', :answer_id, OBJECT_CONSTRUCT('trust_status', :trust_status);
  RETURN 'SAVED ' || answer_id || ' (trust ' || trust_status || ')';
END;
$$;


-- ---------------------------------------------------------------------------
-- Human progress updates and planned-control launch (caller's rights)
-- ---------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE SP_UPDATE_ACTION_STATUS(P_ACTION_ID VARCHAR, P_STATUS VARCHAR, P_NOTE VARCHAR)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
COMMENT = 'HUMAN progress update of an approved action: APPROVED -> IN_PROGRESS -> DONE. Never exposed to the agent.'
AS
$$
DECLARE
  roles       VARCHAR;
  authorized  NUMBER;
  found       NUMBER;
  st          VARCHAR;
  target      VARCHAR;
  mirror_res  VARCHAR;
  not_authorized EXCEPTION (-20301, 'Not authorized: caller holds none of RR_CONFIG.APPROVER_ROLES.');
  not_found      EXCEPTION (-20302, 'Recovery action not found.');
  bad_transition EXCEPTION (-20306, 'Allowed transitions: APPROVED -> IN_PROGRESS, IN_PROGRESS -> DONE.');
BEGIN
  target := UPPER(TRIM(COALESCE(P_STATUS, '')));
  SELECT APPROVER_ROLES INTO :roles FROM RR_CONFIG WHERE CONFIG_ID = 1;
  SELECT COUNT(*) INTO :authorized
    FROM TABLE(FLATTEN(INPUT => PARSE_JSON(CURRENT_AVAILABLE_ROLES()))) f,
         TABLE(SPLIT_TO_TABLE(:roles, ',')) r
   WHERE UPPER(f.VALUE::VARCHAR) = UPPER(TRIM(r.VALUE));
  IF (authorized = 0) THEN RAISE not_authorized; END IF;

  SELECT COUNT(*) INTO :found FROM RR_RECOVERY_ACTIONS WHERE ACTION_ID = :P_ACTION_ID;
  IF (found = 0) THEN RAISE not_found; END IF;
  SELECT STATUS INTO :st FROM RR_RECOVERY_ACTIONS WHERE ACTION_ID = :P_ACTION_ID;
  IF (NOT ((st = 'APPROVED' AND target = 'IN_PROGRESS') OR (st = 'IN_PROGRESS' AND target = 'DONE'))) THEN
    RAISE bad_transition;
  END IF;

  UPDATE RR_RECOVERY_ACTIONS
     SET STATUS = :target,
         NOTES = COALESCE(NOTES || ' | ', '') || :target || ' by ' || CURRENT_USER() || ': ' || COALESCE(:P_NOTE, ''),
         PRIORITY_RANK = IFF(:target = 'DONE', NULL, PRIORITY_RANK),
         UPDATED_AT = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
   WHERE ACTION_ID = :P_ACTION_ID;

  INSERT INTO AGENT_ACTIONS (LOG_ID, ACTED_AT, ACTOR, ACTOR_ROLE, SURFACE, ACTION_TYPE, TARGET_OBJECT, TARGET_ID, PAYLOAD)
  SELECT UUID_STRING(), CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, CURRENT_USER(), CURRENT_ROLE(), 'RR_HUMAN_DECISION',
         'UPDATE_ACTION_STATUS', 'RR_RECOVERY_ACTIONS', :P_ACTION_ID,
         OBJECT_CONSTRUCT('from', :st, 'to', :target, 'note', :P_NOTE);

  CALL SP_RR_MIRROR_DECISION(:P_ACTION_ID) INTO :mirror_res;
  RETURN TO_JSON(OBJECT_CONSTRUCT('ok', TRUE, 'action_id', P_ACTION_ID, 'status', target,
                                  'message', target || ' by ' || CURRENT_USER(), 'mirror', mirror_res));
END;
$$;

CREATE OR REPLACE PROCEDURE SP_LAUNCH_PLANNED_CONTROL(P_CONTROL_ID VARCHAR, P_OWNER VARCHAR, P_REVIEW_DAYS NUMBER, P_NOTE VARCHAR)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
COMMENT = 'HUMAN launch of a control from RR_PREVENTION_PLAN (writes PREVENTION_CONTROLS via SP_LAUNCH_PREVENTION_CONTROL).'
AS
$$
DECLARE
  found       NUMBER;
  cat         VARCHAR;
  ctl_name    VARCHAR;
  ctl_owner   VARCHAR;
  st          VARCHAR;
  review      DATE;
  res         VARCHAR;
  launched_id VARCHAR;
  not_found EXCEPTION (-20311, 'Prevention control not found in RR_PREVENTION_PLAN.');
  bad_state EXCEPTION (-20312, 'Only PROPOSED prevention controls can be launched.');
BEGIN
  SELECT COUNT(*) INTO :found FROM RR_PREVENTION_PLAN WHERE CONTROL_ID = :P_CONTROL_ID;
  IF (found = 0) THEN RAISE not_found; END IF;
  SELECT CATEGORY, CONTROL_NAME, COALESCE(NULLIF(TRIM(:P_OWNER), ''), OWNER), STATUS
    INTO :cat, :ctl_name, :ctl_owner, :st
    FROM RR_PREVENTION_PLAN WHERE CONTROL_ID = :P_CONTROL_ID;
  IF (st <> 'PROPOSED') THEN RAISE bad_state; END IF;

  review := DATEADD(day, COALESCE(P_REVIEW_DAYS, 30), CURRENT_DATE());
  CALL SP_LAUNCH_PREVENTION_CONTROL(:cat, :ctl_name, :ctl_owner, :review, :P_NOTE) INTO :res;
  launched_id := TRIM(REPLACE(res, 'LAUNCHED ', ''));

  UPDATE RR_PREVENTION_PLAN
     SET STATUS = 'LAUNCHED', OWNER = :ctl_owner, LAUNCHED_CONTROL_ID = :launched_id, LAUNCHED_BY = CURRENT_USER(),
         LAUNCHED_AT = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, REVIEW_DATE = :review,
         UPDATED_AT = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
   WHERE CONTROL_ID = :P_CONTROL_ID;

  RETURN TO_JSON(OBJECT_CONSTRUCT('ok', TRUE, 'control_id', P_CONTROL_ID, 'launched_control_id', launched_id,
                                  'owner', ctl_owner, 'review_date', review, 'message', res));
END;
$$;

-- ===========================================================================
-- EXECUTE
-- ===========================================================================
CALL SP_PROPOSE_TOP_RECOVERY_ACTIONS(10);
CALL SP_RR_TRUST_CHECK();

SELECT PRIORITY_RANK, CATEGORY, CUSTOMER_NAME, ACTION_TEXT, OWNER_ROLE, FIRST_STEP, DUE_DATE,
       EXPECTED_RECOVERY_USD, STATUS, ACTION_SOURCE
FROM RR_RECOVERY_ACTIONS WHERE STATUS IN ('PROPOSED', 'APPROVED', 'IN_PROGRESS')
ORDER BY PRIORITY_RANK;

SELECT * FROM RR_GAP_PLAN ORDER BY STEP_ORDER;
SELECT * FROM RR_PREVENTION_PLAN ORDER BY EST_PREVENTABLE_USD DESC;

SELECT CHECK_GROUP, CHECK_NAME, SEVERITY, STATUS, EXPECTED, ACTUAL
FROM RR_TRUST_RESULTS
WHERE TRUST_RUN_ID = (SELECT MAX(TRUST_RUN_ID) FROM RR_TRUST_RESULTS)
ORDER BY IFF(STATUS = 'FAIL', 0, 1), CHECK_GROUP, CHECK_NAME;

-- Human approval example (run as a human with an approver role; replace the ID):
-- CALL SP_APPROVE_RECOVERY_ACTION('<ACTION_ID>', 'Approved in weekly revenue call');
-- CALL SP_REJECT_RECOVERY_ACTION('<ACTION_ID>', 'Customer already escalated by account team');
-- CALL SP_UPDATE_ACTION_STATUS('<ACTION_ID>', 'IN_PROGRESS', 'Transfer order raised');
-- CALL SP_LAUNCH_PLANNED_CONTROL('<CONTROL_ID>', NULL, 30, 'Launched in weekly ops review');
