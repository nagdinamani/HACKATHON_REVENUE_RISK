/* =============================================================================
   05_REFRESH_DECISION_LAYER.sql
   Deterministic refresh: Detect -> Calculate -> Persist -> Hash.

   SP_REFRESH_REVENUE_DECISION_LAYER()
     0. Config lock + plan-scenario guard
     1. ML second opinion (statistical fallback + native overlay if deployed)
     2. RR_PRODUCT_INVENTORY_360 (latest snapshot on/before AS_OF_DATE)
     3. Inventory optimiser -> RR_FULFILLMENT_ALLOCATION
     4. Five governed risk mechanisms -> temp stage (query ID captured per category)
     5. Duplicate guard, hashing, MERGE into RR_RISK_LEDGER with change tracking
     6. RR_OPPORTUNITY_360, RR_CUSTOMER_360
     7. RR_REVENUE_OUTLOOK (authoritative executive row, base + upside scenarios)
     8. RR_REFRESH_AUDIT

   All dates are evaluated against RR_CONFIG.AS_OF_DATE (locked), never CURRENT_DATE.
   No expected total is referenced anywhere in this file.
   ============================================================================= */

USE DATABASE HACKATHON_REVENUE_RISK;
USE SCHEMA SOLUTION;
USE WAREHOUSE RR_WH;

-- ---------------------------------------------------------------------------
-- Governed row hash (shared by the refresh and by SP_RR_TRUST_CHECK, which
-- recomputes it to prove AI enrichment never altered financial columns)
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION RR_LEDGER_ROW_HASH(
  CATEGORY VARCHAR, SOURCE_ID VARCHAR, CUSTOMER_ID VARCHAR, PRODUCT_ID VARCHAR,
  AT_RISK_USD NUMBER(18,2), RECOVERABLE_USD NUMBER(18,2), RECOVERY_PROB NUMBER(8,4),
  DUE_DATE DATE, BLOCKER VARCHAR, RECOVERY_PATH VARCHAR, EVIDENCE_TEXT VARCHAR)
RETURNS VARCHAR
COMMENT = 'SHA-256 over the governed (non-AI, non-ML) columns of a risk ledger row.'
AS
$$
  SHA2(CONCAT_WS('|',
    COALESCE(CATEGORY, ''), COALESCE(SOURCE_ID, ''), COALESCE(CUSTOMER_ID, ''), COALESCE(PRODUCT_ID, ''),
    COALESCE(TO_VARCHAR(AT_RISK_USD), ''), COALESCE(TO_VARCHAR(RECOVERABLE_USD), ''),
    COALESCE(TO_VARCHAR(RECOVERY_PROB), ''), COALESCE(TO_VARCHAR(DUE_DATE), ''),
    COALESCE(BLOCKER, ''), COALESCE(RECOVERY_PATH, ''), COALESCE(EVIDENCE_TEXT, '')), 256)
$$;

CREATE OR REPLACE PROCEDURE SP_REFRESH_REVENUE_DECISION_LAYER()
RETURNS VARIANT
LANGUAGE SQL
EXECUTE AS CALLER
COMMENT = 'Deterministic refresh of the Revenue Recovery decision layer (360 tables, risk ledger, revenue outlook).'
AS
$$
DECLARE
  run_id        VARCHAR DEFAULT ('RF-' || TO_VARCHAR(CURRENT_TIMESTAMP(), 'YYYYMMDDHH24MISSFF3'));
  started_at    TIMESTAMP_NTZ DEFAULT (CURRENT_TIMESTAMP()::TIMESTAMP_NTZ);
  as_of         DATE;
  refresh_ml    BOOLEAN;
  scen_cfg      VARCHAR;
  scen_count    NUMBER;
  plan_rows     NUMBER;
  dup_count     NUMBER;
  qid           VARCHAR;
  alloc_result  VARIANT;
  so_result     VARCHAR DEFAULT 'SKIPPED (REFRESH_ML_IN_PIPELINE = FALSE)';
  summary       VARIANT;
  err_code      NUMBER;
  err_msg       VARCHAR;
  err_state     VARCHAR;
  plan_empty         EXCEPTION (-20201, 'FACT_REVENUE_PLAN has no rows for the configured quarter/scenario. STOP.');
  scenario_ambiguous EXCEPTION (-20202, 'FACT_REVENUE_PLAN has multiple SCENARIO_IDs for Q4 and RR_CONFIG.PLAN_SCENARIO_ID is NULL. Set it in 01 (see calibration 7b). STOP.');
  duplicate_items    EXCEPTION (-20203, 'Duplicate RISK_ITEM_IDs produced by the risk rules (source keys not unique). STOP.');
BEGIN
  -- -------------------------------------------------------------------------
  -- 0. Guards
  -- -------------------------------------------------------------------------
  CALL SP_ASSERT_CONFIG_LOCKED();
  SELECT AS_OF_DATE, REFRESH_ML_IN_PIPELINE, PLAN_SCENARIO_ID
    INTO :as_of, :refresh_ml, :scen_cfg
    FROM RR_CONFIG WHERE CONFIG_ID = 1;

  SELECT COUNT(*), COUNT(DISTINCT COALESCE(p.SCENARIO_ID, '<NULL>'))
    INTO :plan_rows, :scen_count
    FROM FACT_REVENUE_PLAN p
    JOIN RR_CONFIG c ON c.CONFIG_ID = 1
   WHERE p.PERIOD_MONTH BETWEEN c.QTR_START AND c.QTR_END
     AND (c.PLAN_SCENARIO_ID IS NULL OR p.SCENARIO_ID = c.PLAN_SCENARIO_ID);
  IF (plan_rows = 0) THEN RAISE plan_empty; END IF;
  IF (scen_count > 1) THEN RAISE scenario_ambiguous; END IF;

  -- -------------------------------------------------------------------------
  -- 1. ML / statistical second opinion
  -- -------------------------------------------------------------------------
  IF (refresh_ml) THEN
    CALL SP_REFRESH_SECOND_OPINION() INTO :so_result;
  END IF;

  -- -------------------------------------------------------------------------
  -- 2. Product x warehouse inventory 360
  -- -------------------------------------------------------------------------
  INSERT OVERWRITE INTO RR_PRODUCT_INVENTORY_360
  WITH c AS (SELECT * FROM RR_CONFIG WHERE CONFIG_ID = 1),
  inv AS (
    SELECT i.* FROM FACT_INVENTORY i CROSS JOIN c
    WHERE i.SNAPSHOT_DATE <= c.AS_OF_DATE
    QUALIFY ROW_NUMBER() OVER (PARTITION BY i.PRODUCT_ID, i.WAREHOUSE ORDER BY i.SNAPSHOT_DATE DESC, i.INVENTORY_ID DESC) = 1
  ),
  blocked AS (
    SELECT o.PRODUCT_ID, o.WAREHOUSE, SUM(COALESCE(o.QUANTITY, 0)) AS Q, SUM(o.BOOKED_VALUE) AS V
    FROM FACT_ORDER o CROSS JOIN c
    WHERE TRIM(o.RISK_REASON) = c.FULFILLMENT_RISK_REASON
      AND (o.SHIPPED_DATE IS NULL OR o.SHIPPED_DATE > c.AS_OF_DATE)
      AND (o.ORDER_DATE IS NULL OR o.ORDER_DATE <= c.AS_OF_DATE)
      AND (NOT COALESCE(c.FULFILLMENT_Q4_PROMISE_ONLY, FALSE) OR o.PROMISED_DATE <= c.QTR_END)
    GROUP BY 1, 2
  ),
  tot AS (SELECT PRODUCT_ID, SUM(GREATEST(COALESCE(AVAILABLE, 0), 0)) AS T FROM inv GROUP BY 1),
  dem AS (SELECT PRODUCT_ID, SUM(FORECAST_QTY) AS D, ANY_VALUE(ML_METHOD) AS M FROM RR_ML_DEMAND_FORECAST GROUP BY 1)
  SELECT inv.PRODUCT_ID, inv.WAREHOUSE, p.PRODUCT_NAME, p.PRODUCT_FAMILY, inv.SNAPSHOT_DATE,
         inv.ON_HAND, inv.RESERVED, GREATEST(COALESCE(inv.AVAILABLE, 0), 0),
         COALESCE(b.Q, 0), COALESCE(b.V, 0), 0, GREATEST(COALESCE(inv.AVAILABLE, 0), 0),
         tot.T, dem.D, ROUND(tot.T / NULLIF(dem.D, 0), 4), dem.M,
         c.AS_OF_DATE, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
  FROM inv
  CROSS JOIN c
  LEFT JOIN DIM_PRODUCT p ON p.PRODUCT_ID = inv.PRODUCT_ID
  LEFT JOIN blocked b ON b.PRODUCT_ID = inv.PRODUCT_ID AND b.WAREHOUSE = inv.WAREHOUSE
  LEFT JOIN tot ON tot.PRODUCT_ID = inv.PRODUCT_ID
  LEFT JOIN dem ON dem.PRODUCT_ID = inv.PRODUCT_ID;

  -- -------------------------------------------------------------------------
  -- 3. Inventory optimiser (no double counting of shared alternate stock)
  -- -------------------------------------------------------------------------
  CALL SP_ALLOCATE_ALTERNATE_INVENTORY() INTO :alloc_result;

  UPDATE RR_PRODUCT_INVENTORY_360 t
     SET DONATED_QTY = s.Q,
         REMAINING_AFTER_ALLOCATION = t.AVAILABLE_QTY - s.Q
    FROM (SELECT PRODUCT_ID, ALTERNATE_WAREHOUSE, SUM(ALLOCATED_QTY) AS Q
            FROM RR_FULFILLMENT_ALLOCATION WHERE COVERED_FLAG GROUP BY 1, 2) s
   WHERE t.PRODUCT_ID = s.PRODUCT_ID AND t.WAREHOUSE = s.ALTERNATE_WAREHOUSE;

  -- -------------------------------------------------------------------------
  -- 4. Governed risk mechanisms -> stage
  -- -------------------------------------------------------------------------
  CREATE OR REPLACE TEMPORARY TABLE RR_TMP_LEDGER_STAGE (
    RISK_ITEM_ID VARCHAR, CATEGORY VARCHAR, SOURCE_TABLE VARCHAR, SOURCE_ID VARCHAR,
    CUSTOMER_ID VARCHAR, CUSTOMER_NAME VARCHAR, PRODUCT_ID VARCHAR, PRODUCT_NAME VARCHAR, PRODUCT_FAMILY VARCHAR,
    REGION_ID VARCHAR, REGION_NAME VARCHAR,
    AT_RISK_USD NUMBER(18,2), RECOVERABLE_USD NUMBER(18,2), RECOVERY_PROB NUMBER(8,4),
    VALUE_BASIS VARCHAR, DUE_DATE DATE, BLOCKER VARCHAR, RECOVERY_PATH VARCHAR,
    EVIDENCE_TEXT VARCHAR, EVIDENCE VARIANT,
    ML_SCORE NUMBER(12,4), ML_SCORE_TYPE VARCHAR, ML_METHOD VARCHAR,
    CALCULATION_RULE VARCHAR, SOURCE_QUERY_ID VARCHAR,
    ROW_HASH VARCHAR, AI_INPUT_HASH VARCHAR);

  -- 4a. PIPELINE: late-stage/at-risk opportunities that carry a material blocker
  INSERT INTO RR_TMP_LEDGER_STAGE (RISK_ITEM_ID, CATEGORY, SOURCE_TABLE, SOURCE_ID, CUSTOMER_ID, CUSTOMER_NAME,
    PRODUCT_ID, PRODUCT_NAME, PRODUCT_FAMILY, REGION_ID, REGION_NAME, AT_RISK_USD, RECOVERABLE_USD, RECOVERY_PROB,
    VALUE_BASIS, DUE_DATE, BLOCKER, RECOVERY_PATH, EVIDENCE_TEXT, EVIDENCE, ML_SCORE, ML_SCORE_TYPE, ML_METHOD, CALCULATION_RULE)
  WITH c AS (SELECT * FROM RR_CONFIG WHERE CONFIG_ID = 1),
  rgn AS (SELECT REGION_ID, ANY_VALUE(REGION_NAME) AS REGION_NAME FROM DIM_CUSTOMER GROUP BY 1),
  src AS (
    SELECT o.*,
           LEAST(GREATEST(IFF(o.RECOVERY_PROBABILITY > 1, o.RECOVERY_PROBABILITY / 100, o.RECOVERY_PROBABILITY), 0), 1) AS GOV_PROB
    FROM FACT_OPPORTUNITY o CROSS JOIN c
    WHERE (o.ACTUAL_CLOSE_DATE IS NULL OR o.ACTUAL_CLOSE_DATE > c.AS_OF_DATE)
      AND (o.CREATED_DATE IS NULL OR o.CREATED_DATE <= c.AS_OF_DATE)
      AND o.EXPECTED_CLOSE_DATE BETWEEN c.QTR_START AND c.QTR_END
      AND NULLIF(TRIM(o.RISK_REASON), '') IS NOT NULL
      AND COALESCE(o.OPPORTUNITY_AMOUNT, 0) > 0
      AND (c.PIPELINE_STAGE_FILTER IS NULL
           OR POSITION(',' || UPPER(TRIM(o.STAGE_NAME)) || ',' IN ',' || UPPER(REPLACE(c.PIPELINE_STAGE_FILTER, ', ', ',')) || ',') > 0)
  )
  SELECT 'PIPE-' || s.OPPORTUNITY_ID, 'PIPELINE', 'FACT_OPPORTUNITY', s.OPPORTUNITY_ID,
         s.CUSTOMER_ID, cu.CUSTOMER_NAME, s.PRODUCT_ID, p.PRODUCT_NAME, p.PRODUCT_FAMILY,
         COALESCE(s.REGION_ID, cu.REGION_ID), COALESCE(r.REGION_NAME, cu.REGION_NAME),
         s.OPPORTUNITY_AMOUNT,
         ROUND(s.OPPORTUNITY_AMOUNT * COALESCE(s.GOV_PROB, 0), 2),
         s.GOV_PROB,
         'BOOKING', s.EXPECTED_CLOSE_DATE, TRIM(s.RISK_REASON), NULL,
         'Opportunity ' || COALESCE(s.OPPORTUNITY_NAME, s.OPPORTUNITY_ID) || ' (' || s.OPPORTUNITY_ID || ') is in stage '
           || COALESCE(s.STAGE_NAME, 'n/a') || ' with forecast category ' || COALESCE(s.FORECAST_CATEGORY, 'n/a')
           || ' and CRM probability ' || COALESCE(TO_VARCHAR(s.PROBABILITY_PERCENT), 'n/a') || '%; expected close '
           || TO_VARCHAR(s.EXPECTED_CLOSE_DATE) || '; ' || COALESCE(TO_VARCHAR(s.DAYS_IN_STAGE), 'n/a')
           || ' days in stage; blocker: ' || TRIM(s.RISK_REASON) || '.',
         OBJECT_CONSTRUCT('stage', s.STAGE_NAME, 'forecast_category', s.FORECAST_CATEGORY,
                          'crm_probability_pct', s.PROBABILITY_PERCENT, 'days_in_stage', s.DAYS_IN_STAGE,
                          'expected_close_date', s.EXPECTED_CLOSE_DATE, 'governed_recovery_prob', s.GOV_PROB,
                          'opportunity_status', s.OPPORTUNITY_STATUS),
         ds.ML_WIN_PROB, 'WIN_PROBABILITY', ds.ML_METHOD,
         'PIPELINE: open on AS_OF_DATE, EXPECTED_CLOSE_DATE in Q4, RISK_REASON (blocker) present'
           || IFF(c.PIPELINE_STAGE_FILTER IS NULL, '', ', STAGE_NAME in [' || c.PIPELINE_STAGE_FILTER || ']')
           || '. AT_RISK = OPPORTUNITY_AMOUNT. RECOVERABLE = OPPORTUNITY_AMOUNT x governed RECOVERY_PROBABILITY.'
  FROM src s
  CROSS JOIN c
  LEFT JOIN DIM_CUSTOMER cu ON cu.CUSTOMER_ID = s.CUSTOMER_ID
  LEFT JOIN DIM_PRODUCT p   ON p.PRODUCT_ID = s.PRODUCT_ID
  LEFT JOIN rgn r           ON r.REGION_ID = COALESCE(s.REGION_ID, cu.REGION_ID)
  LEFT JOIN RR_ML_DEAL_SCORES ds ON ds.OPPORTUNITY_ID = s.OPPORTUNITY_ID;
  qid := SQLID;
  UPDATE RR_TMP_LEDGER_STAGE SET SOURCE_QUERY_ID = :qid WHERE CATEGORY = 'PIPELINE';

  -- 4b. FULFILLMENT: priority orders blocked by the LOCKED reason; recoverable
  --     only when the optimiser found full same-product alternate coverage.
  INSERT INTO RR_TMP_LEDGER_STAGE (RISK_ITEM_ID, CATEGORY, SOURCE_TABLE, SOURCE_ID, CUSTOMER_ID, CUSTOMER_NAME,
    PRODUCT_ID, PRODUCT_NAME, PRODUCT_FAMILY, REGION_ID, REGION_NAME, AT_RISK_USD, RECOVERABLE_USD, RECOVERY_PROB,
    VALUE_BASIS, DUE_DATE, BLOCKER, RECOVERY_PATH, EVIDENCE_TEXT, EVIDENCE, ML_SCORE, ML_SCORE_TYPE, ML_METHOD, CALCULATION_RULE)
  WITH pi AS (
    SELECT PRODUCT_ID, MAX(DEMAND_COVERAGE_RATIO) AS DEMAND_COVERAGE_RATIO, ANY_VALUE(ML_DEMAND_METHOD) AS ML_DEMAND_METHOD
    FROM RR_PRODUCT_INVENTORY_360 GROUP BY 1
  )
  SELECT 'FUL-' || a.ORDER_ID, 'FULFILLMENT', 'FACT_ORDER', a.ORDER_ID,
         o.CUSTOMER_ID, cu.CUSTOMER_NAME, o.PRODUCT_ID, p.PRODUCT_NAME, p.PRODUCT_FAMILY,
         cu.REGION_ID, cu.REGION_NAME,
         o.BOOKED_VALUE,
         IFF(a.COVERED_FLAG, o.BOOKED_VALUE, 0),
         IFF(a.COVERED_FLAG, 1, 0),
         'ORDER', o.PROMISED_DATE, TRIM(o.RISK_REASON),
         IFF(a.COVERED_FLAG, 'Transfer ' || a.ALLOCATED_QTY || ' units from warehouse ' || a.ALTERNATE_WAREHOUSE
                             || ' to ' || COALESCE(o.WAREHOUSE, 'source warehouse'), NULL),
         'Priority order ' || o.ORDER_ID || ' for ' || COALESCE(TO_VARCHAR(o.QUANTITY), 'unknown') || ' units of '
           || COALESCE(p.PRODUCT_NAME, o.PRODUCT_ID) || ' from warehouse ' || COALESCE(o.WAREHOUSE, 'n/a')
           || ' (' || COALESCE(TO_VARCHAR(a.SOURCE_AVAILABLE_QTY), 'no') || ' units available there), promised '
           || COALESCE(TO_VARCHAR(o.PROMISED_DATE), 'n/a') || ', ship status ' || COALESCE(o.SHIP_STATUS, 'n/a')
           || ', is blocked: ' || TRIM(o.RISK_REASON) || '. ' || a.REASON || '.',
         OBJECT_CONSTRUCT('order_line_id', o.ORDER_LINE_ID, 'quantity', o.QUANTITY, 'source_warehouse', o.WAREHOUSE,
                          'source_available_qty', a.SOURCE_AVAILABLE_QTY, 'alternate_warehouse', a.ALTERNATE_WAREHOUSE,
                          'alt_available_before', a.ALT_AVAILABLE_BEFORE, 'alt_available_after', a.ALT_AVAILABLE_AFTER,
                          'allocation_seq', a.ALLOCATION_SEQ, 'allocation_policy', a.ALLOCATION_POLICY,
                          'promised_date', o.PROMISED_DATE, 'ship_status', o.SHIP_STATUS),
         pi.DEMAND_COVERAGE_RATIO, 'DEMAND_COVERAGE_RATIO', pi.ML_DEMAND_METHOD,
         'FULFILLMENT: FACT_ORDER.RISK_REASON = RR_CONFIG.FULFILLMENT_RISK_REASON, unshipped on AS_OF_DATE. AT_RISK = BOOKED_VALUE. '
           || 'RECOVERABLE = BOOKED_VALUE only when ONE alternate warehouse holding the same PRODUCT_ID covers the full QUANTITY '
           || 'after earlier allocations (shared stock decremented, no double counting); otherwise 0.'
  FROM RR_FULFILLMENT_ALLOCATION a
  JOIN FACT_ORDER o ON o.ORDER_ID = a.ORDER_ID
  LEFT JOIN DIM_CUSTOMER cu ON cu.CUSTOMER_ID = o.CUSTOMER_ID
  LEFT JOIN DIM_PRODUCT p   ON p.PRODUCT_ID = o.PRODUCT_ID
  LEFT JOIN pi              ON pi.PRODUCT_ID = o.PRODUCT_ID;
  qid := SQLID;
  UPDATE RR_TMP_LEDGER_STAGE SET SOURCE_QUERY_ID = :qid WHERE CATEGORY = 'FULFILLMENT';

  -- 4c. BILLING: shipped orders with invoice exceptions; operational fixes are
  --     recoverable, commercial disputes never auto-recoverable.
  INSERT INTO RR_TMP_LEDGER_STAGE (RISK_ITEM_ID, CATEGORY, SOURCE_TABLE, SOURCE_ID, CUSTOMER_ID, CUSTOMER_NAME,
    PRODUCT_ID, PRODUCT_NAME, PRODUCT_FAMILY, REGION_ID, REGION_NAME, AT_RISK_USD, RECOVERABLE_USD, RECOVERY_PROB,
    VALUE_BASIS, DUE_DATE, BLOCKER, RECOVERY_PATH, EVIDENCE_TEXT, EVIDENCE, ML_SCORE, ML_SCORE_TYPE, ML_METHOD, CALCULATION_RULE)
  WITH c AS (SELECT * FROM RR_CONFIG WHERE CONFIG_ID = 1),
  src AS (
    SELECT b.*, o.SHIPPED_DATE AS ORDER_SHIPPED_DATE, o.SHIP_STATUS AS ORDER_SHIP_STATUS,
           (UPPER(TRIM(b.RESOLVABLE_FLAG)) = 'Y'
            AND NOT (b.EXCEPTION_CODE ILIKE c.BILLING_NONRECOVERABLE_PATTERN)) AS IS_RECOVERABLE
    FROM FACT_BILLING b
    CROSS JOIN c
    LEFT JOIN FACT_ORDER o ON o.ORDER_ID = b.ORDER_ID
    WHERE NULLIF(TRIM(b.EXCEPTION_CODE), '') IS NOT NULL
      AND UPPER(TRIM(b.EXCEPTION_CODE)) NOT IN ('NONE', 'N/A', 'NA', 'NULL', '0')
      AND (b.BILLING_DATE IS NULL OR b.BILLING_DATE <= c.AS_OF_DATE)
      AND COALESCE(b.BILLING_STATUS, '') NOT ILIKE ANY ('%paid%', '%resolved%', '%cleared%', '%closed%')
      AND COALESCE(b.AMOUNT, 0) > 0
      AND (NOT COALESCE(c.BILLING_REQUIRE_SHIPPED, TRUE)
           OR (o.SHIPPED_DATE IS NOT NULL AND o.SHIPPED_DATE <= c.AS_OF_DATE))
  )
  SELECT 'BIL-' || s.BILLING_ID, 'BILLING', 'FACT_BILLING', s.BILLING_ID,
         s.CUSTOMER_ID, cu.CUSTOMER_NAME, s.PRODUCT_ID, p.PRODUCT_NAME, p.PRODUCT_FAMILY,
         cu.REGION_ID, cu.REGION_NAME,
         s.AMOUNT,
         IFF(s.IS_RECOVERABLE, s.AMOUNT, 0),
         IFF(s.IS_RECOVERABLE, 1, 0),
         'INVOICE', c.QTR_END, TRIM(s.EXCEPTION_CODE),
         IFF(s.IS_RECOVERABLE, 'Correct ' || TRIM(s.EXCEPTION_CODE) || ' and re-issue invoice ' || COALESCE(s.INVOICE_ID, s.BILLING_ID), NULL),
         'Invoice ' || COALESCE(s.INVOICE_ID, 'n/a') || ' (billing ' || s.BILLING_ID || ') for order ' || COALESCE(s.ORDER_ID, 'n/a')
           || ' shipped ' || COALESCE(TO_VARCHAR(s.ORDER_SHIPPED_DATE), 'n/a') || ' is held by exception ' || TRIM(s.EXCEPTION_CODE)
           || ' (billing status ' || COALESCE(s.BILLING_STATUS, 'n/a') || ', aging ' || COALESCE(TO_VARCHAR(s.AGING_DAYS), 'n/a')
           || ' days, resolvable flag ' || COALESCE(s.RESOLVABLE_FLAG, 'n/a') || ').'
           || IFF(s.IS_RECOVERABLE, ' Operationally resolvable before quarter-end.', ' Not auto-recoverable (commercial dispute or not resolvable).'),
         OBJECT_CONSTRUCT('invoice_id', s.INVOICE_ID, 'order_id', s.ORDER_ID, 'billing_date', s.BILLING_DATE,
                          'billing_status', s.BILLING_STATUS, 'aging_days', s.AGING_DAYS,
                          'resolvable_flag', s.RESOLVABLE_FLAG, 'order_shipped_date', s.ORDER_SHIPPED_DATE),
         NULL, NULL, NULL,
         'BILLING: FACT_BILLING.EXCEPTION_CODE present, billed on/before AS_OF_DATE, not paid/resolved'
           || IFF(COALESCE(c.BILLING_REQUIRE_SHIPPED, TRUE), ', order shipped on/before AS_OF_DATE', '')
           || '. AT_RISK = AMOUNT. RECOVERABLE = AMOUNT when RESOLVABLE_FLAG = Y and EXCEPTION_CODE not ILIKE '''
           || c.BILLING_NONRECOVERABLE_PATTERN || ''' (commercial disputes); otherwise 0.'
  FROM src s
  CROSS JOIN c
  LEFT JOIN DIM_CUSTOMER cu ON cu.CUSTOMER_ID = s.CUSTOMER_ID
  LEFT JOIN DIM_PRODUCT p   ON p.PRODUCT_ID = s.PRODUCT_ID;
  qid := SQLID;
  UPDATE RR_TMP_LEDGER_STAGE SET SOURCE_QUERY_ID = :qid WHERE CATEGORY = 'BILLING';

  -- 4d. RENEWAL: near-term renewals with usage decline / P1-P2 / other health evidence (ARR)
  INSERT INTO RR_TMP_LEDGER_STAGE (RISK_ITEM_ID, CATEGORY, SOURCE_TABLE, SOURCE_ID, CUSTOMER_ID, CUSTOMER_NAME,
    PRODUCT_ID, PRODUCT_NAME, PRODUCT_FAMILY, REGION_ID, REGION_NAME, AT_RISK_USD, RECOVERABLE_USD, RECOVERY_PROB,
    VALUE_BASIS, DUE_DATE, BLOCKER, RECOVERY_PATH, EVIDENCE_TEXT, EVIDENCE, ML_SCORE, ML_SCORE_TYPE, ML_METHOD, CALCULATION_RULE)
  WITH c AS (SELECT * FROM RR_CONFIG WHERE CONFIG_ID = 1),
  h AS (
    SELECT fh.* FROM FACT_CUSTOMER_HEALTH fh CROSS JOIN c
    WHERE fh.SNAPSHOT_DATE <= c.AS_OF_DATE
    QUALIFY ROW_NUMBER() OVER (PARTITION BY fh.CUSTOMER_ID ORDER BY fh.SNAPSHOT_DATE DESC, fh.HEALTH_ID DESC) = 1
  ),
  anom AS (
    SELECT CUSTOMER_ID, MAX(IFF(IS_ANOMALY AND DIRECTION = 'DOWN', ABS(ANOMALY_SCORE), NULL)) AS SCORE, ANY_VALUE(ML_METHOD) AS M
    FROM RR_ML_USAGE_ANOMALIES GROUP BY 1
  ),
  src AS (
    SELECT cu.CUSTOMER_ID, cu.CUSTOMER_NAME, cu.REGION_ID, cu.REGION_NAME, cu.RENEWAL_DATE,
           h.HEALTH_ID, h.SNAPSHOT_DATE, h.USAGE_CHANGE_PCT, h.OPEN_P1_P2, h.CSAT, h.RENEWAL_ARR,
           h.RENEWAL_PROBABILITY, h.RISK_REASON, h.RECOVERY_PROBABILITY,
           LEAST(GREATEST(IFF(h.RECOVERY_PROBABILITY > 1, h.RECOVERY_PROBABILITY / 100, h.RECOVERY_PROBABILITY), 0), 1) AS GOV_PROB,
           (h.USAGE_CHANGE_PCT <= c.RENEWAL_USAGE_DECLINE_PCT) AS T_USAGE,
           (h.OPEN_P1_P2 >= c.RENEWAL_MIN_OPEN_P1P2) AS T_SUPPORT,
           (COALESCE(c.RENEWAL_INCLUDE_RISK_REASON, FALSE) AND NULLIF(TRIM(h.RISK_REASON), '') IS NOT NULL) AS T_REASON
    FROM DIM_CUSTOMER cu
    JOIN h ON h.CUSTOMER_ID = cu.CUSTOMER_ID
    CROSS JOIN c
    WHERE cu.RENEWAL_DATE BETWEEN c.AS_OF_DATE
                              AND COALESCE(DATEADD(day, c.RENEWAL_WINDOW_DAYS, c.AS_OF_DATE), c.QTR_END)
      AND COALESCE(cu.ACTIVE_FLAG, TRUE)
      AND COALESCE(h.RENEWAL_ARR, 0) > 0
  )
  SELECT 'REN-' || s.CUSTOMER_ID, 'RENEWAL', 'DIM_CUSTOMER+FACT_CUSTOMER_HEALTH', s.CUSTOMER_ID,
         s.CUSTOMER_ID, s.CUSTOMER_NAME, NULL, NULL, NULL, s.REGION_ID, s.REGION_NAME,
         s.RENEWAL_ARR,
         ROUND(s.RENEWAL_ARR * COALESCE(s.GOV_PROB, 0), 2),
         s.GOV_PROB,
         'ARR', s.RENEWAL_DATE,
         COALESCE(NULLIF(TRIM(s.RISK_REASON), ''),
                  CASE WHEN s.T_USAGE AND s.T_SUPPORT THEN 'Usage decline with open P1/P2 escalations'
                       WHEN s.T_USAGE THEN 'Meaningful usage decline'
                       ELSE 'Open P1/P2 support escalations' END),
         NULL,
         'Renewal due ' || TO_VARCHAR(s.RENEWAL_DATE) || '. Latest health snapshot ' || TO_VARCHAR(s.SNAPSHOT_DATE)
           || ': usage change ' || COALESCE(TO_VARCHAR(s.USAGE_CHANGE_PCT), 'n/a') || '%, open P1/P2 '
           || COALESCE(TO_VARCHAR(s.OPEN_P1_P2), 'n/a') || ', CSAT ' || COALESCE(TO_VARCHAR(s.CSAT), 'n/a')
           || ', renewal probability ' || COALESCE(TO_VARCHAR(s.RENEWAL_PROBABILITY), 'n/a')
           || '. Triggers: ' || ARRAY_TO_STRING(ARRAY_CONSTRUCT_COMPACT(
                IFF(s.T_USAGE, 'usage decline', NULL), IFF(s.T_SUPPORT, 'P1/P2 escalations', NULL),
                IFF(s.T_REASON, 'health risk reason', NULL)), ', ') || '.',
         OBJECT_CONSTRUCT('health_id', s.HEALTH_ID, 'snapshot_date', s.SNAPSHOT_DATE, 'usage_change_pct', s.USAGE_CHANGE_PCT,
                          'open_p1_p2', s.OPEN_P1_P2, 'csat', s.CSAT, 'renewal_probability', s.RENEWAL_PROBABILITY,
                          'governed_recovery_prob', s.GOV_PROB, 'health_risk_reason', s.RISK_REASON),
         COALESCE(a.SCORE, 0), 'USAGE_ANOMALY_SCORE', a.M,
         'RENEWAL: DIM_CUSTOMER.RENEWAL_DATE from AS_OF_DATE through '
           || IFF(c.RENEWAL_WINDOW_DAYS IS NULL, 'QTR_END', 'AS_OF_DATE + ' || c.RENEWAL_WINDOW_DAYS || ' days')
           || '; latest health on/before AS_OF_DATE shows USAGE_CHANGE_PCT <= ' || c.RENEWAL_USAGE_DECLINE_PCT
           || ' OR OPEN_P1_P2 >= ' || c.RENEWAL_MIN_OPEN_P1P2
           || IFF(COALESCE(c.RENEWAL_INCLUDE_RISK_REASON, FALSE), ' OR health RISK_REASON present', '')
           || '. AT_RISK = RENEWAL_ARR (ARR, not recognized Q4 revenue). RECOVERABLE = ARR x governed RECOVERY_PROBABILITY.'
  FROM src s
  CROSS JOIN c
  LEFT JOIN anom a ON a.CUSTOMER_ID = s.CUSTOMER_ID
  WHERE s.T_USAGE OR s.T_SUPPORT OR s.T_REASON;
  qid := SQLID;
  UPDATE RR_TMP_LEDGER_STAGE SET SOURCE_QUERY_ID = :qid WHERE CATEGORY = 'RENEWAL';

  -- 4e. SUPPORT / EXPANSION: expansion endangered by poor support health
  INSERT INTO RR_TMP_LEDGER_STAGE (RISK_ITEM_ID, CATEGORY, SOURCE_TABLE, SOURCE_ID, CUSTOMER_ID, CUSTOMER_NAME,
    PRODUCT_ID, PRODUCT_NAME, PRODUCT_FAMILY, REGION_ID, REGION_NAME, AT_RISK_USD, RECOVERABLE_USD, RECOVERY_PROB,
    VALUE_BASIS, DUE_DATE, BLOCKER, RECOVERY_PATH, EVIDENCE_TEXT, EVIDENCE, ML_SCORE, ML_SCORE_TYPE, ML_METHOD, CALCULATION_RULE)
  WITH c AS (SELECT * FROM RR_CONFIG WHERE CONFIG_ID = 1),
  h AS (
    SELECT fh.* FROM FACT_CUSTOMER_HEALTH fh CROSS JOIN c
    WHERE fh.SNAPSHOT_DATE <= c.AS_OF_DATE
    QUALIFY ROW_NUMBER() OVER (PARTITION BY fh.CUSTOMER_ID ORDER BY fh.SNAPSHOT_DATE DESC, fh.HEALTH_ID DESC) = 1
  ),
  anom AS (
    SELECT CUSTOMER_ID, MAX(IFF(IS_ANOMALY AND DIRECTION = 'DOWN', ABS(ANOMALY_SCORE), NULL)) AS SCORE, ANY_VALUE(ML_METHOD) AS M
    FROM RR_ML_USAGE_ANOMALIES GROUP BY 1
  )
  SELECT 'SUP-' || h.CUSTOMER_ID, 'SUPPORT_EXPANSION', 'FACT_CUSTOMER_HEALTH', h.CUSTOMER_ID,
         h.CUSTOMER_ID, cu.CUSTOMER_NAME, NULL, NULL, NULL, cu.REGION_ID, cu.REGION_NAME,
         h.AT_RISK_EXPANSION_VALUE,
         ROUND(h.AT_RISK_EXPANSION_VALUE
               * COALESCE(LEAST(GREATEST(IFF(h.SUPPORT_RECOVERY_PROBABILITY > 1, h.SUPPORT_RECOVERY_PROBABILITY / 100, h.SUPPORT_RECOVERY_PROBABILITY), 0), 1), 0), 2),
         LEAST(GREATEST(IFF(h.SUPPORT_RECOVERY_PROBABILITY > 1, h.SUPPORT_RECOVERY_PROBABILITY / 100, h.SUPPORT_RECOVERY_PROBABILITY), 0), 1),
         'EXPANSION', c.QTR_END,
         COALESCE(NULLIF(TRIM(h.RISK_REASON), ''), 'Poor support health (low CSAT with open P1/P2 escalations)'),
         NULL,
         'Expansion opportunity endangered by support health. Latest health snapshot ' || TO_VARCHAR(h.SNAPSHOT_DATE)
           || ': CSAT ' || TO_VARCHAR(h.CSAT) || ' (threshold ' || TO_VARCHAR(c.SUPPORT_MAX_CSAT) || '), open P1/P2 '
           || TO_VARCHAR(h.OPEN_P1_P2) || ', usage change ' || COALESCE(TO_VARCHAR(h.USAGE_CHANGE_PCT), 'n/a') || '%.',
         OBJECT_CONSTRUCT('health_id', h.HEALTH_ID, 'snapshot_date', h.SNAPSHOT_DATE, 'csat', h.CSAT,
                          'open_p1_p2', h.OPEN_P1_P2, 'usage_change_pct', h.USAGE_CHANGE_PCT,
                          'support_recovery_probability', h.SUPPORT_RECOVERY_PROBABILITY, 'health_risk_reason', h.RISK_REASON),
         COALESCE(a.SCORE, 0), 'USAGE_ANOMALY_SCORE', a.M,
         'SUPPORT_EXPANSION: latest health on/before AS_OF_DATE with AT_RISK_EXPANSION_VALUE > 0, CSAT <= SUPPORT_MAX_CSAT ('
           || TO_VARCHAR(c.SUPPORT_MAX_CSAT) || ') and OPEN_P1_P2 >= ' || c.SUPPORT_MIN_OPEN_P1P2
           || '. AT_RISK = AT_RISK_EXPANSION_VALUE. RECOVERABLE = value x governed SUPPORT_RECOVERY_PROBABILITY.'
  FROM h
  CROSS JOIN c
  LEFT JOIN DIM_CUSTOMER cu ON cu.CUSTOMER_ID = h.CUSTOMER_ID
  LEFT JOIN anom a ON a.CUSTOMER_ID = h.CUSTOMER_ID
  WHERE COALESCE(h.AT_RISK_EXPANSION_VALUE, 0) > 0
    AND h.CSAT <= c.SUPPORT_MAX_CSAT
    AND COALESCE(h.OPEN_P1_P2, 0) >= c.SUPPORT_MIN_OPEN_P1P2
    AND COALESCE(cu.ACTIVE_FLAG, TRUE);
  qid := SQLID;
  UPDATE RR_TMP_LEDGER_STAGE SET SOURCE_QUERY_ID = :qid WHERE CATEGORY = 'SUPPORT_EXPANSION';

  -- -------------------------------------------------------------------------
  -- 5. Duplicate guard, hashing, MERGE with change tracking
  -- -------------------------------------------------------------------------
  SELECT COUNT(*) - COUNT(DISTINCT RISK_ITEM_ID) INTO :dup_count FROM RR_TMP_LEDGER_STAGE;
  IF (dup_count > 0) THEN RAISE duplicate_items; END IF;

  UPDATE RR_TMP_LEDGER_STAGE SET
    ROW_HASH = RR_LEDGER_ROW_HASH(CATEGORY, SOURCE_ID, CUSTOMER_ID, PRODUCT_ID, AT_RISK_USD, RECOVERABLE_USD,
                                  RECOVERY_PROB, DUE_DATE, BLOCKER, RECOVERY_PATH, EVIDENCE_TEXT),
    AI_INPUT_HASH = SHA2(CONCAT_WS('|', CATEGORY, COALESCE(BLOCKER, ''), COALESCE(RECOVERY_PATH, ''),
                                   COALESCE(EVIDENCE_TEXT, ''),
                                   COALESCE(TO_VARCHAR(ROUND(AT_RISK_USD, -3)), ''),
                                   COALESCE(TO_VARCHAR(ROUND(RECOVERABLE_USD, -3)), ''),
                                   COALESCE(TO_VARCHAR(ROUND(RECOVERY_PROB, 2)), ''),
                                   COALESCE(TO_VARCHAR(ROUND(ML_SCORE, 1)), '')), 256);

  MERGE INTO RR_RISK_LEDGER t
  USING RR_TMP_LEDGER_STAGE s
     ON t.RISK_ITEM_ID = s.RISK_ITEM_ID
  WHEN MATCHED THEN UPDATE SET
    t.CHANGE_STATUS        = CASE WHEN NOT COALESCE(t.ACTIVE_FLAG, FALSE) THEN 'REOPENED'
                                  WHEN t.ROW_HASH = s.ROW_HASH THEN 'UNCHANGED' ELSE 'CHANGED' END,
    t.PREV_ROW_HASH        = t.ROW_HASH,
    t.PREV_AT_RISK_USD     = t.AT_RISK_USD,
    t.PREV_RECOVERABLE_USD = t.RECOVERABLE_USD,
    t.CATEGORY = s.CATEGORY, t.SOURCE_TABLE = s.SOURCE_TABLE, t.SOURCE_ID = s.SOURCE_ID,
    t.CUSTOMER_ID = s.CUSTOMER_ID, t.CUSTOMER_NAME = s.CUSTOMER_NAME,
    t.PRODUCT_ID = s.PRODUCT_ID, t.PRODUCT_NAME = s.PRODUCT_NAME, t.PRODUCT_FAMILY = s.PRODUCT_FAMILY,
    t.REGION_ID = s.REGION_ID, t.REGION_NAME = s.REGION_NAME,
    t.AT_RISK_USD = s.AT_RISK_USD, t.RECOVERABLE_USD = s.RECOVERABLE_USD,
    t.NO_PATH_USD = s.AT_RISK_USD - s.RECOVERABLE_USD, t.RECOVERY_PROB = s.RECOVERY_PROB,
    t.Q4_REVENUE_IMPACT = s.RECOVERABLE_USD, t.VALUE_BASIS = s.VALUE_BASIS,
    t.DUE_DATE = s.DUE_DATE, t.DAYS_TO_DUE = DATEDIFF(day, :as_of, s.DUE_DATE),
    t.BLOCKER = s.BLOCKER, t.RECOVERY_PATH = s.RECOVERY_PATH,
    t.EVIDENCE_TEXT = s.EVIDENCE_TEXT, t.EVIDENCE = s.EVIDENCE,
    t.ML_SCORE = s.ML_SCORE, t.ML_SCORE_TYPE = s.ML_SCORE_TYPE, t.ML_METHOD = s.ML_METHOD,
    t.ML_GOVERNED_DELTA = IFF(s.ML_SCORE_TYPE = 'WIN_PROBABILITY', ROUND(s.ML_SCORE - s.RECOVERY_PROB, 4), NULL),
    t.CALCULATION_RULE = s.CALCULATION_RULE, t.SOURCE_QUERY_ID = s.SOURCE_QUERY_ID,
    t.ROW_HASH = s.ROW_HASH, t.AI_INPUT_HASH = s.AI_INPUT_HASH,
    t.AS_OF_DATE = :as_of, t.ACTIVE_FLAG = TRUE, t.REFRESH_ID = :run_id,
    t.REFRESHED_AT = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
  WHEN NOT MATCHED THEN INSERT (
    RISK_ITEM_ID, CATEGORY, SOURCE_TABLE, SOURCE_ID, CUSTOMER_ID, CUSTOMER_NAME, PRODUCT_ID, PRODUCT_NAME, PRODUCT_FAMILY,
    REGION_ID, REGION_NAME, AT_RISK_USD, RECOVERABLE_USD, NO_PATH_USD, RECOVERY_PROB, Q4_REVENUE_IMPACT, VALUE_BASIS,
    DUE_DATE, DAYS_TO_DUE, BLOCKER, RECOVERY_PATH, EVIDENCE_TEXT, EVIDENCE, ML_SCORE, ML_SCORE_TYPE, ML_METHOD,
    ML_GOVERNED_DELTA, CALCULATION_RULE, SOURCE_QUERY_ID, ROW_HASH, AI_INPUT_HASH, CHANGE_STATUS,
    AS_OF_DATE, ACTIVE_FLAG, FIRST_SEEN_AT, REFRESH_ID, REFRESHED_AT)
  VALUES (
    s.RISK_ITEM_ID, s.CATEGORY, s.SOURCE_TABLE, s.SOURCE_ID, s.CUSTOMER_ID, s.CUSTOMER_NAME, s.PRODUCT_ID, s.PRODUCT_NAME, s.PRODUCT_FAMILY,
    s.REGION_ID, s.REGION_NAME, s.AT_RISK_USD, s.RECOVERABLE_USD, s.AT_RISK_USD - s.RECOVERABLE_USD, s.RECOVERY_PROB,
    s.RECOVERABLE_USD, s.VALUE_BASIS, s.DUE_DATE, DATEDIFF(day, :as_of, s.DUE_DATE), s.BLOCKER, s.RECOVERY_PATH,
    s.EVIDENCE_TEXT, s.EVIDENCE, s.ML_SCORE, s.ML_SCORE_TYPE, s.ML_METHOD,
    IFF(s.ML_SCORE_TYPE = 'WIN_PROBABILITY', ROUND(s.ML_SCORE - s.RECOVERY_PROB, 4), NULL),
    s.CALCULATION_RULE, s.SOURCE_QUERY_ID, s.ROW_HASH, s.AI_INPUT_HASH, 'NEW',
    :as_of, TRUE, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, :run_id, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ);

  -- items resolved in an earlier refresh are now simply INACTIVE
  UPDATE RR_RISK_LEDGER SET CHANGE_STATUS = 'INACTIVE'
   WHERE ACTIVE_FLAG = FALSE AND CHANGE_STATUS = 'RESOLVED';

  -- items no longer produced by any rule are RESOLVED in this refresh
  UPDATE RR_RISK_LEDGER
     SET ACTIVE_FLAG = FALSE, CHANGE_STATUS = 'RESOLVED',
         PREV_ROW_HASH = ROW_HASH, PREV_AT_RISK_USD = AT_RISK_USD, PREV_RECOVERABLE_USD = RECOVERABLE_USD,
         REFRESH_ID = :run_id, REFRESHED_AT = CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
   WHERE ACTIVE_FLAG = TRUE
     AND RISK_ITEM_ID NOT IN (SELECT RISK_ITEM_ID FROM RR_TMP_LEDGER_STAGE);

  -- -------------------------------------------------------------------------
  -- 6a. Opportunity 360 (governed vs ML probability)
  -- -------------------------------------------------------------------------
  INSERT OVERWRITE INTO RR_OPPORTUNITY_360
  WITH c AS (SELECT * FROM RR_CONFIG WHERE CONFIG_ID = 1),
  rgn AS (SELECT REGION_ID, ANY_VALUE(REGION_NAME) AS REGION_NAME FROM DIM_CUSTOMER GROUP BY 1),
  o AS (
    SELECT fo.*,
           LEAST(GREATEST(IFF(fo.RECOVERY_PROBABILITY > 1, fo.RECOVERY_PROBABILITY / 100, fo.RECOVERY_PROBABILITY), 0), 1) AS GOV_PROB
    FROM FACT_OPPORTUNITY fo CROSS JOIN c
    WHERE (fo.ACTUAL_CLOSE_DATE IS NULL OR fo.ACTUAL_CLOSE_DATE > c.AS_OF_DATE)
      AND (fo.CREATED_DATE IS NULL OR fo.CREATED_DATE <= c.AS_OF_DATE)
  )
  SELECT o.OPPORTUNITY_ID, o.OPPORTUNITY_NAME, o.CUSTOMER_ID, cu.CUSTOMER_NAME, o.PRODUCT_ID, p.PRODUCT_FAMILY,
         COALESCE(o.REGION_ID, cu.REGION_ID), COALESCE(r.REGION_NAME, cu.REGION_NAME),
         o.STAGE_NAME, o.FORECAST_CATEGORY, o.OPPORTUNITY_STATUS, o.OPPORTUNITY_AMOUNT, o.PROBABILITY_PERCENT,
         o.EXPECTED_CLOSE_DATE, COALESCE(o.EXPECTED_CLOSE_DATE BETWEEN c.QTR_START AND c.QTR_END, FALSE),
         o.DAYS_IN_STAGE, o.RISK_REASON,
         o.GOV_PROB, ds.ML_WIN_PROB, ds.ML_METHOD,
         ROUND(ds.ML_WIN_PROB - o.GOV_PROB, 4),
         COALESCE(ABS(ds.ML_WIN_PROB - o.GOV_PROB) >= c.ML_DISAGREEMENT_THRESHOLD, FALSE),
         (l.RISK_ITEM_ID IS NOT NULL),
         c.AS_OF_DATE, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
  FROM o
  CROSS JOIN c
  LEFT JOIN DIM_CUSTOMER cu ON cu.CUSTOMER_ID = o.CUSTOMER_ID
  LEFT JOIN DIM_PRODUCT p   ON p.PRODUCT_ID = o.PRODUCT_ID
  LEFT JOIN rgn r           ON r.REGION_ID = COALESCE(o.REGION_ID, cu.REGION_ID)
  LEFT JOIN RR_ML_DEAL_SCORES ds ON ds.OPPORTUNITY_ID = o.OPPORTUNITY_ID
  LEFT JOIN RR_RISK_LEDGER l ON l.RISK_ITEM_ID = 'PIPE-' || o.OPPORTUNITY_ID AND l.ACTIVE_FLAG;

  -- -------------------------------------------------------------------------
  -- 6b. Customer 360
  -- -------------------------------------------------------------------------
  INSERT OVERWRITE INTO RR_CUSTOMER_360
  WITH c AS (SELECT * FROM RR_CONFIG WHERE CONFIG_ID = 1),
  hw AS (
    SELECT h.*, ROW_NUMBER() OVER (PARTITION BY h.CUSTOMER_ID ORDER BY h.SNAPSHOT_DATE DESC, h.HEALTH_ID DESC) AS RN
    FROM FACT_CUSTOMER_HEALTH h CROSS JOIN c
    WHERE h.SNAPSHOT_DATE <= c.AS_OF_DATE
  ),
  latest AS (SELECT * FROM hw WHERE RN = 1),
  trend AS (
    SELECT CUSTOMER_ID,
           AVG(IFF(RN <= 4, USAGE_CHANGE_PCT, NULL))          AS U4,
           AVG(IFF(RN BETWEEN 5 AND 12, USAGE_CHANGE_PCT, NULL)) AS U8,
           AVG(IFF(RN BETWEEN 5 AND 12, CSAT, NULL))           AS C8
    FROM hw WHERE RN <= 12 GROUP BY 1
  ),
  anom AS (
    SELECT CUSTOMER_ID,
           BOOLOR_AGG(COALESCE(IS_ANOMALY, FALSE) AND DIRECTION = 'DOWN') AS FLAG,
           MAX(IFF(IS_ANOMALY AND DIRECTION = 'DOWN', ABS(ANOMALY_SCORE), NULL)) AS SCORE,
           ANY_VALUE(ML_METHOD) AS M
    FROM RR_ML_USAGE_ANOMALIES GROUP BY 1
  ),
  pipe AS (
    SELECT o.CUSTOMER_ID, SUM(o.OPPORTUNITY_AMOUNT) AS V
    FROM FACT_OPPORTUNITY o CROSS JOIN c
    WHERE (o.ACTUAL_CLOSE_DATE IS NULL OR o.ACTUAL_CLOSE_DATE > c.AS_OF_DATE)
      AND (o.CREATED_DATE IS NULL OR o.CREATED_DATE <= c.AS_OF_DATE)
    GROUP BY 1
  ),
  led AS (
    SELECT CUSTOMER_ID,
           SUM(AT_RISK_USD) AS AR, SUM(RECOVERABLE_USD) AS RC, COUNT(*) AS N,
           SUM(IFF(CATEGORY = 'FULFILLMENT', AT_RISK_USD, 0)) AS BLK,
           SUM(IFF(CATEGORY = 'BILLING', AT_RISK_USD, 0)) AS BIL
    FROM RR_RISK_LEDGER WHERE ACTIVE_FLAG GROUP BY 1
  )
  SELECT cu.CUSTOMER_ID, cu.CUSTOMER_NAME, cu.SEGMENT, cu.INDUSTRY, cu.REGION_ID, cu.REGION_NAME, cu.TIER,
         cu.ACTIVE_FLAG, cu.RENEWAL_DATE, DATEDIFF(day, c.AS_OF_DATE, cu.RENEWAL_DATE),
         COALESCE(cu.RENEWAL_DATE BETWEEN c.QTR_START AND c.QTR_END, FALSE),
         lt.SNAPSHOT_DATE, lt.USAGE_CHANGE_PCT, ROUND(t.U4, 4), ROUND(t.U8, 4), lt.CSAT, ROUND(t.C8, 2), lt.OPEN_P1_P2,
         lt.RENEWAL_ARR, lt.RENEWAL_PROBABILITY, lt.RISK_REASON, lt.AT_RISK_EXPANSION_VALUE,
         COALESCE(t.U4 < t.U8 AND (lt.CSAT < t.C8 OR lt.OPEN_P1_P2 > 0), FALSE),
         COALESCE(a.FLAG, FALSE), a.SCORE, a.M,
         COALESCE(pp.V, 0), COALESCE(l.BLK, 0), COALESCE(l.BIL, 0),
         COALESCE(l.AR, 0), COALESCE(l.RC, 0), COALESCE(l.N, 0),
         c.AS_OF_DATE, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
  FROM DIM_CUSTOMER cu
  CROSS JOIN c
  LEFT JOIN latest lt ON lt.CUSTOMER_ID = cu.CUSTOMER_ID
  LEFT JOIN trend t   ON t.CUSTOMER_ID = cu.CUSTOMER_ID
  LEFT JOIN anom a    ON a.CUSTOMER_ID = cu.CUSTOMER_ID
  LEFT JOIN pipe pp   ON pp.CUSTOMER_ID = cu.CUSTOMER_ID
  LEFT JOIN led l     ON l.CUSTOMER_ID = cu.CUSTOMER_ID;

  -- -------------------------------------------------------------------------
  -- 7. Revenue outlook (authoritative executive row)
  -- -------------------------------------------------------------------------
  INSERT OVERWRITE INTO RR_REVENUE_OUTLOOK
  WITH c AS (SELECT * FROM RR_CONFIG WHERE CONFIG_ID = 1),
  plan AS (
    SELECT SUM(p.TARGET_REVENUE) AS T, SUM(p.FORECAST_REVENUE) AS F, SUM(p.ACTUAL_REVENUE) AS A,
           LISTAGG(DISTINCT p.SCENARIO_ID, ',') AS S
    FROM FACT_REVENUE_PLAN p CROSS JOIN c
    WHERE p.PERIOD_MONTH BETWEEN c.QTR_START AND c.QTR_END
      AND (c.PLAN_SCENARIO_ID IS NULL OR p.SCENARIO_ID = c.PLAN_SCENARIO_ID)
  ),
  led AS (
    SELECT COALESCE(SUM(l.AT_RISK_USD), 0) AS GR, COALESCE(SUM(l.RECOVERABLE_USD), 0) AS MR,
           COALESCE(SUM(l.NO_PATH_USD), 0) AS NP, COUNT(*) AS N,
           COALESCE(SUM(IFF(l.CATEGORY = 'PIPELINE', l.AT_RISK_USD, 0)), 0)              AS PA,
           COALESCE(SUM(IFF(l.CATEGORY = 'PIPELINE', l.RECOVERABLE_USD, 0)), 0)          AS PR,
           COALESCE(SUM(IFF(l.CATEGORY = 'FULFILLMENT', l.AT_RISK_USD, 0)), 0)           AS FA,
           COALESCE(SUM(IFF(l.CATEGORY = 'FULFILLMENT', l.RECOVERABLE_USD, 0)), 0)       AS FR,
           COALESCE(SUM(IFF(l.CATEGORY = 'BILLING', l.AT_RISK_USD, 0)), 0)               AS BA,
           COALESCE(SUM(IFF(l.CATEGORY = 'BILLING', l.RECOVERABLE_USD, 0)), 0)           AS BR,
           COALESCE(SUM(IFF(l.CATEGORY = 'RENEWAL', l.AT_RISK_USD, 0)), 0)               AS RA,
           COALESCE(SUM(IFF(l.CATEGORY = 'RENEWAL', l.RECOVERABLE_USD, 0)), 0)           AS RR,
           COALESCE(SUM(IFF(l.CATEGORY = 'SUPPORT_EXPANSION', l.AT_RISK_USD, 0)), 0)     AS SA,
           COALESCE(SUM(IFF(l.CATEGORY = 'SUPPORT_EXPANSION', l.RECOVERABLE_USD, 0)), 0) AS SR,
           COALESCE(SUM(IFF(POSITION(',' || l.CATEGORY || ',' IN ',' || REPLACE(c.BASE_RECOVERY_CATEGORIES, ' ', '') || ',') > 0,
                            l.Q4_REVENUE_IMPACT, 0)), 0) AS BASE_REC,
           COALESCE(SUM(l.Q4_REVENUE_IMPACT), 0) AS UPSIDE_REC
    FROM RR_RISK_LEDGER l CROSS JOIN c
    WHERE l.ACTIVE_FLAG
  ),
  mlrev AS (
    SELECT SUM(IFF(ROW_TYPE = 'ACTUAL', VALUE_USD, 0)) AS TD, SUM(VALUE_USD) AS PROJ,
           LISTAGG(DISTINCT IFF(ROW_TYPE = 'FORECAST', ML_METHOD, NULL), ',') AS M
    FROM RR_ML_REVENUE_FORECAST
  )
  SELECT 'Q4-' || TO_VARCHAR(c.QTR_START, 'YYYY') || '-OUTLOOK', c.AS_OF_DATE, c.QTR_START, c.QTR_END, plan.S,
         plan.T, plan.F, plan.T - plan.F, plan.A,
         led.GR, led.MR, led.NP,
         led.PA, led.PR, led.FA, led.FR, led.BA, led.BR, led.RA, led.RR, led.SA, led.SR,
         c.BASE_RECOVERY_CATEGORIES,
         led.BASE_REC, plan.F + led.BASE_REC, plan.T - (plan.F + led.BASE_REC),
         led.UPSIDE_REC, plan.F + led.UPSIDE_REC, plan.T - (plan.F + led.UPSIDE_REC),
         mlrev.TD, mlrev.PROJ, mlrev.M,
         led.N,
         'Gross revenue at risk is operational exposure across five mechanisms; it is NOT the forecast gap and part of it may '
           || 'already be reflected in the current forecast. Base Revised Outlook (governed base: ' || c.BASE_RECOVERY_CATEGORIES
           || ') and Upside Recovery Case (all five categories) are illustrative scenarios that assume the modeled recovery is '
           || 'incremental to the forecast; neither is a guaranteed forecast. Renewal values are ARR, not recognized Q4 revenue.',
         :run_id, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
  FROM plan CROSS JOIN led CROSS JOIN mlrev CROSS JOIN c;

  -- -------------------------------------------------------------------------
  -- 8. Audit + summary
  -- -------------------------------------------------------------------------
  SELECT OBJECT_CONSTRUCT(
           'run_id', :run_id,
           'as_of_date', :as_of,
           'second_opinion', :so_result,
           'allocation', :alloc_result,
           'outlook', (SELECT OBJECT_CONSTRUCT(
                          'q4_target_usd', Q4_TARGET_USD, 'q4_forecast_usd', Q4_FORECAST_USD, 'forecast_gap_usd', FORECAST_GAP_USD,
                          'gross_at_risk_usd', GROSS_AT_RISK_USD, 'modeled_recoverable_usd', MODELED_RECOVERABLE_USD,
                          'base_recovery_usd', BASE_RECOVERY_USD, 'base_revised_outlook_usd', BASE_REVISED_OUTLOOK_USD,
                          'base_remaining_gap_usd', BASE_REMAINING_GAP_USD, 'upside_outlook_usd', UPSIDE_OUTLOOK_USD,
                          'upside_remaining_gap_usd', UPSIDE_REMAINING_GAP_USD)
                       FROM RR_REVENUE_OUTLOOK),
           'categories', (SELECT OBJECT_AGG(CATEGORY, OBJECT_CONSTRUCT('items', N, 'at_risk_usd', AR, 'recoverable_usd', RC)::VARIANT)
                          FROM (SELECT CATEGORY, COUNT(*) AS N, SUM(AT_RISK_USD) AS AR, SUM(RECOVERABLE_USD) AS RC
                                  FROM RR_RISK_LEDGER WHERE ACTIVE_FLAG GROUP BY 1)),
           'changes', (SELECT OBJECT_AGG(CHANGE_STATUS, N::VARIANT)
                       FROM (SELECT CHANGE_STATUS, COUNT(*) AS N FROM RR_RISK_LEDGER
                              WHERE REFRESH_ID = :run_id GROUP BY 1)),
           'ai_pending', (SELECT COUNT(*) FROM RR_RISK_LEDGER
                           WHERE ACTIVE_FLAG AND AI_ENRICHED_HASH IS DISTINCT FROM AI_INPUT_HASH))
    INTO :summary;

  INSERT INTO RR_REFRESH_AUDIT (RUN_ID, STAGE, STATUS, STARTED_AT, ENDED_AT, AS_OF_DATE, ROWS_AFFECTED, DETAILS, RUN_BY)
  SELECT :run_id, 'REFRESH', 'SUCCESS', :started_at, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, :as_of,
         (SELECT COUNT(*) FROM RR_RISK_LEDGER WHERE ACTIVE_FLAG), :summary, CURRENT_USER();

  RETURN summary;

EXCEPTION
  WHEN OTHER THEN
    err_code := SQLCODE;
    err_msg := SQLERRM;
    err_state := SQLSTATE;
    INSERT INTO RR_REFRESH_AUDIT (RUN_ID, STAGE, STATUS, STARTED_AT, ENDED_AT, AS_OF_DATE, ROWS_AFFECTED, DETAILS, RUN_BY)
    SELECT :run_id, 'REFRESH', 'FAILED', :started_at, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, :as_of, 0,
           OBJECT_CONSTRUCT('sqlcode', :err_code, 'sqlerrm', :err_msg, 'sqlstate', :err_state), CURRENT_USER();
    RAISE;
END;
$$;

-- ===========================================================================
-- EXECUTE
-- ===========================================================================
CALL SP_REFRESH_REVENUE_DECISION_LAYER();

-- Category reconciliation preview ($M)
SELECT CATEGORY, COUNT(*) AS ITEMS,
       ROUND(SUM(AT_RISK_USD)/1e6, 2)     AS AT_RISK_M,
       ROUND(SUM(RECOVERABLE_USD)/1e6, 2) AS RECOVERABLE_M
FROM RR_RISK_LEDGER WHERE ACTIVE_FLAG
GROUP BY ROLLUP (CATEGORY) ORDER BY CATEGORY NULLS LAST;

SELECT * FROM RR_REVENUE_OUTLOOK;
SELECT * FROM RR_FULFILLMENT_ALLOCATION ORDER BY ALLOCATION_SEQ;
