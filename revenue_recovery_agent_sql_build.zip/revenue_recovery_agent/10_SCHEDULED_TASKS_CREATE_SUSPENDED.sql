/* =============================================================================
   10_SCHEDULED_TASKS_CREATE_SUSPENDED.sql
   Run ONLY after 09 validation, 11 smoke test and 13 agent tests have passed.

   TASK_RR_REFRESH          deterministic calculation (incl. ML second opinion)
        -> TASK_RR_AI_ENRICH        Cortex AI on CHANGED rows only
             -> TASK_RR_PROPOSE_ACTIONS  trust-gated action proposals (never approvals)

   Tasks are created SUSPENDED (Snowflake default). SP_ENABLE_RR_TASKS resumes
   them only if the latest validation, smoke test and trust check passed AND a
   human confirms the agent tests were reviewed.
   ============================================================================= */

USE DATABASE HACKATHON_REVENUE_RISK;
USE SCHEMA SOLUTION;
USE WAREHOUSE RR_WH;

CREATE OR REPLACE TASK TASK_RR_REFRESH
  WAREHOUSE = RR_WH
  SCHEDULE  = 'USING CRON 0 6 * * MON-FRI America/Los_Angeles'
  COMMENT   = 'Revenue Recovery: deterministic refresh of 360 tables, risk ledger and revenue outlook.'
AS
  CALL SP_REFRESH_REVENUE_DECISION_LAYER();

CREATE OR REPLACE TASK TASK_RR_AI_ENRICH
  WAREHOUSE = RR_WH
  COMMENT   = 'Revenue Recovery: incremental Cortex AI enrichment (changed rows only).'
  AFTER TASK_RR_REFRESH
AS
  CALL SP_ENRICH_REVENUE_RISKS_AI(200);

CREATE OR REPLACE TASK TASK_RR_PROPOSE_ACTIONS
  WAREHOUSE = RR_WH
  COMMENT   = 'Revenue Recovery: trust-gated proposal of top recovery actions (humans approve).'
  AFTER TASK_RR_AI_ENRICH
AS
  CALL SP_PROPOSE_TOP_RECOVERY_ACTIONS(10);

-- All three must show STATE = suspended
SHOW TASKS LIKE 'TASK_RR_%' IN SCHEMA HACKATHON_REVENUE_RISK.SOLUTION;

-- ---------------------------------------------------------------------------
-- Guarded enablement
-- ---------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE SP_ENABLE_RR_TASKS(P_AGENT_TESTS_SIGNED_OFF BOOLEAN)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
COMMENT = 'Resumes the Revenue Recovery task graph only when validation, smoke test and trust all passed and agent tests were signed off.'
AS
$$
DECLARE
  v_status VARCHAR;
  s_status VARCHAR;
  t_status VARCHAR;
  not_ready EXCEPTION (-20501, 'Tasks NOT enabled: latest validation / smoke test / trust check did not pass, or agent tests were not signed off.');
BEGIN
  SELECT MAX_BY(STATUS, ENDED_AT) INTO :v_status FROM RR_REFRESH_AUDIT WHERE STAGE = 'VALIDATION';
  SELECT MAX_BY(STATUS, ENDED_AT) INTO :s_status FROM RR_REFRESH_AUDIT WHERE STAGE = 'SMOKE_TEST';
  SELECT MAX_BY(STATUS, ENDED_AT) INTO :t_status FROM RR_REFRESH_AUDIT WHERE STAGE = 'TRUST';
  IF (NOT COALESCE(P_AGENT_TESTS_SIGNED_OFF, FALSE)
      OR COALESCE(v_status, 'NONE') <> 'SUCCESS'
      OR COALESCE(s_status, 'NONE') <> 'SUCCESS'
      OR COALESCE(t_status, 'NONE') <> 'PASS') THEN
    RAISE not_ready;
  END IF;

  -- children first, root last
  ALTER TASK TASK_RR_PROPOSE_ACTIONS RESUME;
  ALTER TASK TASK_RR_AI_ENRICH RESUME;
  ALTER TASK TASK_RR_REFRESH RESUME;

  INSERT INTO RR_REFRESH_AUDIT (RUN_ID, STAGE, STATUS, STARTED_AT, ENDED_AT, AS_OF_DATE, ROWS_AFFECTED, DETAILS, RUN_BY)
  SELECT 'TK-' || TO_VARCHAR(CURRENT_TIMESTAMP(), 'YYYYMMDDHH24MISSFF3'), 'TASKS_ENABLED', 'SUCCESS',
         CURRENT_TIMESTAMP()::TIMESTAMP_NTZ, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ,
         (SELECT AS_OF_DATE FROM RR_CONFIG WHERE CONFIG_ID = 1), 3,
         OBJECT_CONSTRUCT('validation', :v_status, 'smoke_test', :s_status, 'trust', :t_status), CURRENT_USER();
  RETURN 'TASKS RESUMED: TASK_RR_REFRESH -> TASK_RR_AI_ENRICH -> TASK_RR_PROPOSE_ACTIONS';
END;
$$;

-- ===========================================================================
-- EXPLICIT ENABLEMENT (run deliberately, after reviewing 13_AGENT_TESTS.sql output)
-- ===========================================================================
-- CALL SP_ENABLE_RR_TASKS(TRUE);
-- EXECUTE TASK TASK_RR_REFRESH;          -- optional immediate run of the whole graph
-- SHOW TASKS LIKE 'TASK_RR_%';
-- SELECT * FROM TABLE(INFORMATION_SCHEMA.TASK_HISTORY()) WHERE NAME LIKE 'TASK_RR_%' ORDER BY SCHEDULED_TIME DESC;

-- To pause:
-- ALTER TASK TASK_RR_REFRESH SUSPEND;
