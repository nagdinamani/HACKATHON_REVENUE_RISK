/* =============================================================================
   04_DECISION_LAYER_OBJECTS.sql
   Compute Once -> Query Many. Persisted decision tables (no views):

     RR_CUSTOMER_360           one row per customer: health, trend, ML anomaly, exposure
     RR_OPPORTUNITY_360        one row per open opportunity: governed vs ML probability
     RR_PRODUCT_INVENTORY_360  one row per product x warehouse: availability, allocation, demand
     RR_FULFILLMENT_ALLOCATION inventory-optimiser decision per blocked priority order
     RR_RISK_LEDGER            THE governed decision artifact (one row per risk item)
     RR_REVENUE_OUTLOOK        authoritative executive position (single current row)

   Plus SP_ALLOCATE_ALTERNATE_INVENTORY (Python): greedy, non-double-counting
   allocation of alternate same-product inventory to blocked priority orders.
   ============================================================================= */

USE DATABASE HACKATHON_REVENUE_RISK;
USE SCHEMA SOLUTION;
USE WAREHOUSE RR_WH;

-- ---------------------------------------------------------------------------
-- RR_CUSTOMER_360
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS RR_CUSTOMER_360 (
  CUSTOMER_ID                VARCHAR NOT NULL,
  CUSTOMER_NAME              VARCHAR,
  SEGMENT                    VARCHAR,
  INDUSTRY                   VARCHAR,
  REGION_ID                  VARCHAR,
  REGION_NAME                VARCHAR,
  TIER                       VARCHAR,
  CUSTOMER_ACTIVE_FLAG       BOOLEAN,
  RENEWAL_DATE               DATE,
  DAYS_TO_RENEWAL            NUMBER,
  RENEWAL_IN_Q4              BOOLEAN,
  LATEST_HEALTH_DATE         DATE,
  USAGE_CHANGE_PCT           NUMBER(10,4),
  USAGE_AVG_LAST_4W          NUMBER(10,4),
  USAGE_AVG_PRIOR_8W         NUMBER(10,4),
  CSAT                       NUMBER(6,2),
  CSAT_AVG_PRIOR_8W          NUMBER(6,2),
  OPEN_P1_P2                 NUMBER,
  RENEWAL_ARR                NUMBER(18,2),
  RENEWAL_PROBABILITY        NUMBER(8,4),
  HEALTH_RISK_REASON         VARCHAR,
  AT_RISK_EXPANSION_VALUE    NUMBER(18,2),
  HEALTH_DETERIORATING_FLAG  BOOLEAN COMMENT 'Usage last 4w below prior 8w AND (CSAT fell OR P1/P2 open). Deterministic.',
  ML_USAGE_ANOMALY_FLAG      BOOLEAN COMMENT 'Second opinion: downside usage anomaly in detection window.',
  ML_ANOMALY_SCORE           NUMBER(12,4),
  ML_ANOMALY_METHOD          VARCHAR,
  OPEN_PIPELINE_USD          NUMBER(18,2),
  BLOCKED_ORDER_USD          NUMBER(18,2),
  BILLING_EXCEPTION_USD      NUMBER(18,2),
  LEDGER_AT_RISK_USD         NUMBER(18,2),
  LEDGER_RECOVERABLE_USD     NUMBER(18,2),
  LEDGER_ITEM_COUNT          NUMBER,
  AS_OF_DATE                 DATE,
  REFRESHED_AT               TIMESTAMP_NTZ,
  CONSTRAINT PK_RR_C360 PRIMARY KEY (CUSTOMER_ID)
) COMMENT = 'Customer 360 decision table (one row per customer, as of AS_OF_DATE).';

-- ---------------------------------------------------------------------------
-- RR_OPPORTUNITY_360
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS RR_OPPORTUNITY_360 (
  OPPORTUNITY_ID          VARCHAR NOT NULL,
  OPPORTUNITY_NAME        VARCHAR,
  CUSTOMER_ID             VARCHAR,
  CUSTOMER_NAME           VARCHAR,
  PRODUCT_ID              VARCHAR,
  PRODUCT_FAMILY          VARCHAR,
  REGION_ID               VARCHAR,
  REGION_NAME             VARCHAR,
  STAGE_NAME              VARCHAR,
  FORECAST_CATEGORY       VARCHAR,
  OPPORTUNITY_STATUS      VARCHAR,
  OPPORTUNITY_AMOUNT      NUMBER(18,2),
  CRM_PROBABILITY_PCT     NUMBER,
  EXPECTED_CLOSE_DATE     DATE,
  CLOSES_IN_Q4            BOOLEAN,
  DAYS_IN_STAGE           NUMBER,
  RISK_REASON             VARCHAR,
  GOVERNED_RECOVERY_PROB  NUMBER(8,4) COMMENT 'Governed (source) recovery probability. Authoritative.',
  ML_WIN_PROB             NUMBER(8,4) COMMENT 'Second opinion only.',
  ML_METHOD               VARCHAR,
  ML_MINUS_GOVERNED       NUMBER(8,4),
  ML_DISAGREEMENT_FLAG    BOOLEAN,
  IN_RISK_LEDGER          BOOLEAN,
  AS_OF_DATE              DATE,
  REFRESHED_AT            TIMESTAMP_NTZ,
  CONSTRAINT PK_RR_O360 PRIMARY KEY (OPPORTUNITY_ID)
) COMMENT = 'Open-opportunity 360 with governed vs ML probability comparison.';

-- ---------------------------------------------------------------------------
-- RR_PRODUCT_INVENTORY_360
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS RR_PRODUCT_INVENTORY_360 (
  PRODUCT_ID                 VARCHAR NOT NULL,
  WAREHOUSE                  VARCHAR NOT NULL,
  PRODUCT_NAME               VARCHAR,
  PRODUCT_FAMILY             VARCHAR,
  SNAPSHOT_DATE              DATE,
  ON_HAND                    NUMBER,
  RESERVED                   NUMBER,
  AVAILABLE_QTY              NUMBER  COMMENT 'GREATEST(AVAILABLE,0) at latest snapshot on/before AS_OF_DATE',
  BLOCKED_ORDER_QTY          NUMBER  COMMENT 'Units on blocked priority orders sourced from this warehouse',
  BLOCKED_ORDER_USD          NUMBER(18,2),
  DONATED_QTY                NUMBER  COMMENT 'Units allocated from this warehouse to recover other warehouses orders',
  REMAINING_AFTER_ALLOCATION NUMBER,
  PRODUCT_TOTAL_AVAILABLE    NUMBER,
  ML_DEMAND_TO_QTR_END       NUMBER(18,2) COMMENT 'Second opinion: forecast units ordered from AS_OF week to QTR_END (product level)',
  DEMAND_COVERAGE_RATIO      NUMBER(12,4) COMMENT 'Product total available / ML demand to QTR_END',
  ML_DEMAND_METHOD           VARCHAR,
  AS_OF_DATE                 DATE,
  REFRESHED_AT               TIMESTAMP_NTZ,
  CONSTRAINT PK_RR_P360 PRIMARY KEY (PRODUCT_ID, WAREHOUSE)
) COMMENT = 'Product x warehouse inventory position, allocation and demand coverage.';

-- ---------------------------------------------------------------------------
-- RR_FULFILLMENT_ALLOCATION (inventory optimiser output)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS RR_FULFILLMENT_ALLOCATION (
  ORDER_ID              VARCHAR NOT NULL,
  PRODUCT_ID            VARCHAR,
  SOURCE_WAREHOUSE      VARCHAR,
  REQUIRED_QTY          NUMBER,
  BOOKED_VALUE          NUMBER(18,2),
  PROMISED_DATE         DATE,
  SOURCE_AVAILABLE_QTY  NUMBER,
  ALTERNATE_WAREHOUSE   VARCHAR,
  ALLOCATED_QTY         NUMBER,
  ALT_AVAILABLE_BEFORE  NUMBER,
  ALT_AVAILABLE_AFTER   NUMBER,
  COVERED_FLAG          BOOLEAN,
  ALLOCATION_SEQ        NUMBER,
  ALLOCATION_POLICY     VARCHAR,
  REASON                VARCHAR,
  AS_OF_DATE            DATE,
  ALLOCATED_AT          TIMESTAMP_NTZ,
  CONSTRAINT PK_RR_FA PRIMARY KEY (ORDER_ID)
) COMMENT = 'One decision per blocked priority order: can one alternate warehouse fully cover it without double-counting shared stock?';

-- ---------------------------------------------------------------------------
-- RR_RISK_LEDGER — primary governed decision artifact
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS RR_RISK_LEDGER (
  RISK_ITEM_ID          VARCHAR NOT NULL,
  CATEGORY              VARCHAR NOT NULL COMMENT 'PIPELINE | FULFILLMENT | BILLING | RENEWAL | SUPPORT_EXPANSION',
  SOURCE_TABLE          VARCHAR,
  SOURCE_ID             VARCHAR NOT NULL,
  CUSTOMER_ID           VARCHAR,
  CUSTOMER_NAME         VARCHAR,
  PRODUCT_ID            VARCHAR,
  PRODUCT_NAME          VARCHAR,
  PRODUCT_FAMILY        VARCHAR,
  REGION_ID             VARCHAR,
  REGION_NAME           VARCHAR,
  AT_RISK_USD           NUMBER(18,2) COMMENT 'Authoritative (SQL). Gross exposure for this item.',
  RECOVERABLE_USD       NUMBER(18,2) COMMENT 'Authoritative (SQL). Modeled recoverable value.',
  NO_PATH_USD           NUMBER(18,2) COMMENT 'AT_RISK_USD - RECOVERABLE_USD',
  RECOVERY_PROB         NUMBER(8,4)  COMMENT 'Governed recovery probability (never overwritten by ML or AI).',
  Q4_REVENUE_IMPACT     NUMBER(18,2) COMMENT 'Recoverable value used in illustrative scenarios. Renewal = ARR, not recognized Q4 revenue.',
  VALUE_BASIS           VARCHAR      COMMENT 'BOOKING | ORDER | INVOICE | ARR | EXPANSION',
  DUE_DATE              DATE,
  DAYS_TO_DUE           NUMBER       COMMENT 'Days from AS_OF_DATE to DUE_DATE',
  BLOCKER               VARCHAR,
  RECOVERY_PATH         VARCHAR      COMMENT 'Deterministic recovery path, e.g. alternate warehouse',
  EVIDENCE_TEXT         VARCHAR      COMMENT 'Stable evidence statement (no volatile fields, so AI is not re-triggered daily)',
  EVIDENCE              VARIANT,
  ML_SCORE              NUMBER(12,4),
  ML_SCORE_TYPE         VARCHAR      COMMENT 'WIN_PROBABILITY | USAGE_ANOMALY_SCORE | DEMAND_COVERAGE_RATIO',
  ML_METHOD             VARCHAR,
  ML_GOVERNED_DELTA     NUMBER(8,4)  COMMENT 'ML_SCORE - RECOVERY_PROB (pipeline only)',
  AI_RISK_CLASS         VARCHAR,
  AI_NEXT_BEST_ACTION   VARCHAR,
  AI_FIRST_STEP         VARCHAR,
  AI_OWNER_ROLE         VARCHAR,
  AI_SUMMARY            VARCHAR,
  AI_MODEL              VARCHAR,
  CALCULATION_RULE      VARCHAR,
  SOURCE_QUERY_ID       VARCHAR      COMMENT 'Query ID of the SQL statement that computed this row (lineage)',
  ROW_HASH              VARCHAR,
  PREV_ROW_HASH         VARCHAR,
  AI_INPUT_HASH         VARCHAR      COMMENT 'Hash of the evidence that AI enrichment depends on',
  AI_ENRICHED_HASH      VARCHAR      COMMENT 'AI_INPUT_HASH value at the time AI enrichment ran',
  AI_ENRICHED_AT        TIMESTAMP_NTZ,
  CHANGE_STATUS         VARCHAR      COMMENT 'NEW | CHANGED | UNCHANGED | REOPENED | RESOLVED | INACTIVE (vs previous refresh)',
  PREV_AT_RISK_USD      NUMBER(18,2),
  PREV_RECOVERABLE_USD  NUMBER(18,2),
  AS_OF_DATE            DATE,
  ACTIVE_FLAG           BOOLEAN,
  FIRST_SEEN_AT         TIMESTAMP_NTZ,
  REFRESH_ID            VARCHAR,
  REFRESHED_AT          TIMESTAMP_NTZ,
  CONSTRAINT PK_RR_LEDGER PRIMARY KEY (RISK_ITEM_ID)
) COMMENT = 'Unified Revenue Risk Ledger. SQL computes money; ML adds ML_*; Cortex AI adds AI_* only.';

-- ---------------------------------------------------------------------------
-- RR_REVENUE_OUTLOOK — single current authoritative row (history in RR_REFRESH_AUDIT)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS RR_REVENUE_OUTLOOK (
  OUTLOOK_ID                       VARCHAR NOT NULL,
  AS_OF_DATE                       DATE,
  QTR_START                        DATE,
  QTR_END                          DATE,
  PLAN_SCENARIO_ID                 VARCHAR,
  Q4_TARGET_USD                    NUMBER(18,2),
  Q4_FORECAST_USD                  NUMBER(18,2),
  FORECAST_GAP_USD                 NUMBER(18,2),
  Q4_ACTUAL_TO_DATE_USD            NUMBER(18,2),
  GROSS_AT_RISK_USD                NUMBER(18,2),
  MODELED_RECOVERABLE_USD          NUMBER(18,2),
  NO_PATH_USD                      NUMBER(18,2),
  PIPELINE_AT_RISK_USD             NUMBER(18,2),
  PIPELINE_RECOVERABLE_USD         NUMBER(18,2),
  FULFILLMENT_AT_RISK_USD          NUMBER(18,2),
  FULFILLMENT_RECOVERABLE_USD      NUMBER(18,2),
  BILLING_AT_RISK_USD              NUMBER(18,2),
  BILLING_RECOVERABLE_USD          NUMBER(18,2),
  RENEWAL_AT_RISK_USD              NUMBER(18,2),
  RENEWAL_RECOVERABLE_USD          NUMBER(18,2),
  SUPPORT_EXPANSION_AT_RISK_USD    NUMBER(18,2),
  SUPPORT_EXPANSION_RECOVERABLE_USD NUMBER(18,2),
  BASE_RECOVERY_CATEGORIES         VARCHAR,
  BASE_RECOVERY_USD                NUMBER(18,2),
  BASE_REVISED_OUTLOOK_USD         NUMBER(18,2),
  BASE_REMAINING_GAP_USD           NUMBER(18,2),
  UPSIDE_RECOVERY_USD              NUMBER(18,2),
  UPSIDE_OUTLOOK_USD               NUMBER(18,2),
  UPSIDE_REMAINING_GAP_USD         NUMBER(18,2),
  ML_Q4_SHIPMENTS_TO_DATE_USD      NUMBER(18,2),
  ML_Q4_SHIPMENTS_PROJECTED_USD    NUMBER(18,2),
  ML_REVENUE_METHOD                VARCHAR,
  RISK_ITEM_COUNT                  NUMBER,
  ACCOUNTING_NOTE                  VARCHAR,
  REFRESH_ID                       VARCHAR,
  REFRESHED_AT                     TIMESTAMP_NTZ,
  CONSTRAINT PK_RR_OUTLOOK PRIMARY KEY (OUTLOOK_ID)
) COMMENT = 'Authoritative executive revenue position. Base Revised Outlook and Upside Recovery Case are illustrative scenarios, not forecasts.';

-- ---------------------------------------------------------------------------
-- SP_ALLOCATE_ALTERNATE_INVENTORY — inventory optimiser (Python)
--   * Candidates: orders whose RISK_REASON equals the LOCKED configured reason,
--     unshipped as of AS_OF_DATE.
--   * Supply: RR_PRODUCT_INVENTORY_360.AVAILABLE_QTY (latest snapshot <= AS_OF_DATE).
--   * An order is recoverable only if ONE alternate warehouse (not its own)
--     holding the SAME product can cover the FULL quantity.
--   * Shared stock is decremented as it is allocated -> no double counting.
--   * Order priority: earliest promise date, then highest value, then ORDER_ID.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE SP_ALLOCATE_ALTERNATE_INVENTORY()
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.11'
PACKAGES = ('snowflake-snowpark-python')
HANDLER = 'run'
COMMENT = 'Greedy, non-double-counting allocation of alternate same-product inventory to blocked priority orders.'
AS
$$
from datetime import datetime
from snowflake.snowpark.types import (StructType, StructField, StringType, DecimalType,
                                      DateType, BooleanType, TimestampType, LongType)

def run(session):
    cfg = session.sql("""
        SELECT AS_OF_DATE, QTR_END, FULFILLMENT_RISK_REASON,
               COALESCE(FULFILLMENT_ALLOCATION_POLICY, 'BEST_FIT') AS POLICY,
               COALESCE(FULFILLMENT_Q4_PROMISE_ONLY, FALSE) AS Q4_ONLY
        FROM RR_CONFIG WHERE CONFIG_ID = 1""").collect()[0]
    policy = str(cfg["POLICY"]).upper()

    orders = session.sql("""
        SELECT o.ORDER_ID, o.PRODUCT_ID, o.WAREHOUSE, o.QUANTITY, o.BOOKED_VALUE, o.PROMISED_DATE
        FROM FACT_ORDER o
        CROSS JOIN (SELECT * FROM RR_CONFIG WHERE CONFIG_ID = 1) c
        WHERE TRIM(o.RISK_REASON) = c.FULFILLMENT_RISK_REASON
          AND (o.SHIPPED_DATE IS NULL OR o.SHIPPED_DATE > c.AS_OF_DATE)
          AND (o.ORDER_DATE IS NULL OR o.ORDER_DATE <= c.AS_OF_DATE)
          AND (NOT COALESCE(c.FULFILLMENT_Q4_PROMISE_ONLY, FALSE) OR o.PROMISED_DATE <= c.QTR_END)
        ORDER BY o.PROMISED_DATE NULLS LAST, o.BOOKED_VALUE DESC NULLS LAST, o.ORDER_ID""").collect()

    inv_rows = session.sql("SELECT PRODUCT_ID, WAREHOUSE, AVAILABLE_QTY FROM RR_PRODUCT_INVENTORY_360").collect()
    remaining = {}
    for r in inv_rows:
        remaining[(r["PRODUCT_ID"], r["WAREHOUSE"])] = int(r["AVAILABLE_QTY"] or 0)
    original = dict(remaining)

    out = []
    now = datetime.utcnow()
    seq = 0
    for o in orders:
        seq += 1
        qty = int(o["QUANTITY"]) if o["QUANTITY"] is not None else None
        pid, own_wh = o["PRODUCT_ID"], o["WAREHOUSE"]
        own_avail = original.get((pid, own_wh))
        alt_wh, before, after, alloc, covered = None, None, None, 0, False
        if qty is None or qty <= 0:
            reason = "Quantity missing or non-positive: cannot evaluate coverage"
        else:
            cands = [(a, w) for (p, w), a in remaining.items()
                     if p == pid and w != own_wh and a >= qty]
            if cands:
                if policy == "LARGEST":
                    a, w = sorted(cands, key=lambda t: (-t[0], str(t[1])))[0]
                else:  # BEST_FIT preserves larger pools for later orders
                    a, w = sorted(cands, key=lambda t: (t[0], str(t[1])))[0]
                alt_wh, before = w, a
                remaining[(pid, w)] = a - qty
                after, alloc, covered = a - qty, qty, True
                reason = f"Alternate warehouse {w} fully covers {qty} units ({a} available before allocation)"
            else:
                best_alt = max([a for (p, w), a in remaining.items() if p == pid and w != own_wh], default=0)
                reason = (f"No single alternate warehouse can cover {qty} units "
                          f"(largest remaining alternate pool: {best_alt})")
        out.append((o["ORDER_ID"], pid, own_wh, qty, o["BOOKED_VALUE"], o["PROMISED_DATE"],
                    own_avail, alt_wh, alloc, before, after, covered, seq, policy, reason,
                    cfg["AS_OF_DATE"], now))

    schema = StructType([
        StructField("ORDER_ID", StringType()), StructField("PRODUCT_ID", StringType()),
        StructField("SOURCE_WAREHOUSE", StringType()), StructField("REQUIRED_QTY", LongType()),
        StructField("BOOKED_VALUE", DecimalType(18, 2)), StructField("PROMISED_DATE", DateType()),
        StructField("SOURCE_AVAILABLE_QTY", LongType()), StructField("ALTERNATE_WAREHOUSE", StringType()),
        StructField("ALLOCATED_QTY", LongType()), StructField("ALT_AVAILABLE_BEFORE", LongType()),
        StructField("ALT_AVAILABLE_AFTER", LongType()), StructField("COVERED_FLAG", BooleanType()),
        StructField("ALLOCATION_SEQ", LongType()), StructField("ALLOCATION_POLICY", StringType()),
        StructField("REASON", StringType()), StructField("AS_OF_DATE", DateType()),
        StructField("ALLOCATED_AT", TimestampType())])

    session.sql("TRUNCATE TABLE RR_FULFILLMENT_ALLOCATION").collect()
    if out:
        session.create_dataframe(out, schema=schema).write.mode("append").save_as_table(
            "RR_FULFILLMENT_ALLOCATION", column_order="name")

    covered = [r for r in out if r[11]]
    return {
        "orders_evaluated": len(out),
        "orders_covered": len(covered),
        "booked_value_evaluated": float(sum(float(r[4] or 0) for r in out)),
        "booked_value_covered": float(sum(float(r[4] or 0) for r in covered)),
        "policy": policy,
    }
$$;

SHOW TABLES LIKE 'RR_%' IN SCHEMA HACKATHON_REVENUE_RISK.SOLUTION;
