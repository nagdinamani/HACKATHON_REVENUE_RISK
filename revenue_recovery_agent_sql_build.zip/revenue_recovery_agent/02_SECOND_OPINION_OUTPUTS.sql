/* =============================================================================
   02_SECOND_OPINION_OUTPUTS.sql
   ML / statistical SECOND OPINION layer.

   * Creates the fixed output contract tables (identical whether native
     Snowflake ML or the statistical fallback produced the rows):
        RR_ML_DEAL_SCORES       win probability per open opportunity
        RR_ML_USAGE_ANOMALIES   usage-change anomalies per customer-week
        RR_ML_REVENUE_FORECAST  weekly shipped-revenue actuals + forecast to QTR_END
        RR_ML_DEMAND_FORECAST   weekly unit demand forecast per product to QTR_END
        RR_ML_GAP_DRIVERS       segments driving forecast-vs-target gap
        RR_ML_PLAN_FORECAST     monthly company revenue forecast (P10/P50/P90) for Q4 vs plan
   * SP_BUILD_SECOND_OPINION_FALLBACK : deterministic SQL statistics (always runs)
   * SP_REFRESH_SECOND_OPINION        : fallback first, then overlays native
                                        Snowflake ML results if 03 was deployed.

   The second opinion NEVER writes governed probabilities or money. It is joined
   into the decision layer as ML_SCORE / ML_GOVERNED_DELTA only.
   ============================================================================= */

USE DATABASE HACKATHON_REVENUE_RISK;
USE SCHEMA SOLUTION;
USE WAREHOUSE RR_WH;

-- ---------------------------------------------------------------------------
-- 1. Output contract tables
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS RR_ML_DEAL_SCORES (
  OPPORTUNITY_ID  VARCHAR NOT NULL,
  ML_WIN_PROB     NUMBER(8,4),
  ML_METHOD       VARCHAR,
  MODEL_NAME      VARCHAR,
  FEATURES        VARIANT,
  AS_OF_DATE      DATE,
  SCORED_AT       TIMESTAMP_NTZ,
  CONSTRAINT PK_RR_ML_DEAL PRIMARY KEY (OPPORTUNITY_ID)
) COMMENT = 'Second-opinion win probability for open opportunities. Never overwrites governed RECOVERY_PROB.';

CREATE TABLE IF NOT EXISTS RR_ML_USAGE_ANOMALIES (
  CUSTOMER_ID       VARCHAR NOT NULL,
  SNAPSHOT_DATE     DATE NOT NULL,
  USAGE_CHANGE_PCT  NUMBER(10,4),
  EXPECTED_VALUE    NUMBER(12,4),
  LOWER_BOUND       NUMBER(12,4),
  UPPER_BOUND       NUMBER(12,4),
  IS_ANOMALY        BOOLEAN,
  DIRECTION         VARCHAR,
  ANOMALY_SCORE     NUMBER(12,4),
  ML_METHOD         VARCHAR,
  MODEL_NAME        VARCHAR,
  AS_OF_DATE        DATE,
  SCORED_AT         TIMESTAMP_NTZ
) COMMENT = 'Usage-change anomalies in the detection window ending AS_OF_DATE.';

CREATE TABLE IF NOT EXISTS RR_ML_REVENUE_FORECAST (
  SERIES        VARCHAR NOT NULL COMMENT 'Product family',
  PERIOD_START  DATE NOT NULL    COMMENT 'Week start',
  ROW_TYPE      VARCHAR NOT NULL COMMENT 'ACTUAL (Q4 to date) | FORECAST (through QTR_END, last week prorated)',
  VALUE_USD     NUMBER(18,2),
  LOWER_BOUND   NUMBER(18,2),
  UPPER_BOUND   NUMBER(18,2),
  ML_METHOD     VARCHAR,
  MODEL_NAME    VARCHAR,
  AS_OF_DATE    DATE,
  SCORED_AT     TIMESTAMP_NTZ
) COMMENT = 'Shipment run-rate second opinion (booked value of shipped orders). Directional only; not comparable 1:1 with plan revenue.';

CREATE TABLE IF NOT EXISTS RR_ML_DEMAND_FORECAST (
  PRODUCT_ID    VARCHAR NOT NULL,
  PERIOD_START  DATE NOT NULL,
  FORECAST_QTY  NUMBER(18,2),
  LOWER_BOUND   NUMBER(18,2),
  UPPER_BOUND   NUMBER(18,2),
  ML_METHOD     VARCHAR,
  MODEL_NAME    VARCHAR,
  AS_OF_DATE    DATE,
  SCORED_AT     TIMESTAMP_NTZ
) COMMENT = 'Weekly ordered-unit demand forecast per product through QTR_END.';

CREATE TABLE IF NOT EXISTS RR_ML_GAP_DRIVERS (
  DRIVER_RANK            NUMBER,
  CONTRIBUTOR            VARCHAR,
  METRIC_CONTROL_TARGET  NUMBER(18,2),
  METRIC_TEST_FORECAST   NUMBER(18,2),
  CONTRIBUTION           NUMBER(18,2),
  RELATIVE_CONTRIBUTION  NUMBER(18,6),
  GROWTH_RATE            NUMBER(18,6),
  ML_METHOD              VARCHAR,
  MODEL_NAME             VARCHAR,
  AS_OF_DATE             DATE,
  SCORED_AT              TIMESTAMP_NTZ
) COMMENT = 'Segments explaining Q4 forecast vs target (control = target, test = forecast).';

CREATE TABLE IF NOT EXISTS RR_ML_PLAN_FORECAST (
  PERIOD_MONTH     DATE NOT NULL COMMENT 'Q4 month (first day)',
  ML_FORECAST_USD  NUMBER(18,2) COMMENT 'Company-level ML revenue forecast for the month (comparable with plan target / forecast)',
  ML_P10_USD       NUMBER(18,2),
  ML_P90_USD       NUMBER(18,2),
  ML_METHOD        VARCHAR,
  MODEL_NAME       VARCHAR,
  AS_OF_DATE       DATE,
  SCORED_AT        TIMESTAMP_NTZ
) COMMENT = 'Second-opinion monthly revenue forecast from FACT_REVENUE_PLAN.ACTUAL_REVENUE history. Never replaces the plan forecast.';

-- ---------------------------------------------------------------------------
-- 2. Deterministic statistical fallback (same contract, always available)
-- ---------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE SP_BUILD_SECOND_OPINION_FALLBACK()
RETURNS VARCHAR
LANGUAGE SQL
COMMENT = 'Statistical second opinion: smoothed win rates, z-score anomalies, trailing run-rate forecasts, variance decomposition.'
AS
$$
BEGIN
  -- 2a. Deal win probability: empirical win rate by stage x product family,
  --     Bayesian-smoothed toward the stage rate, which is smoothed toward the global rate (k = 10).
  INSERT OVERWRITE INTO RR_ML_DEAL_SCORES
  WITH c AS (SELECT * FROM RR_CONFIG WHERE CONFIG_ID = 1),
  hist AS (
    SELECT COALESCE(NULLIF(TRIM(o.LAST_OPEN_STAGE), ''), o.STAGE_NAME) AS STAGE,
           COALESCE(p.PRODUCT_FAMILY, 'UNKNOWN') AS PRODUCT_FAMILY,
           IFF(o.OPPORTUNITY_STATUS ILIKE '%won%', 1, 0) AS WON
    FROM FACT_OPPORTUNITY o
    LEFT JOIN DIM_PRODUCT p ON p.PRODUCT_ID = o.PRODUCT_ID
    CROSS JOIN c
    WHERE o.ACTUAL_CLOSE_DATE IS NOT NULL
      AND o.ACTUAL_CLOSE_DATE <= c.AS_OF_DATE
      AND (o.OPPORTUNITY_STATUS ILIKE '%won%' OR o.OPPORTUNITY_STATUS ILIKE '%lost%')
  ),
  g  AS (SELECT AVG(WON) AS G_RATE FROM hist),
  st AS (SELECT STAGE, SUM(WON) AS W, COUNT(*) AS N FROM hist GROUP BY 1),
  sf AS (SELECT STAGE, PRODUCT_FAMILY, SUM(WON) AS W, COUNT(*) AS N FROM hist GROUP BY 1, 2),
  open_opps AS (
    SELECT o.OPPORTUNITY_ID, o.STAGE_NAME AS STAGE, COALESCE(p.PRODUCT_FAMILY, 'UNKNOWN') AS PRODUCT_FAMILY
    FROM FACT_OPPORTUNITY o
    LEFT JOIN DIM_PRODUCT p ON p.PRODUCT_ID = o.PRODUCT_ID
    CROSS JOIN c
    WHERE (o.ACTUAL_CLOSE_DATE IS NULL OR o.ACTUAL_CLOSE_DATE > c.AS_OF_DATE)
      AND (o.CREATED_DATE IS NULL OR o.CREATED_DATE <= c.AS_OF_DATE)
  ),
  scored AS (
    SELECT x.OPPORTUNITY_ID, x.STAGE, x.PRODUCT_FAMILY,
           (COALESCE(st.W, 0) + 10 * g.G_RATE) / (COALESCE(st.N, 0) + 10) AS STAGE_RATE,
           COALESCE(sf.W, 0) AS SF_W, COALESCE(sf.N, 0) AS SF_N
    FROM open_opps x
    CROSS JOIN g
    LEFT JOIN st ON st.STAGE = x.STAGE
    LEFT JOIN sf ON sf.STAGE = x.STAGE AND sf.PRODUCT_FAMILY = x.PRODUCT_FAMILY
  )
  SELECT s.OPPORTUNITY_ID,
         ROUND((s.SF_W + 10 * s.STAGE_RATE) / (s.SF_N + 10), 4),
         'STATISTICAL_FALLBACK',
         'SMOOTHED_EMPIRICAL_WIN_RATE(stage x product_family, k=10)',
         OBJECT_CONSTRUCT('stage', s.STAGE, 'product_family', s.PRODUCT_FAMILY, 'segment_closed_deals', s.SF_N),
         c.AS_OF_DATE, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
  FROM scored s CROSS JOIN c;

  -- 2b. Usage anomalies: z-score of each detection-window observation vs the customer baseline.
  INSERT OVERWRITE INTO RR_ML_USAGE_ANOMALIES
  WITH c AS (SELECT * FROM RR_CONFIG WHERE CONFIG_ID = 1),
  w AS (
    SELECT c.AS_OF_DATE,
           DATEADD(week, -c.ANOMALY_DETECTION_WEEKS, c.AS_OF_DATE) AS DETECT_START,
           DATEADD(week, -(c.ANOMALY_DETECTION_WEEKS + c.ANOMALY_BASELINE_WEEKS), c.AS_OF_DATE) AS BASE_START
    FROM c
  ),
  base AS (
    SELECT h.CUSTOMER_ID, AVG(h.USAGE_CHANGE_PCT) AS MU, STDDEV_SAMP(h.USAGE_CHANGE_PCT) AS SD
    FROM FACT_CUSTOMER_HEALTH h CROSS JOIN w
    WHERE h.SNAPSHOT_DATE > w.BASE_START AND h.SNAPSHOT_DATE <= w.DETECT_START
    GROUP BY 1
  ),
  det AS (
    SELECT h.CUSTOMER_ID, h.SNAPSHOT_DATE, h.USAGE_CHANGE_PCT
    FROM FACT_CUSTOMER_HEALTH h CROSS JOIN w
    WHERE h.SNAPSHOT_DATE > w.DETECT_START AND h.SNAPSHOT_DATE <= w.AS_OF_DATE
  )
  SELECT d.CUSTOMER_ID, d.SNAPSHOT_DATE, d.USAGE_CHANGE_PCT,
         ROUND(b.MU, 4), ROUND(b.MU - 2 * b.SD, 4), ROUND(b.MU + 2 * b.SD, 4),
         COALESCE(ABS((d.USAGE_CHANGE_PCT - b.MU) / NULLIF(b.SD, 0)) >= 2, FALSE),
         IFF(d.USAGE_CHANGE_PCT < b.MU, 'DOWN', 'UP'),
         ROUND((d.USAGE_CHANGE_PCT - b.MU) / NULLIF(b.SD, 0), 4),
         'STATISTICAL_FALLBACK', 'ZSCORE_VS_CUSTOMER_BASELINE(|z|>=2)',
         w.AS_OF_DATE, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
  FROM det d
  LEFT JOIN base b ON b.CUSTOMER_ID = d.CUSTOMER_ID
  CROSS JOIN w;

  -- 2c. Shipment revenue: Q4-to-date actuals + trailing-8-week run-rate forecast to QTR_END.
  INSERT OVERWRITE INTO RR_ML_REVENUE_FORECAST
  WITH c AS (SELECT * FROM RR_CONFIG WHERE CONFIG_ID = 1),
  k AS (SELECT DATE_TRUNC('WEEK', c.AS_OF_DATE) AS CUR_WEEK, c.QTR_START, c.QTR_END, c.AS_OF_DATE FROM c),
  ship AS (
    SELECT COALESCE(p.PRODUCT_FAMILY, 'UNKNOWN') AS SERIES, DATE_TRUNC('WEEK', o.SHIPPED_DATE) AS WK,
           MIN(o.SHIPPED_DATE) AS FIRST_DAY, SUM(o.BOOKED_VALUE) AS V
    FROM FACT_ORDER o
    LEFT JOIN DIM_PRODUCT p ON p.PRODUCT_ID = o.PRODUCT_ID
    CROSS JOIN k
    WHERE o.SHIPPED_DATE IS NOT NULL AND o.SHIPPED_DATE < k.CUR_WEEK
    GROUP BY 1, 2
  ),
  q4_actual AS (
    SELECT COALESCE(p.PRODUCT_FAMILY, 'UNKNOWN') AS SERIES, DATE_TRUNC('WEEK', o.SHIPPED_DATE) AS WK, SUM(o.BOOKED_VALUE) AS V
    FROM FACT_ORDER o
    LEFT JOIN DIM_PRODUCT p ON p.PRODUCT_ID = o.PRODUCT_ID
    CROSS JOIN k
    WHERE o.SHIPPED_DATE >= k.QTR_START AND o.SHIPPED_DATE < k.CUR_WEEK
    GROUP BY 1, 2
  ),
  series AS (SELECT DISTINCT SERIES FROM ship),
  last8 AS (
    SELECT DATEADD(week, -(ROW_NUMBER() OVER (ORDER BY SEQ4())), k.CUR_WEEK) AS WK
    FROM TABLE(GENERATOR(ROWCOUNT => 8)) CROSS JOIN k
  ),
  trail AS (
    SELECT s.SERIES, AVG(COALESCE(sh.V, 0)) AS AVG8, COALESCE(STDDEV_SAMP(COALESCE(sh.V, 0)), 0) AS SD8
    FROM series s CROSS JOIN last8 w
    LEFT JOIN ship sh ON sh.SERIES = s.SERIES AND sh.WK = w.WK
    GROUP BY 1
  ),
  fut AS (
    SELECT WK, LEAST(7, DATEDIFF(day, WK, QTR_END) + 1) / 7 AS PRORATE
    FROM (SELECT DATEADD(week, ROW_NUMBER() OVER (ORDER BY SEQ4()) - 1, k.CUR_WEEK) AS WK, k.QTR_END
          FROM TABLE(GENERATOR(ROWCOUNT => 20)) CROSS JOIN k)
    WHERE WK <= QTR_END
  )
  SELECT a.SERIES, a.WK, 'ACTUAL', a.V, a.V, a.V,
         'ACTUAL', 'FACT_ORDER.SHIPPED', c.AS_OF_DATE, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
  FROM q4_actual a CROSS JOIN c
  UNION ALL
  SELECT t.SERIES, f.WK, 'FORECAST',
         ROUND(t.AVG8 * f.PRORATE, 2),
         ROUND(GREATEST(t.AVG8 - 1.2816 * t.SD8, 0) * f.PRORATE, 2),
         ROUND((t.AVG8 + 1.2816 * t.SD8) * f.PRORATE, 2),
         'STATISTICAL_FALLBACK', 'TRAILING_8_WEEK_RUN_RATE', c.AS_OF_DATE, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
  FROM trail t CROSS JOIN fut f CROSS JOIN c;

  -- 2d. Demand: trailing-8-week average ordered units per product, forecast to QTR_END.
  INSERT OVERWRITE INTO RR_ML_DEMAND_FORECAST
  WITH c AS (SELECT * FROM RR_CONFIG WHERE CONFIG_ID = 1),
  k AS (SELECT DATE_TRUNC('WEEK', c.AS_OF_DATE) AS CUR_WEEK, c.QTR_END FROM c),
  dem AS (
    SELECT o.PRODUCT_ID, DATE_TRUNC('WEEK', o.ORDER_DATE) AS WK, SUM(COALESCE(o.QUANTITY, 0)) AS Q
    FROM FACT_ORDER o CROSS JOIN k
    WHERE o.ORDER_DATE < k.CUR_WEEK
    GROUP BY 1, 2
  ),
  prods AS (SELECT PRODUCT_ID FROM DIM_PRODUCT),
  last8 AS (
    SELECT DATEADD(week, -(ROW_NUMBER() OVER (ORDER BY SEQ4())), k.CUR_WEEK) AS WK
    FROM TABLE(GENERATOR(ROWCOUNT => 8)) CROSS JOIN k
  ),
  trail AS (
    SELECT p.PRODUCT_ID, AVG(COALESCE(d.Q, 0)) AS AVG8, COALESCE(STDDEV_SAMP(COALESCE(d.Q, 0)), 0) AS SD8
    FROM prods p CROSS JOIN last8 w
    LEFT JOIN dem d ON d.PRODUCT_ID = p.PRODUCT_ID AND d.WK = w.WK
    GROUP BY 1
  ),
  fut AS (
    SELECT WK, LEAST(7, DATEDIFF(day, WK, QTR_END) + 1) / 7 AS PRORATE
    FROM (SELECT DATEADD(week, ROW_NUMBER() OVER (ORDER BY SEQ4()) - 1, k.CUR_WEEK) AS WK, k.QTR_END
          FROM TABLE(GENERATOR(ROWCOUNT => 20)) CROSS JOIN k)
    WHERE WK <= QTR_END
  )
  SELECT t.PRODUCT_ID, f.WK,
         ROUND(t.AVG8 * f.PRORATE, 2),
         ROUND(GREATEST(t.AVG8 - 1.2816 * t.SD8, 0) * f.PRORATE, 2),
         ROUND((t.AVG8 + 1.2816 * t.SD8) * f.PRORATE, 2),
         'STATISTICAL_FALLBACK', 'TRAILING_8_WEEK_DEMAND', c.AS_OF_DATE, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
  FROM trail t CROSS JOIN fut f CROSS JOIN c;

  -- 2e. Gap drivers: region x product-family variance decomposition of forecast vs target.
  INSERT OVERWRITE INTO RR_ML_GAP_DRIVERS
  WITH c AS (SELECT * FROM RR_CONFIG WHERE CONFIG_ID = 1),
  rgn AS (SELECT REGION_ID, ANY_VALUE(REGION_NAME) AS REGION_NAME FROM DIM_CUSTOMER GROUP BY 1),
  q4 AS (
    SELECT COALESCE(r.REGION_NAME, p.REGION_ID) AS REGION, p.PRODUCT_FAMILY,
           SUM(p.TARGET_REVENUE) AS T, SUM(p.FORECAST_REVENUE) AS F
    FROM FACT_REVENUE_PLAN p
    LEFT JOIN rgn r ON r.REGION_ID = p.REGION_ID
    CROSS JOIN c
    WHERE p.PERIOD_MONTH BETWEEN c.QTR_START AND c.QTR_END
      AND (c.PLAN_SCENARIO_ID IS NULL OR p.SCENARIO_ID = c.PLAN_SCENARIO_ID)
    GROUP BY 1, 2
  ),
  tot AS (SELECT SUM(T) AS T, SUM(F) AS F FROM q4),
  seg AS (
    SELECT 0 AS SORT_KEY, 'Overall' AS CONTRIBUTOR, tot.T, tot.F FROM tot
    UNION ALL
    SELECT 1, 'REGION = ' || REGION || ', PRODUCT_FAMILY = ' || PRODUCT_FAMILY, T, F FROM q4
  )
  SELECT ROW_NUMBER() OVER (ORDER BY s.SORT_KEY, (s.F - s.T) ASC, s.CONTRIBUTOR) - 1,
         s.CONTRIBUTOR, s.T, s.F, s.F - s.T,
         ROUND((s.F - s.T) / NULLIF(tot.F - tot.T, 0), 6),
         ROUND(s.F / NULLIF(s.T, 0) - 1, 6),
         'STATISTICAL_FALLBACK', 'SQL_VARIANCE_DECOMPOSITION(region x product_family)',
         c.AS_OF_DATE, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
  FROM seg s CROSS JOIN tot CROSS JOIN c;

  -- 2f. Monthly revenue second opinion: seasonal-naive x year-over-year growth.
  --     F(m) = actual(m - 12 months) x mean YoY ratio of the last 9 closed months;
  --     P10/P90 from the dispersion of those ratios. Falls back to the trailing
  --     3-month mean when the prior-year month is missing.
  INSERT OVERWRITE INTO RR_ML_PLAN_FORECAST
  WITH c AS (SELECT * FROM RR_CONFIG WHERE CONFIG_ID = 1),
  hist AS (
    SELECT p.PERIOD_MONTH, SUM(p.ACTUAL_REVENUE) AS A
    FROM FACT_REVENUE_PLAN p CROSS JOIN c
    WHERE p.PERIOD_MONTH < c.QTR_START AND p.ACTUAL_REVENUE IS NOT NULL
      AND (c.PLAN_SCENARIO_ID IS NULL OR p.SCENARIO_ID = c.PLAN_SCENARIO_ID)
    GROUP BY 1
  ),
  ratios AS (
    SELECT h.PERIOD_MONTH, h.A / NULLIF(prev.A, 0) AS R
    FROM hist h JOIN hist prev ON prev.PERIOD_MONTH = DATEADD(month, -12, h.PERIOD_MONTH)
    QUALIFY ROW_NUMBER() OVER (ORDER BY h.PERIOD_MONTH DESC) <= 9
  ),
  g AS (SELECT AVG(R) AS G, COALESCE(STDDEV_SAMP(R), 0) AS SD, COUNT(*) AS N FROM ratios),
  last3 AS (
    SELECT AVG(A) AS MU, COALESCE(STDDEV_SAMP(A), 0) AS SD
    FROM (SELECT A FROM hist QUALIFY ROW_NUMBER() OVER (ORDER BY PERIOD_MONTH DESC) <= 3)
  ),
  q4 AS (
    SELECT DISTINCT p.PERIOD_MONTH FROM FACT_REVENUE_PLAN p CROSS JOIN c
    WHERE p.PERIOD_MONTH BETWEEN c.QTR_START AND c.QTR_END
  )
  SELECT q4.PERIOD_MONTH,
         ROUND(IFF(ly.A IS NOT NULL AND g.N >= 3, ly.A * g.G, l3.MU), 2),
         ROUND(GREATEST(IFF(ly.A IS NOT NULL AND g.N >= 3, ly.A * (g.G - 1.2816 * g.SD), l3.MU - 1.2816 * l3.SD), 0), 2),
         ROUND(IFF(ly.A IS NOT NULL AND g.N >= 3, ly.A * (g.G + 1.2816 * g.SD), l3.MU + 1.2816 * l3.SD), 2),
         'STATISTICAL_FALLBACK',
         IFF(ly.A IS NOT NULL AND g.N >= 3, 'SEASONAL_NAIVE_X_YOY_GROWTH', 'TRAILING_3_MONTH_MEAN'),
         c.AS_OF_DATE, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ
  FROM q4
  CROSS JOIN g CROSS JOIN last3 l3 CROSS JOIN c
  LEFT JOIN hist ly ON ly.PERIOD_MONTH = DATEADD(month, -12, q4.PERIOD_MONTH);

  RETURN 'SECOND_OPINION_FALLBACK_BUILT';
END;
$$;

-- ---------------------------------------------------------------------------
-- 3. Orchestrator: fallback first, then native Snowflake ML overlay if present.
--    SP_APPLY_NATIVE_ML is created by optional 03; if it does not exist or a
--    model fails, the fallback rows remain and the stage is logged DEGRADED.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE SP_REFRESH_SECOND_OPINION()
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
COMMENT = 'Builds the ML second opinion: statistical fallback, then native Snowflake ML overlay when available.'
AS
$$
DECLARE
  run_id        VARCHAR;
  started_at    TIMESTAMP_NTZ;
  native_result VARCHAR DEFAULT 'NOT_DEPLOYED';
  stage_status  VARCHAR DEFAULT 'SUCCESS';
BEGIN
  run_id := 'SO-' || TO_VARCHAR(CURRENT_TIMESTAMP(), 'YYYYMMDDHH24MISSFF3');
  started_at := CURRENT_TIMESTAMP()::TIMESTAMP_NTZ;
  CALL SP_ASSERT_CONFIG_LOCKED();
  CALL SP_BUILD_SECOND_OPINION_FALLBACK();

  BEGIN
    CALL SP_APPLY_NATIVE_ML() INTO :native_result;
  EXCEPTION
    WHEN OTHER THEN
      native_result := 'NATIVE_ML_UNAVAILABLE: ' || SQLERRM;
      stage_status := 'DEGRADED';
  END;

  INSERT INTO RR_REFRESH_AUDIT (RUN_ID, STAGE, STATUS, STARTED_AT, ENDED_AT, AS_OF_DATE, ROWS_AFFECTED, DETAILS, RUN_BY)
  SELECT :run_id, 'SECOND_OPINION', :stage_status, :started_at, CURRENT_TIMESTAMP()::TIMESTAMP_NTZ,
         (SELECT AS_OF_DATE FROM RR_CONFIG WHERE CONFIG_ID = 1),
         (SELECT COUNT(*) FROM RR_ML_DEAL_SCORES),
         OBJECT_CONSTRUCT(
           'native_ml', :native_result,
           'methods', (SELECT ARRAY_AGG(DISTINCT M) FROM (
                         SELECT ML_METHOD AS M FROM RR_ML_DEAL_SCORES
                         UNION SELECT ML_METHOD FROM RR_ML_USAGE_ANOMALIES
                         UNION SELECT ML_METHOD FROM RR_ML_REVENUE_FORECAST
                         UNION SELECT ML_METHOD FROM RR_ML_DEMAND_FORECAST
                         UNION SELECT ML_METHOD FROM RR_ML_GAP_DRIVERS
                         UNION SELECT ML_METHOD FROM RR_ML_PLAN_FORECAST))),
         CURRENT_USER();

  RETURN 'SECOND_OPINION ' || :stage_status || ' | native: ' || :native_result;
END;
$$;

CALL SP_REFRESH_SECOND_OPINION();

SELECT 'RR_ML_DEAL_SCORES' AS OUTPUT, ML_METHOD, COUNT(*) AS ROWS_FOUND FROM RR_ML_DEAL_SCORES GROUP BY 1, 2
UNION ALL SELECT 'RR_ML_USAGE_ANOMALIES', ML_METHOD, COUNT(*) FROM RR_ML_USAGE_ANOMALIES GROUP BY 1, 2
UNION ALL SELECT 'RR_ML_REVENUE_FORECAST', ML_METHOD, COUNT(*) FROM RR_ML_REVENUE_FORECAST GROUP BY 1, 2
UNION ALL SELECT 'RR_ML_DEMAND_FORECAST', ML_METHOD, COUNT(*) FROM RR_ML_DEMAND_FORECAST GROUP BY 1, 2
UNION ALL SELECT 'RR_ML_GAP_DRIVERS', ML_METHOD, COUNT(*) FROM RR_ML_GAP_DRIVERS GROUP BY 1, 2
UNION ALL SELECT 'RR_ML_PLAN_FORECAST', ML_METHOD, COUNT(*) FROM RR_ML_PLAN_FORECAST GROUP BY 1, 2
ORDER BY 1, 2;
